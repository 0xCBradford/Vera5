function Pl(e=globalThis){const t=e.browser;return t&&t!==e.chrome?(e.chrome=t,!0):!1}Pl();const d={IPV4:"ipv4",DOMAIN:"domain",URL:"url",MD5:"md5",SHA1:"sha1",SHA256:"sha256",CVE:"cve",EMAIL:"email",ASN:"asn",CIDR:"cidr",FILEPATH:"filepath",ONION:"onion"},b={URL:"ioc.regex.url",SHA256:"ioc.regex.sha256",SHA1:"ioc.regex.sha1",MD5:"ioc.regex.md5",CVE:"ioc.regex.cve",IPV4:"ioc.regex.ipv4",DOMAIN:"ioc.regex.domain",EMAIL:"ioc.regex.email",ASN:"ioc.regex.asn",CIDR:"ioc.regex.cidr",FILEPATH:"ioc.regex.filepath",ONION:"ioc.regex.onion"},Hl=32,Ul=80;function ha(e){switch(e){case b.URL:return"Matched a visible URL in page text, including defanged hxxp and bracket-dot forms.";case b.SHA256:return"Matched a 64-character hexadecimal SHA-256 hash.";case b.SHA1:return"Matched a 40-character hexadecimal SHA-1 hash.";case b.MD5:return"Matched a 32-character hexadecimal MD5 hash.";case b.CVE:return"Matched a CVE identifier (CVE-YYYY-NNNN+).";case b.IPV4:return"Matched an IPv4 address in visible text, including bracket-dot defanged forms.";case b.DOMAIN:return"Matched a domain name in visible text, including bracket-dot defanged forms.";case b.EMAIL:return"Matched an email address in visible text.";case b.ASN:return"Matched an autonomous system number (AS/ASN prefix).";case b.CIDR:return"Matched an IPv4 CIDR network block.";case b.FILEPATH:return"Matched a conservative file path in visible text.";case b.ONION:return"Matched a Tor v3 onion service hostname.";default:return e}}function Ti(e){switch(e){case d.URL:return b.URL;case d.SHA256:return b.SHA256;case d.SHA1:return b.SHA1;case d.MD5:return b.MD5;case d.CVE:return b.CVE;case d.IPV4:return b.IPV4;case d.DOMAIN:return b.DOMAIN;case d.EMAIL:return b.EMAIL;case d.ASN:return b.ASN;case d.CIDR:return b.CIDR;case d.FILEPATH:return b.FILEPATH;case d.ONION:return b.ONION;default:return e}}function Vl(e,t,n,r={}){const o=r.radius??Hl,a=r.maxLength??Ul,i=Math.max(0,t-o),s=Math.min(e.length,n+o);let l=e.slice(i,s).replace(/\s+/g," ").trim();if(i>0&&(l=`…${l}`),s<e.length&&(l=`${l}…`),l.length<=a)return l;const u=e.slice(t,n),p=l.indexOf(u);if(p===-1)return l.slice(0,a-1)+"…";const f=Math.floor((a-u.length)/2),h=Math.max(0,p-f);let E=l.slice(h,h+a);return h>0&&(E=`…${E.replace(/^…/,"")}`),h+a<l.length&&(E=`${E.replace(/…$/,"")}…`),E}function xi(e,t,n,r,o,a,i){return{value:a,type:t,start:r,end:o,ruleId:n,sourceTextHint:Vl(e,r,o),...i?{displayValue:i}:{}}}const Fl=[{length:64,type:d.SHA256},{length:40,type:d.SHA1},{length:32,type:d.MD5}],W="(?:25[0-5]|2[0-4]\\d|1?\\d?\\d)",Pr="(?:\\[\\.\\]|\\(\\\\.\\)|\\[dot\\]|\\(dot\\))",Xn="(?:\\.|"+Pr+")",Bl=new RegExp(`(?<![\\d.])(${W}${Xn}${W}${Xn}${W}${Xn}${W})(?![\\d.])`,"gi"),nr="[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?",Li="(?:\\.|"+Pr+")",$l=new RegExp(`(?<![@/\\w.-])((?:${nr}${Li})+[a-zA-Z]{2,63})(?![@\\w.])`,"gi"),Gl="(?:https?|hxxps?)",zl="(?::\\/\\/|\\[:\\/\\/\\]|\\[:\\]\\/\\/)",Yl=`(?:[^\\s<>"'{}|\\\\^\\x60]|`+Pr+")",Kl=new RegExp(`(?<![\\w/])(${Gl}${zl}${Yl}+)`,"gi"),Wl=/(?<![A-Za-z0-9_-])(CVE-\d{4}-\d{4,})(?![A-Za-z0-9_-])/gi,jl=new Set(["bmp","css","csv","dll","doc","exe","gif","htm","html","ico","jpeg","jpg","js","json","jsx","log","map","md","pdf","png","svg","ts","tsx","txt","wasm","xml","yaml","yml"]),ql=[[10,0,0,0,10,255,255,255],[127,0,0,0,127,255,255,255],[169,254,0,0,169,254,255,255],[172,16,0,0,172,31,255,255],[192,168,0,0,192,168,255,255]];function Xl(e){return new RegExp(`(?<![0-9a-fA-F])([0-9a-fA-F]{${e}})(?![0-9a-fA-F])`,"g")}function Hr(e){const t=e.split(".");if(t.length!==4)return null;const n=[];for(const r of t){if(!/^\d{1,3}$/.test(r))return null;const o=Number(r);if(o>255)return null;n.push(o)}return n}function Ni(e){for(const t of ql){let n=!0;for(let r=0;r<4;r+=1)if(e[r]<t[r]||e[r]>t[r+4]){n=!1;break}if(n)return!0}return!1}function wi(e,t){const n=Math.max(0,t-24),r=e.slice(n,t).toLowerCase();return/(?:\bv|version\s+|release\s+|build\s+|engine\s+|from\s+version\s+)$/.test(r)}function Jl(e,t){return/^[-_][a-z0-9]/i.test(e.slice(t,t+6))}function Ql(e){const t=e.split(".");return t.length===4&&t.every(n=>n.length===1&&/^\d$/.test(n))}function Ri(e,t,n,r){if(!Ql(r))return!1;const o=e.slice(n,Math.min(e.length,n+24));if(!/^\s+to\s+\d+(?:\.\d+){0,3}\b/.test(o))return!1;const a=Math.max(0,t-20),i=e.slice(a,t).toLowerCase();return/\bfrom\s+$/.test(i)}function Zl(e,t){const n=Math.max(0,t-64),r=e.slice(n,t),o=r.lastIndexOf("@");if(o===-1)return!1;const a=r.slice(o+1);return!/\s/.test(a)}function eu(e){const t=e.toLowerCase();return/^(.)\1+$/.test(t)}function tu(e){const t=e.toUpperCase().split("-");if(t.length!==3||t[0]!=="CVE")return!1;const n=Number(t[1]),r=t[2];return!(!/^\d{4}$/.test(t[1])||!/^\d{4,}$/.test(r)||n<1999||n>2099)}function nu(e){return e.toUpperCase()}function ga(e){return e.replace(/[.,;:!?)]+$/g,"")}function Oe(e){return e.replace(/\[:\/\/\]/gi,"://").replace(/\[:]\/\//gi,"://").replace(/\[:]/gi,":").replace(/\[\.\]/g,".").replace(/\(\.\)/g,".").replace(/\[dot\]/gi,".").replace(/\(dot\)/gi,".").replace(/^hxxps:\/\//i,"https://").replace(/^hxxp:\/\//i,"http://")}function va(e){return Oe(e)}function ru(e){const t=e.split(".").pop()?.toLowerCase();return t!==void 0&&jl.has(t)}function Oi(e){return e.toLowerCase()==="localhost"}function ki(e){const t=e.split(".");if(t.length<2)return!1;for(const r of t)if(r.length<1||r.length>63||!/^[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?$/.test(r))return!1;const n=t[t.length-1];return/^[a-zA-Z]{2,63}$/.test(n)}function bn(e,t,n){return n.some(r=>e<r.end&&t>r.start)}function se(e,t,n,r,o,a){const i=t.flags.includes("g")?t.flags:`${t.flags}g`,s=new RegExp(t.source,i),l=[];let u=s.exec(e);for(;u!==null;){const p=u[1]??u[0],f=u.index+(u[0].length-p.length),h=a?a(p):p,E=f+p.length;o(h,f,E)&&l.push(xi(e,n,r,f,E,h,p!==h?p:void 0)),u=s.exec(e)}return l}function ou(e,t,n,r){return se(e,Xl(t),n,Ti(n),(o,a,i)=>!(o.length!==t||!/^[0-9a-f]+$/i.test(o)||eu(o)||bn(a,i,r)),o=>o.toLowerCase())}function Ur(e,t=[]){const n=[],r=[...t];for(const o of Fl){const a=ou(e,o.length,o.type,r);for(const i of a)n.push(i),r.push({start:i.start,end:i.end})}return n.sort((o,a)=>o.start-a.start)}function Vr(e,t=[]){return se(e,Wl,d.CVE,b.CVE,(n,r,o)=>!(!tu(n)||bn(r,o,t)),nu)}function Fr(e,t={}){const n=t.includePrivateIpv4??!1;return se(e,Bl,d.IPV4,b.IPV4,(r,o,a)=>{const i=Hr(r);return!(!i||!n&&Ni(i)||wi(e,o)||Jl(e,a)||Ri(e,o,a,r)||Eu(e,a))},Oe)}function Br(e){return se(e,Kl,d.URL,b.URL,t=>{const n=ga(t);if(n.length<10)return!1;try{const r=va(n),o=new URL(r);return o.protocol==="http:"||o.protocol==="https:"}catch{return!1}},t=>va(ga(t)))}function $r(e,t=[]){return se(e,$l,d.DOMAIN,b.DOMAIN,(n,r,o)=>{const a=n.toLowerCase();return!ki(n)||ru(n)?!1:Oi(a)?!0:!(Zl(e,r)||Su(n)||bn(r,o,t))},n=>Oe(n).toLowerCase())}const au="[a-zA-Z0-9][a-zA-Z0-9._%+-]{0,62}",iu=`${W}\\.${W}\\.${W}\\.${W}`,su=`(?:(?:${nr}${Li})+[a-zA-Z]{2,63}|${nr}|${iu})`,cu=new RegExp(`(?<![\\w.%+-])(${au}@${su})(?![\\w.%+-@])`,"gi"),lu=/(?<![A-Za-z0-9])(?:AS(?:N)?\s{0,3}(\d{1,10}))(?![A-Za-z0-9.])/gi,uu=new RegExp(`(?<![\\d.])((${W}\\.${W}\\.${W}\\.${W})/(3[0-2]|[12]?\\d))(?![\\d/])`,"gi"),du=/(?<![a-z2-7])([a-z2-7]{56}\.onion)(?![a-z2-7.])/gi,pu=/(?<![A-Za-z0-9])("?)([A-Za-z]:\\(?:[^\\/:*?"<>|\r\n\s]+\\)*[^\\/:*?"<>|\r\n\s]+)\1(?![A-Za-z0-9\\])/g,fu=/(?<![A-Za-z0-9])("?)(\\\\(?:[^\\/:*?"<>|\r\n\s]+\\)+[^\\/:*?"<>|\r\n\s]+)\1(?![A-Za-z0-9\\])/g,mu=/(?<![A-Za-z0-9/])("?)(\/(?:[^/:*?"<>|\r\n\s]+\/)+[^/:*?"<>|\r\n\s]+)\1(?![A-Za-z0-9/])/g,hu=["\\windows\\","\\program files\\","\\program files (x86)\\","\\programdata\\microsoft\\","\\programdata\\package cache\\","\\$recycle.bin\\","\\system volume information\\","\\recovery\\","\\windows\\system32\\","\\windows\\syswow64\\","\\windows\\servicing\\","\\windows\\installer\\","\\windows\\fonts\\","\\windows\\microsoft.net\\"],gu=["/bin/","/sbin/","/usr/bin/","/usr/sbin/","/usr/lib/","/usr/lib64/","/lib/","/lib64/","/etc/","/sys/","/proc/","/dev/","/boot/","/run/systemd/","/var/lib/dpkg/","/var/lib/rpm/","/var/lib/systemd/"],vu=new Set(["c$","admin$","ipc$"]);function Eu(e,t){return/^\/(?:3[0-2]|[12]?\d)\b/.test(e.slice(t))}function yu(e){return/^[a-z2-7]{56}\.onion$/i.test(e.toLowerCase())}function Su(e){return/\.onion$/i.test(e)}function Ea(e){const t=e.lastIndexOf("@");if(t<=0||t>=e.length-1)return null;const n=e.slice(0,t),r=Oe(e.slice(t+1)).toLowerCase();return n.length>64||/\s/.test(n)||!/^[a-zA-Z0-9][a-zA-Z0-9._%+-]*$/.test(n)||!ki(r)&&!/^[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?$/.test(r)&&!Hr(r)||Oi(r)?null:{local:n,domain:r}}function bu(e){return`AS${e}`}function Cu(e){if(!/^\d{1,10}$/.test(e))return!1;const t=Number(e);return Number.isInteger(t)&&t>=1&&t<=4294967295}function Au(e,t){const n=e.indexOf("/");if(n===-1)return!1;const r=e.slice(0,n),o=Number(e.slice(n+1));if(!Number.isInteger(o)||o<0||o>32)return!1;const a=Hr(r);return!(!a||!(t.includePrivateIpv4??!1)&&Ni(a))}function Pt(e){return e.startsWith('"')&&e.endsWith('"')&&e.length>=2?e.slice(1,-1):e}function Di(e){return Pt(e).replace(/\//g,"\\").toLowerCase()}function _u(e){return Pt(e).toLowerCase()}function Iu(e){return/[\r\n\t<>|*]/.test(e)||/\s/.test(e)}function Tu(e){return/^[%$]/.test(e)||/\$\{/.test(e)}function xu(e){const t=Pt(e);return t.startsWith(".")||t.startsWith("./")||t.startsWith(".\\")}function Lu(e){const t=Di(e),n=/^\\\\([^\\]+)\\([^\\]+)(?:\\|$)/.exec(t);return n?vu.has(n[2].toLowerCase()):!1}function ya(e){const t=Di(e);if(t.startsWith("\\\\?\\")||t.startsWith("\\\\.\\")||Lu(e))return!0;let n=t;/^[a-z]:\\/.test(t)&&(n=t.slice(2)),n.startsWith("\\")||(n=`\\${n}`);for(const r of hu)if(n.startsWith(r))return!0;return!1}function Nu(e){const t=_u(e);if(!t.startsWith("/")||t.split("/").filter(Boolean).length<2)return!0;for(const r of gu)if(t.startsWith(r))return!0;return!1}function wu(e){const t=Pt(e);return t.length===0||t.length>260||Iu(t)||Tu(t)||xu(t)||/^(?:https?|hxxps?|ftp|file):/i.test(t)||t.includes("://")?!1:/^[A-Za-z]:\\/.test(t)?t.slice(3).split(/[\\/]/).filter(Boolean).length<2?!1:!ya(t):t.startsWith("\\\\")?t.replace(/^\\\\+/,"").split(/[\\/]/).filter(Boolean).length<3?!1:!ya(t):t.startsWith("/")?!Nu(t):!1}function Ru(e){const t=[pu,fu,mu],n=[],r=[];for(const o of t){const a=new RegExp(o.source,o.flags.includes("g")?o.flags:`${o.flags}g`);let i=a.exec(e);for(;i!==null;){const s=i[2]??i[0],l=i.index+i[0].indexOf(s),u=l+s.length,p=Pt(s);wu(p)&&!bn(l,u,r)&&(n.push(xi(e,d.FILEPATH,b.FILEPATH,l,u,p,s!==p?s:void 0)),r.push({start:l,end:u})),i=a.exec(e)}}return n.sort((o,a)=>o.start-a.start)}function Gr(e){return se(e,cu,d.EMAIL,b.EMAIL,t=>Ea(Oe(t))!==null,t=>{const n=Ea(Oe(t));return n?`${n.local}@${n.domain}`:t})}function zr(e){return se(e,lu,d.ASN,b.ASN,t=>Cu(t.replace(/^AS/i,"")),bu)}function Yr(e,t={}){return se(e,uu,d.CIDR,b.CIDR,(n,r,o)=>!(!Au(n,t)||wi(e,r)||Ri(e,r,o,n.split("/")[0])))}function Kr(e){return se(e,du,d.ONION,b.ONION,t=>yu(t),t=>t.toLowerCase())}function Wr(e){return Ru(e)}const Ou=2048,ku=["type","value","iocType","sourceId","bypassCache"];new Set(ku);const Du=/<[a-z!/]/i;function Mu(e,t){switch(t){case d.IPV4:return Fr(e);case d.DOMAIN:return $r(e);case d.URL:return Br(e);case d.MD5:case d.SHA1:case d.SHA256:return Ur(e).filter(n=>n.type===t);case d.CVE:return Vr(e);case d.EMAIL:return Gr(e);case d.ASN:return zr(e);case d.CIDR:return Yr(e);case d.FILEPATH:return Wr(e);case d.ONION:return Kr(e);default:return[]}}function Mi(e,t){const n=e.trim();return n.length===0||n.length>Ou||/[\r\n\t]/.test(n)||Du.test(n)?null:Mu(n,t).find(a=>a.start===0&&a.end===n.length)?.value??null}function Pu(e){const t=Mi(e.value,e.type);return t?{value:t,type:e.type}:null}const Hu=["api.abuseipdb.com","otx.alienvault.com","urlscan.io","api.greynoise.io","www.virustotal.com","api.shodan.io","search.censys.io"];new Set(Hu);const jr=2,Uu=new Set(Object.values(d));function Vu(e,t,n){return`vera5-loc-${e}-${t}-${n}`}function Fu(e){return{schemaVersion:jr,pageUrl:e.pageUrl,scannedAt:e.scannedAt??Date.now(),entries:e.entries}}function Bu(e){return e.map(t=>({type:t.type,value:t.value,anchorId:Vu(t.type,t.start,t.end),ruleId:t.ruleId,sourceTextHint:t.sourceTextHint,...t.displayValue?{displayValue:t.displayValue}:{},...t.ignoredOverlaps&&t.ignoredOverlaps.length>0?{ignoredOverlaps:[...t.ignoredOverlaps]}:{}}))}function $u(e){return typeof e=="string"&&Uu.has(e)}function Gu(e){return typeof e.ruleId=="string"&&e.ruleId.length>0&&typeof e.sourceTextHint=="string"&&e.sourceTextHint.length>0}function zu(e,t){if(e===null||typeof e!="object")return!1;const n=e;return $u(n.type)&&typeof n.value=="string"&&n.value.length>0&&typeof n.anchorId=="string"&&n.anchorId.length>0?t>=jr?Gu(n):!0:!1}function Yu(e){if(e===null||typeof e!="object")return!1;const t=e,n=t.schemaVersion;return n!==1&&n!==jr||typeof t.pageUrl!="string"||typeof t.scannedAt!="number"||!Number.isFinite(t.scannedAt)||!Array.isArray(t.entries)?!1:t.entries.every(r=>zu(r,n))}const ce={GET_SELECTION_ACTION_STATE:"GET_SELECTION_ACTION_STATE",TAB_SCAN_SNAPSHOT:"TAB_SCAN_SNAPSHOT",GET_TAB_SCAN_SUMMARY:"GET_TAB_SCAN_SUMMARY",OPEN_OPTIONS_PAGE:"OPEN_OPTIONS_PAGE",OPEN_SITE_PERMISSIONS:"OPEN_SITE_PERMISSIONS",LIST_IOC_COLLECTIONS:"LIST_IOC_COLLECTIONS",CREATE_IOC_COLLECTION:"CREATE_IOC_COLLECTION",ADD_IOC_TO_COLLECTION:"ADD_IOC_TO_COLLECTION",ADD_IOCS_TO_COLLECTION:"ADD_IOCS_TO_COLLECTION"};function Ku(e){return{type:ce.TAB_SCAN_SNAPSHOT,snapshot:e}}function Pi(){return{type:ce.OPEN_OPTIONS_PAGE}}function Wu(){return{type:ce.OPEN_SITE_PERMISSIONS}}function ju(){return{type:ce.LIST_IOC_COLLECTIONS}}function qu(e){return{type:ce.CREATE_IOC_COLLECTION,name:e.name,...e.description?{description:e.description}:{}}}function Xu(e){return{type:ce.ADD_IOC_TO_COLLECTION,collectionId:e.collectionId,iocType:e.iocType,value:e.value}}function Ju(e){return{type:ce.ADD_IOCS_TO_COLLECTION,collectionId:e.collectionId,members:e.members}}function Qu(e){return{type:ce.GET_TAB_SCAN_SUMMARY}}const Zu=["Extension context invalidated","Receiving end does not exist","The message port closed before a response was received"],ed=["Access to storage is not allowed from this context"];function D(){if(typeof chrome>"u"||!chrome.runtime)return!1;try{return chrome.runtime.id,!1}catch{return!0}}function Hi(){return typeof chrome>"u"||!chrome.runtime?!1:!D()}function td(e){const t=e instanceof Error?e.message:typeof e=="string"?e:"";return t.length===0?!1:Zu.some(n=>t.includes(n))}function nd(e){const t=e instanceof Error?e.message:typeof e=="string"?e:"";return t.length===0?!1:ed.some(n=>t.includes(n))}function Me(e){return td(e)||nd(e)}const jt=160;function rd(e){if(e instanceof Error){const t=e.name.trim()||"Error";let n=e.message.trim();return n.length>jt&&(n=`${n.slice(0,jt)}…`),n.length>0?`${t}: ${n}`:t}if(typeof e=="string"){const t=e.trim();return t.length===0?"Vera5 extension error":t.length>jt?`${t.slice(0,jt)}…`:t}return"Vera5 extension error"}function _(e){Me(e)||console.error(rd(e))}function R(e){if(!Me(e))throw e}async function k(e){if(typeof chrome>"u"||!chrome.storage?.local)return{};if(D())return{};try{return await chrome.storage.local.get(e)}catch(t){if(Me(t))return{};throw t}}async function od(e){if(typeof chrome>"u"||!chrome.storage?.session)return{};if(D())return{};try{return await chrome.storage.session.get(e)}catch(t){if(Me(t))return{};throw t}}async function ad(e){if(typeof chrome>"u"||!chrome.storage?.session||D())return!1;try{return await chrome.storage.session.set(e),!0}catch(t){if(Me(t))return!1;throw t}}async function qr(e){if(typeof chrome>"u"||!chrome.storage?.local||D())return!1;try{return await chrome.storage.local.set(e),!0}catch(t){if(Me(t))return!1;throw t}}async function Xr(e){if(typeof chrome>"u"||!chrome.storage?.local||D())return!1;try{return await chrome.storage.local.remove(e),!0}catch(t){if(Me(t))return!1;throw t}}async function q(e){if(!Hi())return null;try{return await chrome.runtime.sendMessage(e)}catch(t){return R(t),null}}function Ui(){if(Hi()){if(typeof chrome.runtime.openOptionsPage=="function")try{chrome.runtime.openOptionsPage();return}catch(e){R(e)}q(Pi())}}function Cn(e){if(!D())try{e()}catch(t){R(t)}}async function ct(e){if(!D())try{await e()}catch(t){R(t)}}const Vi="allow_by_default",rr="deny_by_default";function Jr(e){return e.trim().toLowerCase()}function Ve(e){if(!Array.isArray(e))return[];const t=[],n=new Set;for(const r of e){if(typeof r!="string")continue;const o=Jr(r);!o||n.has(o)||(n.add(o),t.push(o))}return t}function Fi(e){return e===rr?rr:Vi}const Bi=["mail.*","webmail.*","outlook.office.com","outlook.live.com","mail.google.com","mail.yahoo.com"];function or(){return{mode:Vi,allowlist:[],denylist:[...Bi]}}function id(e){return{mode:Fi(e.mode),allowlist:Ve(e.allowlist),denylist:Ve(e.denylist)}}function $i(e,t){const n=e.trim().toLowerCase(),r=Jr(t);if(!n||!r)return!1;if(r.startsWith("*.")){const o=r.slice(2);return o?n===o||n.endsWith(`.${o}`):!1}if(r.endsWith(".*")){const o=r.slice(0,-2);return o?n===o||n.startsWith(`${o}.`):!1}return n===r}function ar(e,t){return t.some(n=>$i(e,n))}function sd(e,t){return ar(e,t.denylist)?!1:t.mode===rr?ar(e,t.allowlist):!0}let Zt=null;function cd(){return new Promise(e=>{Zt=e})}function ir(e){Zt&&(Zt(e),Zt=null)}function Gi(){ir({proceed:!1,rememberDismiss:!1})}function ld(e){return`Vera5 will query ${ud(e.sourceLabels)} with this ${e.typeLabel}: ${e.value}`}function ud(e){if(e.length===0)return"your enabled vendors";if(e.length===1)return e[0];if(e.length===2)return`${e[0]} and ${e[1]}`;const t=e.slice(0,-1).join(", "),n=e[e.length-1];return`${t}, and ${n}`}async function Z(e){if(e.length===0)return!1;if(typeof navigator<"u"&&navigator.clipboard?.writeText)try{return await navigator.clipboard.writeText(e),!0}catch{return Sa(e)}return Sa(e)}function Sa(e){if(typeof document>"u")return!1;const t=document.createElement("textarea");t.value=e,t.setAttribute("readonly",""),t.style.position="fixed",t.style.left="-9999px",document.body.appendChild(t),t.select();let n=!1;try{n=document.execCommand("copy")}catch{n=!1}return t.remove(),n}const At="analystNotes";function zi(){return typeof chrome<"u"&&chrome.storage?.local!==void 0&&!D()}function sr(e){if(e===null||typeof e!="object"||Array.isArray(e))return{};const t={};for(const[n,r]of Object.entries(e)){if(typeof n!="string"||typeof r!="string")continue;const o=n.trim(),a=r.trim();o.length===0||a.length===0||(t[o]=r)}return t}function j(e){return e.trim()}async function Qr(){if(!zi())return{};const e=await k(At);return sr(e[At])}async function dd(e){const t=j(e);return t.length===0?"":(await Qr())[t]??""}async function pd(e,t){if(!zi())return;const n=j(e);if(n.length===0)return;const r=await Qr();if(t.trim().length===0?delete r[n]:r[n]=t,Object.keys(r).length===0){await Xr(At);return}await qr({[At]:r})}const _t=new Map,Jn=new Map,fd=400;let Yi=!1;function Zr(){return typeof chrome<"u"&&chrome.storage?.local!==void 0&&!D()}function en(){Yi=!0}function eo(e){return j(e)}function Ki(e,t){const n=eo(e);if(t.trim().length===0){_t.delete(n);return}_t.set(n,t)}function md(e,t){if(!Zr())return;const n=eo(e),r=Jn.get(n);r&&clearTimeout(r),Jn.set(n,setTimeout(()=>{Jn.delete(n),pd(e,t).catch(R)},fd))}function It(e){return _t.get(eo(e))??""}function hd(e,t){Ki(e,t),md(e,t)}function Wi(e,t){Ki(e,t)}async function gd(){if(!Zr()){en();return}try{const e=await Qr();for(const[t,n]of Object.entries(e))_t.has(t)||_t.set(t,n);en()}catch(e){R(e),en()}}function vd(e,t){const n=It(e);if(n.length>0){t(n);return}if(!Yi){if(!Zr()){en();return}dd(e).then(r=>{r.length!==0&&(It(e).length>0||(Wi(e,r),t(r)))}).catch(R)}}function An(e,t){const n=It(e);return n.length>0?n:t??""}const g={ABUSEIPDB:"abuseipdb",OTX:"otx",URLSCAN:"urlscan",VIRUSTOTAL:"virustotal",GREYNOISE:"greynoise",SHODAN:"shodan",GOOGLE_SAFE_BROWSING:"google_safe_browsing",PULSEDIVE:"pulsedive",MALWAREBAZAAR:"malwarebazaar",CENSYS:"censys",THREATFOX:"threatfox",URLHAUS:"urlhaus"},x=[g.ABUSEIPDB,g.OTX,g.VIRUSTOTAL,g.URLSCAN,g.GREYNOISE,g.SHODAN,g.GOOGLE_SAFE_BROWSING,g.PULSEDIVE,g.MALWAREBAZAAR,g.CENSYS,g.THREATFOX,g.URLHAUS],Ed=new Set(x),to="censys_secret",yd=[...x,to],Qn=[d.IPV4,d.DOMAIN,d.URL,d.MD5,d.SHA1,d.SHA256,d.CVE],cr=[d.MD5,d.SHA1,d.SHA256],Sd=[d.IPV4,d.DOMAIN,d.URL];function P(e){return encodeURIComponent(e.trim())}function Ze(e){return e.replace(/^hxxps?:\/\//i,t=>t.toLowerCase().startsWith("hxxps")?"https://":"http://")}function bd(e,t){const n=t.trim();switch(e){case d.IPV4:return`https://www.virustotal.com/gui/ip-address/${n}`;case d.DOMAIN:return`https://www.virustotal.com/gui/domain/${P(n)}`;case d.URL:return`https://www.virustotal.com/gui/search/${P(Ze(n))}`;case d.MD5:case d.SHA1:case d.SHA256:return`https://www.virustotal.com/gui/file/${n.toLowerCase()}`;case d.CVE:return`https://www.virustotal.com/gui/search/${P(n)}`;case d.EMAIL:case d.ASN:case d.CIDR:case d.FILEPATH:return`https://www.virustotal.com/gui/search/${P(n)}`;case d.ONION:return`https://www.virustotal.com/gui/domain/${P(n)}`;default:return null}}function Cd(e,t){const n=t.trim();switch(e){case d.IPV4:return`https://otx.alienvault.com/indicator/ip/${n}`;case d.DOMAIN:return`https://otx.alienvault.com/indicator/domain/${P(n)}`;case d.URL:return`https://otx.alienvault.com/indicator/url/${P(Ze(n))}`;case d.MD5:case d.SHA1:case d.SHA256:return`https://otx.alienvault.com/indicator/file/${n.toLowerCase()}`;case d.CVE:return`https://otx.alienvault.com/indicator/cve/${P(n)}`;case d.EMAIL:return`https://otx.alienvault.com/indicator/email/${P(n)}`;case d.ONION:return`https://otx.alienvault.com/indicator/domain/${P(n)}`;default:return null}}function Ad(e,t){return e!==d.IPV4?null:`https://www.abuseipdb.com/check/${P(t.trim())}`}function _d(e,t){const n=t.trim();switch(e){case d.IPV4:return`https://urlscan.io/search/#ip:${encodeURIComponent(n)}`;case d.DOMAIN:return`https://urlscan.io/search/#domain:${encodeURIComponent(n)}`;case d.URL:return`https://urlscan.io/search/#page.url:"${encodeURIComponent(Ze(n))}"`;case d.MD5:case d.SHA1:case d.SHA256:return`https://urlscan.io/search/#hash:${encodeURIComponent(n.toLowerCase())}`;case d.ONION:return`https://urlscan.io/search/#domain:${encodeURIComponent(n)}`;default:return null}}function Id(e,t){return e!==d.IPV4?null:`https://viz.greynoise.io/ip/${P(t.trim())}`}function Td(e,t){const n=t.trim();switch(e){case d.IPV4:return`https://www.shodan.io/host/${P(n)}`;case d.DOMAIN:return`https://www.shodan.io/search?query=${encodeURIComponent(n)}`;case d.ASN:{const r=n.replace(/^AS/i,"");return`https://www.shodan.io/search?query=${encodeURIComponent(`asn:${r}`)}`}case d.CIDR:return`https://www.shodan.io/search?query=${encodeURIComponent(`net:${n}`)}`;default:return null}}function xd(e,t){const n=t.trim();return e===d.URL?`https://pulsedive.com/explore?q=${encodeURIComponent(Ze(n))}`:`https://pulsedive.com/explore?q=${encodeURIComponent(n)}`}function Ld(e,t){return cr.includes(e)?`https://bazaar.abuse.ch/browse.php?search=sha256:${encodeURIComponent(t.trim().toLowerCase())}`:null}function Nd(e,t){const n=t.trim();switch(e){case d.IPV4:return`https://search.censys.io/hosts/${P(n)}`;case d.DOMAIN:return`https://search.censys.io/domains/${P(n)}`;default:return null}}function wd(e,t){const n=t.trim();return e===d.URL?`https://threatfox.abuse.ch/browse.php?search=ioc:${encodeURIComponent(Ze(n))}`:`https://threatfox.abuse.ch/browse.php?search=ioc:${encodeURIComponent(n)}`}function Rd(e,t){if(e!==d.URL&&e!==d.DOMAIN)return null;const n=e===d.URL?Ze(t.trim()):t.trim();return`https://urlhaus.abuse.ch/browse.php?search=${encodeURIComponent(n)}`}const le={[g.ABUSEIPDB]:{id:g.ABUSEIPDB,displayName:"AbuseIPDB",description:"IP reputation and abuse confidence scoring.",supportedIndicatorTypes:[d.IPV4],requiresApiKey:!0,settingsKeyName:"ABUSEIPDB_API_KEY",cacheKeyNamespace:"abuseipdb",enabledDefault:!1,liveConnector:!0,buildPivotUrl:Ad},[g.OTX]:{id:g.OTX,displayName:"OTX",description:"AlienVault Open Threat Exchange pulses.",supportedIndicatorTypes:Qn,requiresApiKey:!0,settingsKeyName:"OTX_API_KEY",cacheKeyNamespace:"otx",enabledDefault:!1,liveConnector:!0,buildPivotUrl:Cd},[g.VIRUSTOTAL]:{id:g.VIRUSTOTAL,displayName:"VirusTotal",description:"Multi-vendor file, URL, domain, and IP reputation.",supportedIndicatorTypes:Qn,requiresApiKey:!0,settingsKeyName:"VT_API_KEY",cacheKeyNamespace:"virustotal",enabledDefault:!1,liveConnector:!1,buildPivotUrl:bd},[g.URLSCAN]:{id:g.URLSCAN,displayName:"URLScan.io",description:"URL and domain scan intelligence.",supportedIndicatorTypes:[d.DOMAIN,d.URL],requiresApiKey:!0,settingsKeyName:"URLSCAN_API_KEY",cacheKeyNamespace:"urlscan",enabledDefault:!1,liveConnector:!0,buildPivotUrl:_d},[g.GREYNOISE]:{id:g.GREYNOISE,displayName:"GreyNoise",description:"Internet background-noise context for IP addresses.",supportedIndicatorTypes:[d.IPV4],requiresApiKey:!0,settingsKeyName:"GREYNOISE_API_KEY",cacheKeyNamespace:"greynoise",enabledDefault:!1,liveConnector:!0,buildPivotUrl:Id},[g.SHODAN]:{id:g.SHODAN,displayName:"Shodan",description:"Internet-wide exposure and service intelligence.",supportedIndicatorTypes:[d.IPV4,d.DOMAIN],requiresApiKey:!0,settingsKeyName:"SHODAN_API_KEY",cacheKeyNamespace:"shodan",enabledDefault:!1,liveConnector:!0,buildPivotUrl:Td},[g.GOOGLE_SAFE_BROWSING]:{id:g.GOOGLE_SAFE_BROWSING,displayName:"Google Safe Browsing",description:"Google threat lists for malicious URLs and domains.",supportedIndicatorTypes:[d.URL,d.DOMAIN],requiresApiKey:!0,settingsKeyName:"GOOGLE_SAFE_BROWSING_API_KEY",cacheKeyNamespace:"google_safe_browsing",enabledDefault:!1,liveConnector:!1},[g.PULSEDIVE]:{id:g.PULSEDIVE,displayName:"Pulsedive",description:"Threat intelligence context for IOCs and assets.",supportedIndicatorTypes:Qn,requiresApiKey:!0,settingsKeyName:"PULSEDIVE_API_KEY",cacheKeyNamespace:"pulsedive",enabledDefault:!1,liveConnector:!1,buildPivotUrl:xd},[g.MALWAREBAZAAR]:{id:g.MALWAREBAZAAR,displayName:"MalwareBazaar",description:"Abuse.ch malware sample hash intelligence.",supportedIndicatorTypes:cr,requiresApiKey:!0,settingsKeyName:"MALWAREBAZAAR_API_KEY",cacheKeyNamespace:"malwarebazaar",enabledDefault:!1,liveConnector:!1,buildPivotUrl:Ld},[g.CENSYS]:{id:g.CENSYS,displayName:"Censys",description:"Internet asset and certificate search.",supportedIndicatorTypes:[d.IPV4,d.DOMAIN],requiresApiKey:!0,secondaryApiKeySlot:to,settingsKeyName:"CENSYS_API_KEY",secondarySettingsKeyName:"CENSYS_SECRET",cacheKeyNamespace:"censys",enabledDefault:!1,liveConnector:!0,buildPivotUrl:Nd},[g.THREATFOX]:{id:g.THREATFOX,displayName:"ThreatFox",description:"Abuse.ch IOC sharing for malware campaigns.",supportedIndicatorTypes:[...Sd,...cr],requiresApiKey:!0,settingsKeyName:"THREATFOX_API_KEY",cacheKeyNamespace:"threatfox",enabledDefault:!1,liveConnector:!1,buildPivotUrl:wd},[g.URLHAUS]:{id:g.URLHAUS,displayName:"URLHaus",description:"Abuse.ch malicious URL distribution tracking.",supportedIndicatorTypes:[d.URL,d.DOMAIN],requiresApiKey:!0,settingsKeyName:"URLHAUS_API_KEY",cacheKeyNamespace:"urlhaus",enabledDefault:!1,liveConnector:!1,buildPivotUrl:Rd}},et=Object.fromEntries(x.map(e=>[e,le[e].displayName]));Object.fromEntries(x.map(e=>[e,le[e].description]));const ji=x.filter(e=>le[e].liveConnector);x.filter(e=>le[e].requiresApiKey);function Od(e){return Ed.has(e)}function kd(e){return Od(e)||e===to}function Dd(e){return le[e]}function Md(e,t){return le[e].supportedIndicatorTypes.includes(t)}function Pd(e){return`${e} is disabled. Enable it in extension settings to load enrichment.`}function Hd(e,t,n){const r=le[e].buildPivotUrl;return r?r(t,n):null}const lr="Threat intelligence summary is not available yet.",Ud="Loading threat intelligence…",no="Threat intelligence could not be loaded.";function qi(e,t){return t==="error"?`Source: ${e.sourceLabel}`:e.fromCache?`Source: ${e.sourceLabel} · cached`:`Source: ${e.sourceLabel} · live`}function Vd(e,t,n){return Ht(n)||!t?.sourceLabel.trim()?!1:e==="ready"||e==="error"}const Fd="Open settings",Bd="Raw response",$d="Analyst notes",Gd="Add local notes for this indicator…",zd="Analyst notes",ro="vera5-analyst-notes-input",Yd="Label",Kd="Indicator label",Xi="vera5-ioc-label-select",ht="",Wd="Session timeline",jd="Session timeline for this indicator",qd="No session timeline for this indicator yet.",Xd="Pin",Jd="Pinned",Qd="Pin indicator for triage priority",Ji="Enrichment uses your API keys and sends only the selected indicator value to vendors you enable—not the full page.",Qi="The risk label is computed locally from available source signals. It is advisory only; review each source before acting.";function oo(e={}){const t=[],n=e.enrichmentState??"empty";return(n==="ready"||n==="loading"||n==="error")&&t.push(Ji),e.includeRiskScoreDisclaimer&&t.push(Qi),t}const Zd="Enrichment and risk score notice",ba="Enrichment notice";function ep(e={}){const t=oo(e),n=t.includes(Qi),r=t.includes(Ji);return n&&r?Zd:r?ba:n?"Risk score notice":ba}function Zi(e,t){if(e?.sourceLabel.trim())return e;if(t.length!==1)return;const n=t[0];if(n?.label.trim())return{sourceLabel:n.label,fromCache:n.fromCache}}function tp(e,t,n){return Ht(n)?!1:e==="error"&&t==="missing_key"}function np(e,t,n){return Ht(n)?!1:e==="error"&&!!t?.trim()}function ao(e){return x.filter(n=>e.includes(n)).map(n=>{const r=et[n];return{sourceId:n,label:r,message:Pd(r)}})}function rp(e){const t=e.trim();if(!t)return;const n=new Date(t);if(!Number.isNaN(n.getTime()))return new Intl.DateTimeFormat(void 0,{dateStyle:"medium",timeStyle:"short"}).format(n)}function op(e){const t=e?rp(e):void 0;if(t)return`Last updated: ${t}`}function es(e,t){return e==="ok"?t===!0?"Cached":"Live":e==="error"?"Error":"Skipped"}function ap(e,t){return e==="ok"&&t===!0?"vera5-hover-card-source-badge vera5-hover-card-source-badge--cached":`vera5-hover-card-source-badge vera5-hover-card-source-badge--${e}`}function ip(e){if(!Ht(e))return e?.[0]?.lastUpdatedLine}function sp(e){return x.includes(e)}function cp(e){return e.status==="ok"?e.summary?.trim()||lr:e.errorMessage?.trim()||(e.status==="skipped"?"Enrichment was not available for this source.":no)}function lp(e){if(!sp(e.sourceId))return null;const t=e.status==="ok"&&e.fromCache===!0,n={sourceId:e.sourceId,label:e.sourceLabel.trim()||et[e.sourceId],status:e.status,fromCache:t,badgeText:es(e.status,t),detail:cp(e)},r=op(e.fetchedAt);r&&(n.lastUpdatedLine=r);const o=e.tags?.map(i=>i.trim()).filter(i=>i.length>0);o&&o.length>0&&(n.tags=o),e.errorCode&&(n.errorCode=e.errorCode),e.retryHint&&(n.retryHint=e.retryHint);const a=e.rawVendorJson?.trim();return a&&e.status==="ok"&&(n.rawVendorJson=a),n}function up(e){const t=e??[];return t.length===1&&!!t[0]?.rawVendorJson?.trim()}function ts(e){const t=new Map;for(const n of e){const r=lp(n);r&&t.set(r.sourceId,r)}return x.flatMap(n=>{const r=t.get(n);return r?[r]:[]})}function Ht(e){return(e?.length??0)>1}function io(e){return x.every(t=>e.includes(t))}function dp(e,t){return io(e??[])?!1:(t?.length??0)>0}function pp(e,t){return io(e??[])?!0:(t?.length??0)>0}function fp(e,t){return dp(e,t)}function mp(e={}){return oo(e).length>0}function ns(e){const t=ts(e);if(t.length===0)return{enrichmentState:"error",errorMessage:no,sourceResults:[]};const n=t.filter(o=>o.status==="ok");if(n.length>0){const o=n[0];return{enrichmentState:"ready",summary:o.detail,tags:o.tags,sourceAttribution:t.length===1?{sourceLabel:o.label,fromCache:o.fromCache}:void 0,sourceResults:t}}const r=t[0];return{enrichmentState:"error",summary:r.detail,errorMessage:r.detail,errorCode:r.errorCode,retryHint:r.retryHint,sourceAttribution:{sourceLabel:r.label},sourceResults:t}}function hp(e){const t=e.enrichmentState??"empty";return t==="loading"?{text:Ud,variant:"loading"}:t==="error"?{text:e.errorMessage?.trim()||no,variant:"error"}:t==="ready"?{text:e.summary?.trim()||lr,variant:"ready"}:{text:e.summary?.trim()||lr,variant:"empty"}}function gp(e){const t=e.sourceResults??[],n=e.disabledSources??[],r=hp({enrichmentState:e.enrichmentState,summary:e.summary,errorMessage:e.errorMessage}),o=ao(n),a=(e.tags??[]).map(J=>J.trim()).filter(J=>J.length>0),i=r.variant==="ready"&&a.length>0,s=Ht(t),l=up(t),u=l?t[0]?.rawVendorJson:void 0,p=Vd(r.variant,Zi(e.sourceAttribution,t),t),f=tp(r.variant,e.errorCode,t),h=np(r.variant,e.retryHint,t),E=ip(t),S=pp(n,t),L=fp(n,t),z={enrichmentState:r.variant,includeRiskScoreDisclaimer:L},m=oo(z),V=mp(z),X=(e.pivotLinkCount??0)>0,A=X||o.length>0||s;return{enrichment:r,enrichmentTags:a,showTags:i,showMultiSourceResults:s,showSingleSourceRawJson:l,singleSourceRawJson:u,showAttribution:p,showMissingKeyAction:f,showRateLimitRetryHint:h,singleSourceLastUpdatedLine:E,showRiskScore:S,includeRiskScoreDisclaimer:L,disclaimerLines:m,showDisclaimer:V,showFooter:A,showBelowSummary:A||i||!!(l&&u)||p||f||h||!!E||S||V,disabledSourcePlaceholders:o,hasPivotLinks:X}}const rs="Why detected?",vp="Why detected?",Ep={[d.IPV4]:"IPv4 address",[d.DOMAIN]:"Domain",[d.URL]:"URL",[d.MD5]:"MD5 hash",[d.SHA1]:"SHA1 hash",[d.SHA256]:"SHA256 hash",[d.CVE]:"CVE ID",[d.EMAIL]:"Email address",[d.ASN]:"ASN",[d.CIDR]:"IPv4 CIDR",[d.FILEPATH]:"File path",[d.ONION]:"Onion domain"};function Ca(e){return Ep[e]}function os(e){return!e.ruleId||!e.sourceTextHint?null:{typeLabel:Ca(e.type),reason:ha(e.ruleId),sourceTextHint:e.sourceTextHint,ignoredOverlaps:(e.ignoredOverlaps??[]).map(t=>({typeLabel:Ca(t.type),value:t.value,reason:ha(t.ruleId)}))}}const yp="On page:",as="Refanged:",Sp="Copy Indicator",bp="Copy defanged",Cp="Copy refanged",Ap="Copied",Aa="Open live URL",_p="This opens the live URL in a new browser tab. The destination may be malicious or unreachable. Continue?",Ip="Pre-query notice",Tp="Before querying vendors",_a="Send query",Ia="Cancel",Ta="Don't show this notice again";function so(e){const t=e.value,n=e.displayValue??e.value;return{onPageValue:n,refangedValue:t,showRefangedPair:n!==t}}function xp(e){return e.showRefangedPair?[{copyValue:e.onPageValue,label:bp,ariaLabel:`Copy defanged indicator ${e.onPageValue}`},{copyValue:e.refangedValue,label:Cp,ariaLabel:`Copy refanged indicator ${e.refangedValue}`}]:[{copyValue:e.refangedValue,label:Sp,ariaLabel:`Copy indicator ${e.refangedValue}`}]}function Lp(e){return e===d.URL}function Np(e=window){return e.confirm(_p)}function wp(e,t=window){t.open(e,"_blank","noopener,noreferrer")}const v={ABUSEIPDB:g.ABUSEIPDB,OTX:g.OTX,VIRUSTOTAL:g.VIRUSTOTAL,URLSCAN:g.URLSCAN,GREYNOISE:g.GREYNOISE,SHODAN:g.SHODAN,PULSEDIVE:g.PULSEDIVE,MALWAREBAZAAR:g.MALWAREBAZAAR,CENSYS:g.CENSYS,THREATFOX:g.THREATFOX,URLHAUS:g.URLHAUS},Rp=x.filter(e=>e!==g.GOOGLE_SAFE_BROWSING);function is(e,t){return!t?.enabledSourceIds||t.showDisabledSources===!0?!0:t.enabledSourceIds.includes(e)}function ss(e,t,n){return Hd(e,t,n)}function Op(e,t,n){const r=[];for(const o of Rp){if(!is(o,n))continue;const a=ss(o,e,t);a&&r.push({provider:o,label:et[o],href:a})}return r}function kp(e,t){if(!t||t.length===0)return[...e];const n=new Map(t.map((r,o)=>[r,o]));return[...e].sort((r,o)=>{const a=n.get(r.provider)??Number.MAX_SAFE_INTEGER,i=n.get(o.provider)??Number.MAX_SAFE_INTEGER;return a!==i?a-i:0})}const Zn=[{provider:v.VIRUSTOTAL,guidance:"Compare file detections and sandbox behavior."},{provider:v.OTX,guidance:"Review pulses and related indicators for the hash."},{provider:v.MALWAREBAZAAR,guidance:"Look up sample metadata and delivery context."},{provider:v.URLSCAN,guidance:"Find pages or downloads referencing the hash."},{provider:v.THREATFOX,guidance:"Review shared campaign IOC context."}],Dp={[d.IPV4]:[{provider:v.ABUSEIPDB,guidance:"Check abuse confidence and network ownership."},{provider:v.OTX,guidance:"Review community pulses and related indicators."},{provider:v.VIRUSTOTAL,guidance:"Compare detections across vendors."},{provider:v.GREYNOISE,guidance:"Check whether traffic is internet background noise."},{provider:v.SHODAN,guidance:"Review exposed services and host metadata."},{provider:v.URLSCAN,guidance:"Search related scans and hosting context."},{provider:v.CENSYS,guidance:"Inspect certificates and host exposure."},{provider:v.PULSEDIVE,guidance:"Explore related threat context for the IP."},{provider:v.THREATFOX,guidance:"Review shared campaign IOC context."}],[d.DOMAIN]:[{provider:v.VIRUSTOTAL,guidance:"Review domain reputation and DNS records."},{provider:v.OTX,guidance:"Check passive DNS and threat pulses."},{provider:v.URLSCAN,guidance:"Find pages and certificates tied to the domain."},{provider:v.SHODAN,guidance:"Search related hosts and DNS records."},{provider:v.PULSEDIVE,guidance:"Explore domain threat context and risk."},{provider:v.CENSYS,guidance:"Review certificates and DNS history."},{provider:v.URLHAUS,guidance:"Check known malicious URL distribution."}],[d.URL]:[{provider:v.URLSCAN,guidance:"Inspect page content, redirects, and resources."},{provider:v.VIRUSTOTAL,guidance:"Review URL reputation and related files."},{provider:v.OTX,guidance:"Check pulses and related indicators for the URL."},{provider:v.PULSEDIVE,guidance:"Explore URL threat context and risk."},{provider:v.URLHAUS,guidance:"Check known malicious URL distribution."},{provider:v.THREATFOX,guidance:"Review shared campaign IOC context."}],[d.MD5]:Zn,[d.SHA1]:Zn,[d.SHA256]:Zn,[d.CVE]:[{provider:v.VIRUSTOTAL,guidance:"Search vendor coverage and related indicators."},{provider:v.OTX,guidance:"Review pulses and advisories for the CVE."},{provider:v.PULSEDIVE,guidance:"Explore CVE threat context and related IOCs."}],[d.EMAIL]:[{provider:v.VIRUSTOTAL,guidance:"Search multi-vendor reports for the address."},{provider:v.OTX,guidance:"Review pulses and related indicators for the email."},{provider:v.PULSEDIVE,guidance:"Explore threat context for the address."},{provider:v.THREATFOX,guidance:"Review shared campaign IOC context."}],[d.ASN]:[{provider:v.VIRUSTOTAL,guidance:"Search vendor coverage and network context for the ASN."},{provider:v.SHODAN,guidance:"Review hosts and services announced by the ASN."},{provider:v.PULSEDIVE,guidance:"Explore ASN threat context and related assets."},{provider:v.THREATFOX,guidance:"Review shared campaign IOC context."}],[d.CIDR]:[{provider:v.VIRUSTOTAL,guidance:"Search vendor coverage for the network block."},{provider:v.SHODAN,guidance:"Find exposed hosts within the CIDR range."},{provider:v.PULSEDIVE,guidance:"Explore network threat context for the block."}],[d.FILEPATH]:[{provider:v.VIRUSTOTAL,guidance:"Search for files or reports referencing the path string."},{provider:v.PULSEDIVE,guidance:"Explore related threat context for the path token."},{provider:v.THREATFOX,guidance:"Review shared campaign IOC context."}],[d.ONION]:[{provider:v.VIRUSTOTAL,guidance:"Review domain reputation and related files for the onion host."},{provider:v.OTX,guidance:"Check passive DNS and threat pulses for the hostname."},{provider:v.URLSCAN,guidance:"Find scans referencing the onion hostname."},{provider:v.PULSEDIVE,guidance:"Explore threat context for the onion service."},{provider:v.THREATFOX,guidance:"Review shared campaign IOC context."}]};function cs(e,t,n){const r=Dp[e]??[],o=[];for(const a of r){if(!is(a.provider,n))continue;const i=ss(a.provider,e,t);if(!i)continue;const s=et[a.provider];o.push({provider:a.provider,sourceLabel:s,label:s,href:i,guidance:a.guidance})}return kp(o,n?.emphasisProviders)}const _n={OK:"ok",ERROR:"error",SKIPPED:"skipped"},In={MISSING_KEY:"missing_key",UNAUTHORIZED:"unauthorized",RATE_LIMITED:"rate_limited",TIMEOUT:"timeout",UNSUPPORTED_TYPE:"unsupported_type",NETWORK:"network_error",DISABLED:"disabled",DOMAIN_POLICY:"domain_policy",INTERNAL_ASSET:"internal_asset",VENDOR:"vendor_error"},Mp={OK:"ok",ERROR:"error"};new Set(Object.values(Mp));const Pp=new Set(Object.values(_n)),Hp=new Set(Object.values(In));new Set(Object.values(d));function Up(e){return typeof e!="string"||e.trim().length===0?!1:!Number.isNaN(Date.parse(e))}function ls(e){if(!Array.isArray(e))return;const t=e.filter(n=>typeof n=="string").map(n=>n.trim()).filter(n=>n.length>0);return t.length>0?t:void 0}function Vp(e){return typeof e=="string"&&Pp.has(e)}function Fp(e){return typeof e=="string"&&Hp.has(e)}function Bp(e){if(typeof e!="object"||e===null)return!1;const t=e;return!(typeof t.sourceId!="string"||typeof t.sourceLabel!="string"||!Vp(t.status)||t.summary!==void 0&&typeof t.summary!="string"||t.tags!==void 0&&ls(t.tags)===void 0||t.errorCode!==void 0&&!Fp(t.errorCode)||t.errorMessage!==void 0&&typeof t.errorMessage!="string"||t.retryHint!==void 0&&typeof t.retryHint!="string"||t.fetchedAt!==void 0&&!Up(t.fetchedAt)||t.fromCache!==void 0&&typeof t.fromCache!="boolean"||t.rawVendorJson!==void 0&&typeof t.rawVendorJson!="string")}function $p(e){if(!Bp(e))return null;const t=e,n={sourceId:t.sourceId,sourceLabel:t.sourceLabel.trim(),status:t.status},r=t.summary?.trim();r&&(n.summary=r);const o=ls(t.tags);o&&(n.tags=o),t.errorCode&&(n.errorCode=t.errorCode);const a=t.errorMessage?.trim();a&&(n.errorMessage=a);const i=t.retryHint?.trim();i&&(n.retryHint=i),t.fetchedAt&&(n.fetchedAt=t.fetchedAt),t.fromCache===!0&&(n.fromCache=!0);const s=t.rawVendorJson?.trim();return s&&(n.rawVendorJson=s),n}const H={UNKNOWN:"unknown",LOW:"low",SUSPICIOUS:"suspicious",HIGH:"high",CRITICAL:"critical"},us="Sources disagree: compare per-source details before deciding.";function ds(e){return e===H.UNKNOWN?"Unknown":e===H.LOW?"Low":e===H.SUSPICIOUS?"Suspicious":e===H.HIGH?"High":"Critical"}function Gp(e){if(e.signalStrength===null||e.bandLabel===null)return`${e.sourceLabel}: no weighted signal (${e.status}).`;const t=Math.round(e.signalStrength),n=ds(e.bandLabel);return`${e.sourceLabel}: ${n} (${t}/100, weight ${e.weight.toFixed(2)}).`}function zp(e){const t=ds(e.label);return e.compositeSignal===null?`${t} risk`:`${t} risk (${Math.round(e.compositeSignal)}/100)`}function Yp(e){return{sourceLines:e.sources.map(Gp),showDisagreement:e.disagreement,disagreementLine:us}}const co="How this score was computed",Kp=co,Wp="vera5-hover-card-risk-reasoning",jp="vera5-hover-card-risk-reasoning-heading",qp="vera5-hover-card-risk-reasoning-chain",Xp="vera5-hover-card-risk-reasoning-step",Jp="vera5-hover-card-risk-reasoning-empty",Qp="Blended score steps are not available until at least two sources return parseable evidence.",Zp="No per-source scoring signals are available to show a reasoning chain.";function ps(e,t){return t?{mode:"empty",detail:Qp}:e.score.sources.filter(r=>r.signalStrength!==null).length===0?{mode:"empty",detail:Zp}:{mode:"chain",chain:e.chain,sourceIds:e.score.sources.map(r=>r.sourceId)}}function ef(e,t){const n=t.createElement("section");n.className=Wp,n.setAttribute("aria-label",Kp);const r=t.createElement("p");if(r.className=jp,r.textContent=co,n.appendChild(r),e.mode==="empty"){const a=t.createElement("p");return a.className=Jp,a.setAttribute("role","note"),a.textContent=e.detail,n.appendChild(a),n}const o=t.createElement("ol");o.className=qp;for(const a of e.chain.sourceLines){const i=t.createElement("li");i.className=Xp,i.textContent=a,o.appendChild(i)}return n.appendChild(o),n}function tf(e){return e.map(t=>({sourceId:t.sourceId,sourceLabel:t.label,status:t.status,summary:t.status==="ok"?t.detail:void 0}))}function nf(e,t={}){return _f(tf(e),t)}function rf(e,t={}){const n=nf(e,t);return{score:n,summaryText:zp(n),chain:Yp(n)}}const Tn="Risk score unavailable",of="Enable at least one enrichment source in settings to compute a local advisory score.",af="At least two enabled sources must return parseable evidence for a blended composite score. Review per-source details below.";function sf(e){return e.compositeSignal!==null}function fs(e,t,n={}){if(io(e))return{mode:"unavailable",headline:Tn,detail:of};if(t.length===0)return null;const r=rf(t,n);return{mode:"score",view:r,insufficientCompositeNotice:sf(r.score)?null:af}}const cf=/^(\d+)\s+abuse\s+confidence$/,lf=/^(\d+)\s+reports$/,uf=/^1\s+threat\s+pulse$/,df=/^(\d+)\s+threat\s+pulses$/,pf=/^1\s+urlscan\s+result$/,ff=/^(\d+)\s+urlscan\s+results$/,mf=/^(\w+)\s+internet\s+noise$/,hf=/^(\w+)\s+classification$/,gf="not observed in GreyNoise",vf="benign RIOT service",Ef=Object.fromEntries(x.map(e=>[e,e===g.OTX?.85:1])),yf=2;function Y(e){return Number.isFinite(e)?Math.min(100,Math.max(0,e)):0}function Sf(e){if(!e)return null;const t=e.trim();let n=cf.exec(t);if(n)return Y(Number(n[1]));if(n=lf.exec(t),n){const r=Number(n[1]);return Y(ms(r))}if(uf.test(t))return Y(xa(1));if(n=df.exec(t),n){const r=Number(n[1]);return Y(xa(r))}if(pf.test(t))return Y(La(1));if(n=ff.exec(t),n){const r=Number(n[1]);return Y(La(r))}return t===vf?Y(8):t===gf?Y(5):(n=mf.exec(t),n||(n=hf.exec(t),n)?Y(Na(n[1])):null)}function ms(e){return e<=0?0:e===1?22:e<=3?38:e<=8?54:e<=20?68:e<=45?82:Math.min(100,88+Math.floor((e-45)/30))}function xa(e){return e<=0?0:e===1?26:e<=4?42:e<=12?56:e<=35?71:Math.min(100,78+Math.min(22,Math.floor((e-35)/8)))}function La(e){return ms(e)}function Na(e){const t=e.trim().toLowerCase();return t==="malicious"?72:t==="benign"?12:t==="unknown"?45:35}function wa(e){if(e===null||!Number.isFinite(e))return null;const t=Y(e);return t<=24?H.LOW:t<=49?H.SUSPICIOUS:t<=74?H.HIGH:H.CRITICAL}function bf(e,t){const n=t?.[e];return typeof n=="number"&&Number.isFinite(n)?Math.max(0,n):Ef[e]}function Cf(e,t){if(t.length<2)return!1;if(Math.max(...t)-Math.min(...t)>=35)return!0;const n=e.map(o=>o.bandLabel).filter(o=>o!==null);if(n.length<2)return!1;const r=n.map(Af);return Math.max(...r)-Math.min(...r)>=2}function Af(e){switch(e){case H.LOW:return 0;case H.SUSPICIOUS:return 1;case H.HIGH:return 2;case H.CRITICAL:return 3;default:return 0}}function _f(e,t={}){const n=t.weights??{},r=[];let o=0,a=0;const i=[];for(const h of e){const E=bf(h.sourceId,n);let S=null,L=null;E>0&&h.status===_n.OK&&h.summary&&(S=Sf(h.summary),L=S===null?null:wa(S),S!==null&&(o+=S*E,a+=E,i.push(S))),r.push({sourceId:h.sourceId,sourceLabel:h.sourceLabel,status:h.status,weight:E,signalStrength:S,bandLabel:L})}const s=i.length>=yf;let l=null;a>0&&s&&(l=Y(o/a));const u=l!==null&&a>0?wa(l):null,p=l===null||a===0||u===null?H.UNKNOWN:u,f=s&&l!==null&&Cf(r,i);return{label:p,compositeSignal:l,disagreement:f,sources:r}}const If="Vera5 IOC Summary",hs="Source Summary",gs="Analyst notes",ur=1,lo="No enrichment source results are available to compute a local advisory score.",Tf={ipv4:"IPv4 address",domain:"Domain",url:"URL",md5:"MD5 hash",sha1:"SHA1 hash",sha256:"SHA256 hash",cve:"CVE ID",email:"Email address",asn:"ASN",cidr:"IPv4 CIDR",filepath:"File path",onion:"Onion domain"};function xf(e){return Tf[e]}function Lf(e,t){const n=t?.trim();if(n)return n;const r=It(e).trim();return r.length>0?r:void 0}function Nf(e){return e.map(t=>({sourceId:t.sourceId,name:t.label,status:t.status,summary:t.detail,tags:(t.tags??[]).map(n=>n.trim()).filter(n=>n.length>0),fromCache:t.fromCache,lastUpdatedLine:t.lastUpdatedLine,badgeText:t.badgeText}))}function wf(e,t){const n=fs(e,t);if(!n)return null;if(n.mode==="unavailable")return{mode:"unavailable",headline:n.headline,detail:n.detail,disagreement:!1,reasoningLines:[]};const r=ps(n.view,n.insufficientCompositeNotice),o=r.mode==="chain"?r.chain.sourceLines:[],a=r.mode==="empty"?r.detail:void 0,i=n.view.score.disagreement,s=i?us:void 0,l={label:n.view.score.label,summaryText:n.view.summaryText,compositeSignal:n.view.score.compositeSignal,disagreement:i,disagreementNotice:s,reasoningLines:o,reasoningEmptyDetail:a};return n.insufficientCompositeNotice?{mode:"insufficient",...l,insufficientDetail:n.insufficientCompositeNotice}:{mode:"available",...l}}function vs(e){const t=e.sourceResults??[],n=e.disabledSources??[],r=ns(t.map(s=>({sourceId:s.sourceId,sourceLabel:s.label,status:s.status,summary:s.status==="ok"?s.detail:void 0,tags:s.tags,fromCache:s.fromCache,errorCode:s.errorCode,errorMessage:s.status==="error"?s.detail:void 0,retryHint:s.retryHint,rawVendorJson:s.rawVendorJson}))),o=e.enrichmentState??r.enrichmentState,a=e.summary?.trim()||r.summary?.trim(),i=(e.tags??r.tags??[]).map(s=>s.trim()).filter(s=>s.length>0);return{ioc:e.value.trim(),iocType:e.iocType,iocTypeLabel:xf(e.iocType),enrichmentState:o,summary:a||void 0,tags:i,sources:Nf(t),disabledSources:[...n],riskScore:wf(n,t),analystNotes:Lf(e.value,e.analystNotes),pivots:Op(e.iocType,e.value),exportedAt:e.exportedAt??new Date().toISOString()}}function Ut(e){return e?.mode==="available"||e?.mode==="insufficient"}function Rf(e){return e.riskScore?.mode==="unavailable"?["",e.riskScore.headline,"",e.riskScore.detail]:e.riskScore===null?["",Tn,"",lo]:[]}function Of(e){const{riskScore:t}=e;if(!Ut(t))return[];const n=["",`Risk score: ${t.summaryText}`];if(t.mode==="insufficient"&&n.push("",t.insufficientDetail),n.push("",`### ${co}`,""),t.reasoningLines.length>0)for(let r=0;r<t.reasoningLines.length;r+=1)n.push(`${r+1}. ${t.reasoningLines[r]}`);else t.reasoningEmptyDetail&&n.push(t.reasoningEmptyDetail);return t.disagreement&&t.disagreementNotice&&n.push("",t.disagreementNotice),n}function Es(e){const t=Of(e);return t.length>0?t:Rf(e)}function ys(e){let t=`- ${e.name} (${e.badgeText}): ${e.summary}`;return e.tags.length>0&&(t+=` [${e.tags.join(", ")}]`),e.lastUpdatedLine&&(t+=` — ${e.lastUpdatedLine}`),t}function kf(e){const t=[];if(e.sources.length===1){const n=e.sources[0];t.push(qi({sourceLabel:n.name,fromCache:n.fromCache},e.enrichmentState)),n.summary&&t.push(n.summary),n.tags.length>0&&t.push(`Tags: ${n.tags.join(", ")}`),n.lastUpdatedLine&&t.push(n.lastUpdatedLine)}else if(e.sources.length>1)for(const n of e.sources)t.push(ys(n));for(const n of ao(e.disabledSources))t.push(`- ${n.label}: ${n.message}`);return t.length===0?[]:["",`### ${hs}`,"",...t]}function Df(e){return e.analystNotes?["",`### ${gs}`,"",e.analystNotes]:[]}function Vt(e){const t=[`## ${If}`,"",`IOC: ${e.ioc}`,`Type: ${e.iocTypeLabel}`];return e.summary&&t.push("",`Summary: ${e.summary}`),e.tags.length>0&&t.push("",`Tags: ${e.tags.join(", ")}`),t.push(...Es(e)),t.push(...kf(e)),t.push(...Df(e)),t.push(""),t.join(`
`)}function Mf(e){return e.sources.map(t=>({sourceId:t.sourceId,name:t.name,status:t.status,summary:t.summary,tags:[...t.tags],fromCache:t.fromCache,lastUpdatedLine:t.lastUpdatedLine,badgeText:t.badgeText}))}function Pf(e){const{riskScore:t}=e;return t?t.mode==="unavailable"?{mode:"unavailable",headline:t.headline,detail:t.detail}:t.mode==="insufficient"?{mode:"insufficient",label:t.label,summaryText:t.summaryText,compositeSignal:t.compositeSignal,reasoningLines:[...t.reasoningLines],reasoningEmptyDetail:t.reasoningEmptyDetail,insufficientDetail:t.insufficientDetail}:{mode:"available",label:t.label,summaryText:t.summaryText,compositeSignal:t.compositeSignal,reasoningLines:[...t.reasoningLines],reasoningEmptyDetail:t.reasoningEmptyDetail}:{mode:"none",headline:Tn,detail:lo}}function Hf(e){return Ut(e.riskScore)?{disagreement:e.riskScore.disagreement,disagreementNotice:e.riskScore.disagreementNotice}:{disagreement:!1}}function uo(e){const t=Hf(e),n={schemaVersion:ur,exportedAt:e.exportedAt,ioc:e.ioc,iocType:e.iocType,iocTypeLabel:e.iocTypeLabel,enrichmentState:e.enrichmentState,summary:e.summary,tags:[...e.tags],sources:Mf(e),disabledSources:[...e.disabledSources],score:Pf(e),disagreement:t.disagreement,disagreementNotice:t.disagreementNotice,pivots:e.pivots};return e.analystNotes&&(n.analystNotes=e.analystNotes),n}function Ss(e,t=!0){return JSON.stringify(uo(e),null,t?2:void 0)}async function Uf(e){return Z(Ss(e))}async function Vf(e){return Z(Vt(e))}function bs(e){return Vt(e).replace(/^## /gm,"").replace(/^### /gm,"")}async function Ff(e){return Z(bs(e))}const Bf=`

---

`;function $f(e){return e.map(t=>Vt(t)).join(Bf)}function Cs(e,t=!0){return JSON.stringify(e.map(n=>uo(n)),null,t?2:void 0)}async function Gf(e){return e.length===0?!1:Z(Cs(e))}function zf(e,t,n){const r=e==="markdown"?"md":"json",o=n.replace(/[:.]/g,"-");return`vera5-tray-export-${t}-iocs-${o}.${r}`}function Yf(e,t,n=document){if(e.length===0)return;const r=e[0]?.exportedAt??new Date().toISOString(),o=t==="markdown"?$f(e):Cs(e),a=t==="markdown"?"text/markdown":"application/json",i=new Blob([o],{type:a}),s=URL.createObjectURL(i),l=n.createElement("a");l.href=s,l.download=zf(t,e.length,r),l.click(),URL.revokeObjectURL(s)}function Kf(e){const t=e.replace(/[^a-zA-Z0-9._-]+/g,"_").replace(/^_+|_+$/g,"");return t.length>0?t.slice(0,80):"ioc"}function Wf(e,t){const n=t==="markdown"?"md":t==="json"?"json":"txt",r=e.exportedAt.replace(/[:.]/g,"-");return`vera5-${Kf(e.ioc)}-${r}.${n}`}function jf(e,t){return t==="json"?{content:Ss(e),mimeType:"application/json"}:t==="markdown"?{content:Vt(e),mimeType:"text/markdown"}:{content:bs(e),mimeType:"text/plain"}}function qf(e,t,n=document){const{content:r,mimeType:o}=jf(e,t),a=new Blob([r],{type:o}),i=URL.createObjectURL(a),s=n.createElement("a");s.href=i,s.download=Wf(e,t),s.click(),URL.revokeObjectURL(i)}const As=["jira-comment","thehive-case-note","analyst-update","obsidian-note","markdown-report","csv-row"],Xf={"jira-comment":"Jira comment","thehive-case-note":"TheHive case note","analyst-update":"Analyst update","obsidian-note":"Obsidian note","markdown-report":"Markdown report","csv-row":"CSV rows"},Jf=`

---

`;function Qf(){return[...As]}function Tt(e){return Xf[e]}function dr(e){return typeof e=="string"&&As.includes(e)}function Zf(e){return Ut(e.riskScore)?e.riskScore.summaryText:e.riskScore?.mode==="unavailable"?e.riskScore.headline:Tn}function em(e){return Ut(e.riskScore)?e.riskScore.reasoningLines.join(`
`):lo}function tm(e){const t=[];if(e.sources.length===1){const n=e.sources[0];t.push(`${n.name}: ${n.summary}`),n.tags.length>0&&t.push(`Tags: ${n.tags.join(", ")}`),n.lastUpdatedLine&&t.push(n.lastUpdatedLine)}else if(e.sources.length>1)for(const n of e.sources)t.push(ys(n));for(const n of ao(e.disabledSources))t.push(`${n.label}: ${n.message}`);return t.length===0?"No enrichment source results available.":t.join(`
`)}function nm(e){return Ut(e.riskScore)?e.riskScore.disagreementNotice??"":""}function _s(e){return{ioc:e.ioc,iocType:e.iocType,iocTypeLabel:e.iocTypeLabel,summary:e.summary??"",tags:e.tags.join(", "),scoreSummary:Zf(e),scoreReasoning:em(e),sourcesBlock:tm(e),analystNotes:e.analystNotes??"",exportedAt:e.exportedAt,disagreementNotice:nm(e)}}function rm(e){const t=[`h3. Vera5 IOC triage — ${e.ioc}`,"",`*Type:* ${e.iocTypeLabel}`];return e.summary&&t.push(`*Summary:* ${e.summary}`),e.tags&&t.push(`*Tags:* ${e.tags}`),t.push(`*Risk score:* ${e.scoreSummary}`),e.disagreementNotice&&t.push(`*Sources disagree:* ${e.disagreementNotice}`),t.push("","h4. Source summary","",e.sourcesBlock),e.scoreReasoning&&t.push("","h4. Score reasoning","",e.scoreReasoning),e.analystNotes&&t.push("","h4. Analyst notes","",e.analystNotes),t.push("",`_Exported ${e.exportedAt} via Vera5._`),t.join(`
`)}function om(e){const t=[`[Vera5] ${e.ioc} (${e.iocTypeLabel})`,"",`Summary: ${e.summary||"No enrichment summary available."}`,`Risk score: ${e.scoreSummary}`];return e.disagreementNotice&&t.push(`Sources disagree: ${e.disagreementNotice}`),t.push("","Sources:",e.sourcesBlock),e.analystNotes&&t.push("","Analyst notes:",e.analystNotes),t.push("",`Exported ${e.exportedAt} via Vera5.`),t.join(`
`)}function Ra(e){const t=e.summary?`Summary: ${e.summary}. `:"",n=e.tags?`Tags: ${e.tags}. `:"",r=e.disagreementNotice?`Sources disagree: ${e.disagreementNotice}. `:"";let o=`Vera5 triage for ${e.ioc} (${e.iocTypeLabel}). ${t}${n}Risk score: ${e.scoreSummary}. ${r}`.trim();return e.analystNotes&&(o+=` Analyst notes: ${e.analystNotes}`),o}function am(e,t){const n=["---",`ioc: ${t.ioc}`,`ioc_type: ${t.iocType}`,`exported_at: ${t.exportedAt}`,"source: Vera5","---","",`# Vera5 IOC — ${t.ioc}`,"",`- Type: ${t.iocTypeLabel}`];return t.summary&&n.push(`- Summary: ${t.summary}`),t.tags&&n.push(`- Tags: ${t.tags}`),n.push(`- Risk score: ${t.scoreSummary}`),t.disagreementNotice&&n.push(`- Sources disagree: ${t.disagreementNotice}`),n.push("",`## ${hs}`,"",t.sourcesBlock),n.push(...Es(e)),t.analystNotes&&n.push("",`## ${gs}`,"",t.analystNotes),n.join(`
`)}function fe(e){return/[",\n\r]/.test(e)?`"${e.replace(/"/g,'""')}"`:e}function Is(e){const t=_s(e);return[fe(t.ioc),fe(t.iocType),fe(t.summary),fe(t.scoreSummary),fe(t.tags),fe(t.sourcesBlock.replace(/\n/g," | ")),fe(t.analystNotes),fe(t.exportedAt)].join(",")}const im="ioc,ioc_type,summary,risk_score,tags,sources,analyst_notes,exported_at";function sm(e,t){if(e==="markdown-report")return Vt(t);if(e==="csv-row")return Is(t);const n=_s(t);switch(e){case"jira-comment":return rm(n);case"thehive-case-note":return om(n);case"analyst-update":return Ra(n);case"obsidian-note":return am(t,n);default:return Ra(n)}}function Ts(e,t){return t.length===0?"":e==="csv-row"?[im,...t.map(n=>Is(n))].join(`
`):t.map(n=>sm(e,n)).join(Jf)}function cm(e){return e==="csv-row"?"text/csv":e==="obsidian-note"||e==="markdown-report"||e==="jira-comment"?"text/markdown":"text/plain"}function lm(e){return e==="csv-row"?"csv":e==="obsidian-note"||e==="markdown-report"||e==="jira-comment"?"md":"txt"}function um(e,t,n){const r=n.replace(/[:.]/g,"-"),o=lm(e);return`vera5-tray-${e}-${t}-iocs-${r}.${o}`}function po(e,t,n=document){if(t.length===0)return;const r=t[0]?.exportedAt??new Date().toISOString(),o=Ts(e,t),a=new Blob([o],{type:cm(e)}),i=URL.createObjectURL(a),s=n.createElement("a");s.href=i,s.download=um(e,t.length,r),n.body.appendChild(s),s.click(),s.remove(),URL.revokeObjectURL(i)}async function fo(e,t){return t.length===0?!1:Z(Ts(e,t))}const dm="soc",pm="cti",fm="dfir",mm=[dm,pm,fm];function hm(e){return typeof e=="string"&&mm.includes(e)}function gm(e){if(typeof e!="string")return"";const t=e.trim().toLowerCase();return hm(t)?t:""}function xs(e){return dr(e)?e:"analyst-update"}function Ls(e){if(!Array.isArray(e))return[];const t=[],n=new Set;for(const r of e){if(typeof r!="string"||n.has(r)||!Object.values(v).includes(r))continue;const o=r;n.add(o),t.push(o)}return t}function vm(){return{domains:[],cidrRanges:[],vendorLabels:[]}}function Em(e){if(e===null||typeof e!="object"||Array.isArray(e))return null;const t=e;if(typeof t.label!="string"||typeof t.pattern!="string")return null;const n=t.label.trim(),r=Jr(t.pattern);return!n||!r?null:{label:n,pattern:r}}function Ns(e){if(!Array.isArray(e))return[];const t=[],n=new Set;for(const r of e){const o=Em(r);if(!o)continue;const a=`${o.label.toLowerCase()}::${o.pattern}`;n.has(a)||(n.add(a),t.push(o))}return t}function nn(e){const t=e.split(".");if(t.length!==4)return null;let n=0;for(const r of t){if(!/^\d+$/.test(r))return null;const o=Number(r);if(!Number.isInteger(o)||o<0||o>255)return null;n=(n<<8)+o}return n>>>0}function ym(e){const t=e.trim();if(!t)return null;const n=t.indexOf("/");if(n===-1)return nn(t)===null?null:`${t}/32`;const r=t.slice(0,n).trim(),o=t.slice(n+1).trim(),a=Number(o);return nn(r)===null||!Number.isInteger(a)||a<0||a>32?null:`${r}/${a}`}function ws(e){if(!Array.isArray(e))return[];const t=[],n=new Set;for(const r of e){if(typeof r!="string")continue;const o=ym(r);!o||n.has(o)||(n.add(o),t.push(o))}return t}function Sm(e){return{domains:Ve(e.domains),cidrRanges:ws(e.cidrRanges),vendorLabels:Ns(e.vendorLabels)}}function bm(e,t){const n=nn(e.trim());if(n===null)return!1;const r=t.indexOf("/");if(r===-1)return!1;const o=nn(t.slice(0,r).trim()),a=Number(t.slice(r+1));if(o===null||!Number.isInteger(a)||a<0||a>32)return!1;if(a===0)return!0;const i=a===32?4294967295:-1<<32-a>>>0;return(n&i)===(o&i)}function Cm(e){try{return new URL(e).hostname.trim().toLowerCase()||null}catch{return null}}function Oa(e,t){return ar(e,t.domains)?!0:t.vendorLabels.some(n=>$i(e,n.pattern))}function Am(e,t,n){if(t===d.IPV4)return n.cidrRanges.some(r=>bm(e,r));if(t===d.DOMAIN)return Oa(e,n);if(t===d.URL){const r=Cm(e);return r?Oa(r,n):!1}return!1}function _m(e){return e.domains.length>0||e.cidrRanges.length>0||e.vendorLabels.length>0}const ze=3,Im=3600,xn="extensionEnabled",Ln="highlightEnabled",Q="settingsSchemaVersion",mo="autoScanEnabled",ho="manualOnlyMode",go="includePrivateIpv4",Ye="localBackendEnabled",Ke="localLlmSummaryEnabled",xt="apiKeys",Lt="enrichmentSourceEnabled",ge="iocTypeEnabled",vo="enrichmentCacheTtlSeconds",Eo="enrichmentSourceCacheTtlSeconds",yo="showDisabledSourcesInWorkspace",Te="showPreQueryNotices",Nn="preQueryNoticePreferenceConfigured",So="installQuickStartCompleted",xe="domainPolicyMode",Le="domainAllowlist",te="domainDenylist",Ne="domainPolicyEnrichGateEnabled",Fe="internalAssetEnrichGateEnabled",Be="internalAssetDomains",$e="internalAssetCidrRanges",Ge="internalAssetVendorLabels",bo="analystModePresetId",We="defaultExportTemplateId",je="pivotEmphasisProviders",Rs=[xn,Ln,Q,mo,ho,go,Ye,Ke,xt,Lt,ge,vo,yo,Te,Nn,So,xe,Le,te,Ne,Fe,Be,$e,Ge,bo,We,je],Tm=[...Rs,Eo],Co=yd,Ao=["ipv4","domain","url","md5","sha1","sha256","cve","email","asn","cidr","filepath","onion"],xm=new Set(Ao);function Os(e){return e===null||typeof e!="object"||Array.isArray(e)?!1:Object.entries(e).every(([t,n])=>kd(t)&&typeof n=="string")}function ks(e){return e===null||typeof e!="object"||Array.isArray(e)?!1:Object.entries(e).every(([t,n])=>x.includes(t)&&typeof n=="boolean")}function Lm(e){return e===null||typeof e!="object"||Array.isArray(e)?!1:Object.entries(e).every(([t,n])=>x.includes(t)&&typeof n=="number"&&Number.isFinite(n)&&n>=0)}function Ds(e){return e===null||typeof e!="object"||Array.isArray(e)?!1:Object.entries(e).every(([t,n])=>xm.has(t)&&typeof n=="boolean")}function Ms(){return{}}function Ps(){const e={};for(const t of x)e[t]=le[t].enabledDefault;return e}function Hs(){return{}}function Us(){const e={};for(const t of Ao)e[t]=!0;return e}function Nm(){return{extensionEnabled:!0,highlightEnabled:!0,settingsSchemaVersion:ze,autoScanEnabled:!1,manualOnlyMode:!0,includePrivateIpv4:!1,localBackendEnabled:!1,localLlmSummaryEnabled:!1,apiKeys:Ms(),enrichmentSourceEnabled:Ps(),iocTypeEnabled:Us(),enrichmentCacheTtlSeconds:Im,enrichmentSourceCacheTtlSeconds:Hs(),showDisabledSourcesInWorkspace:!1,showPreQueryNotices:!0,preQueryNoticePreferenceConfigured:!1,installQuickStartCompleted:!1,domainPolicyMode:or().mode,domainAllowlist:[],domainDenylist:[...or().denylist],domainPolicyEnrichGateEnabled:!0,internalAssetEnrichGateEnabled:!0,internalAssetDomains:[],internalAssetCidrRanges:[],internalAssetVendorLabels:[],analystModePresetId:"",defaultExportTemplateId:"analyst-update",pivotEmphasisProviders:[]}}function wm(e){if(!Lm(e))return Hs();const t={};for(const[n,r]of Object.entries(e))x.includes(n)&&(t[n]=Math.floor(r));return t}function F(e,t){return e===void 0?t:!!e}function Et(e,t){return typeof e!="number"||!Number.isFinite(e)||e<0?t:Math.floor(e)}function Rm(e,t){if(typeof e=="number"&&Number.isFinite(e)&&e>=0)return Math.floor(e);if(typeof e=="string"&&e.trim()!==""){const n=Number.parseInt(e,10);if(Number.isFinite(n)&&n>=0)return n}return t}function Om(e){if(!Os(e))return Ms();const t={};for(const n of Co){const r=e[n];typeof r=="string"&&r.length>0&&(t[n]=r)}return t}function km(e){const t=Ps();if(!ks(e))return t;const n={...t};for(const r of x){const o=e[r];typeof o=="boolean"&&(n[r]=o)}return n}function _o(e){const t=Us();if(!Ds(e))return t;const n={...t};for(const r of Ao){const o=e[r];typeof o=="boolean"&&(n[r]=o)}return n}function Dm(e){const t=Nm();return{extensionEnabled:F(e[xn],t.extensionEnabled),highlightEnabled:F(e[Ln],t.highlightEnabled),settingsSchemaVersion:Et(e[Q],t.settingsSchemaVersion),autoScanEnabled:F(e[mo],t.autoScanEnabled),manualOnlyMode:F(e[ho],t.manualOnlyMode),includePrivateIpv4:F(e[go],t.includePrivateIpv4),localBackendEnabled:F(e[Ye],t.localBackendEnabled),localLlmSummaryEnabled:F(e[Ke],t.localLlmSummaryEnabled),apiKeys:Om(e[xt]),enrichmentSourceEnabled:km(e[Lt]),iocTypeEnabled:_o(e[ge]),enrichmentCacheTtlSeconds:Rm(e[vo],t.enrichmentCacheTtlSeconds),enrichmentSourceCacheTtlSeconds:wm(e[Eo]),showDisabledSourcesInWorkspace:F(e[yo],t.showDisabledSourcesInWorkspace),showPreQueryNotices:F(e[Te],t.showPreQueryNotices),preQueryNoticePreferenceConfigured:F(e[Nn],t.preQueryNoticePreferenceConfigured),installQuickStartCompleted:F(e[So],t.installQuickStartCompleted),domainPolicyMode:Fi(e[xe]),domainAllowlist:Ve(e[Le]),domainDenylist:e[te]===void 0?[...t.domainDenylist]:Ve(e[te]),domainPolicyEnrichGateEnabled:F(e[Ne],t.domainPolicyEnrichGateEnabled),internalAssetEnrichGateEnabled:F(e[Fe],t.internalAssetEnrichGateEnabled),internalAssetDomains:Ve(e[Be]),internalAssetCidrRanges:ws(e[$e]),internalAssetVendorLabels:Ns(e[Ge]),analystModePresetId:gm(e[bo]),defaultExportTemplateId:xs(e[We]),pivotEmphasisProviders:Ls(e[je])}}function Mm(e){const t=Et(e[Q],0),n={...e};if(t<2){const r=n[te];(r===void 0||Array.isArray(r)&&r.length===0)&&(n[te]=[...Bi]),n[Q]=2}return Et(n[Q],0)<3&&(n[ge]=_o(n[ge]),n[Q]=3),Et(n[Q],0)>=ze?n:{...n,[Q]:ze}}function Pm(e){return{[xn]:e.extensionEnabled,[Ln]:e.highlightEnabled,[Q]:e.settingsSchemaVersion,[mo]:e.autoScanEnabled,[ho]:e.manualOnlyMode,[go]:e.includePrivateIpv4,[Ye]:e.localBackendEnabled,[Ke]:e.localLlmSummaryEnabled,[xt]:e.apiKeys,[Lt]:e.enrichmentSourceEnabled,[ge]:e.iocTypeEnabled,[vo]:e.enrichmentCacheTtlSeconds,[Eo]:e.enrichmentSourceCacheTtlSeconds,[yo]:e.showDisabledSourcesInWorkspace,[Te]:e.showPreQueryNotices,[Nn]:e.preQueryNoticePreferenceConfigured,[So]:e.installQuickStartCompleted,[xe]:e.domainPolicyMode,[Le]:e.domainAllowlist,[te]:e.domainDenylist,[Ne]:e.domainPolicyEnrichGateEnabled,[Fe]:e.internalAssetEnrichGateEnabled,[Be]:e.internalAssetDomains,[$e]:e.internalAssetCidrRanges,[Ge]:e.internalAssetVendorLabels,[bo]:e.analystModePresetId,[We]:e.defaultExportTemplateId,[je]:e.pivotEmphasisProviders}}function Hm(e){if(Et(e[Q],0)!==ze||e[xt]!==void 0&&!Os(e[xt])||e[Lt]!==void 0&&!ks(e[Lt])||e[ge]!==void 0&&!Ds(e[ge]))return!0;for(const t of Rs)if(e[t]===void 0)return!0;return!1}async function wn(){const e=await chrome.storage.local.get(Tm),t=Mm(e),n=Dm(t);if(Hm(e)){const r=Pm({...n,settingsSchemaVersion:ze});await chrome.storage.local.set(r)}return{...n,settingsSchemaVersion:ze}}async function Um(){return(await wn()).extensionEnabled}async function Vm(e){await chrome.storage.local.set({[xn]:e})}async function Fm(){return(await wn()).highlightEnabled}async function Bm(e){await chrome.storage.local.set({[Ln]:e})}function $m(e){return x.filter(t=>e[t]!==!0)}async function Gm(e){await chrome.storage.local.set({[Te]:e,[Nn]:!0})}const pr="autoScanEnabled";async function zm(){const t=(await k(pr))[pr];return t===void 0?!1:!!t}async function Ym(){const e=await k([xe,Le,te]),t=or();return e[xe]===void 0&&e[Le]===void 0&&e[te]===void 0?t:id({mode:e[xe]??t.mode,allowlist:e[Le]??t.allowlist,denylist:e[te]??t.denylist})}async function Km(){const e=await k(Ne);return e[Ne]===void 0?!0:e[Ne]===!0}function Wm(e=document){return e.location.hostname.trim().toLowerCase()}async function Io(e=document){const t=await Ym();return sd(Wm(e),t)}async function jm(e=document){const t=await Km();return t?Io(e):!0}async function qm(e=document){return await zm()?Io(e):!1}const Xm=[xe,Le,te,Ne,pr],fr="highlightEnabled";async function Jm(){const t=(await k(fr))[fr];return t===void 0?!0:!!t}const ka="includePrivateIpv4";async function Qm(){const t=(await k(ka))[ka];return t===void 0?!1:!!t}const Da=ge;async function Zm(){const e=await k(Da);return _o(e[Da])}const ve={CONTENT_REGISTER:"CONTENT_REGISTER",SCAN_PAGE:"SCAN_PAGE",SCAN_SELECTION:"SCAN_SELECTION",ENRICH_SELECTION:"ENRICH_SELECTION",NAVIGATE_TO_IOC_ANCHOR:"NAVIGATE_TO_IOC_ANCHOR",TOGGLE_WORKSPACE:"TOGGLE_WORKSPACE",OPEN_WORKSPACE:"OPEN_WORKSPACE",TOGGLE_COMMAND_PALETTE:"TOGGLE_COMMAND_PALETTE"};const Ma=2500,er={skipScript:!0,skipStyle:!0,skipTextarea:!0},eh=new Set(["head","link","meta","noscript","template","title"]);function Rn(e={}){return{skipScript:e.skipScript??er.skipScript,skipStyle:e.skipStyle??er.skipStyle,skipTextarea:e.skipTextarea??er.skipTextarea}}function th(e,t={}){const n=Rn(t),r=e.tagName.toLowerCase();return!!(n.skipScript&&r==="script"||n.skipStyle&&r==="style"||n.skipTextarea&&r==="textarea"||eh.has(r))}function Vs(e,t,n={}){const r=Rn(n);let o=e;for(;o&&o!==t;){if(o.nodeType===Node.ELEMENT_NODE&&th(o,r))return!0;o=o.parentNode}return!1}function mr(e,t,n={}){return(e.textContent??"").trim().length===0?!1:!Vs(e,t,n)}function nh(e={}){const t=e.maxTextNodes??Ma;return!Number.isFinite(t)||t<1?Ma:Math.floor(t)}function rh(e,t={}){const n=Rn(t),r=nh(t),a=(e.ownerDocument??document).createTreeWalker(e,NodeFilter.SHOW_TEXT),i=[];let s=!1,l=a.nextNode();for(;l;){if(mr(l,e,n)&&(i.push(l),i.length>=r)){let u=a.nextNode();for(;u;){if(mr(u,e,n)){s=!0;break}u=a.nextNode()}break}l=a.nextNode()}return{nodes:i,textNodesScanned:i.length,textNodeCap:r,capReached:s}}function oh(e,t){if(!e.isConnected)return!1;const r=(e.ownerDocument??document).createRange();try{r.selectNodeContents(e)}catch{return!1}return t.compareBoundaryPoints(Range.END_TO_START,r)<0&&t.compareBoundaryPoints(Range.START_TO_END,r)>0}function Fs(e,t={}){const n=rh(e,t);let r=0;return{blocks:n.nodes.map(a=>{const i=a.textContent??"",s={node:a,text:i,blockStart:r};return r+=i.length,s}),textNodesScanned:n.textNodesScanned,textNodeCap:n.textNodeCap,capReached:n.capReached}}const Pa=500;function ah(e,t){return t?t[e]!==!1:!0}const Ha={url:0,email:1,filepath:2,onion:3,sha256:4,sha1:5,md5:6,cve:7,cidr:8,ipv4:9,asn:10,domain:11};function lt(e,t,n){for(const r of e)Bs(r.start,r.end,n)||(t.push(r),n.push({start:r.start,end:r.end}))}function ih(e,t){return e.start<t.end&&e.end>t.start}function Bs(e,t,n){return n.some(r=>e<r.end&&t>r.start)}function sh(e){return`${e.start}:${e.end}:${e.type}:${e.value}`}function ch(e){const t=new Map;for(const o of e)t.set(sh(o),o);const n=[...t.values()].sort((o,a)=>{const i=Ha[o.type]-Ha[a.type];return i!==0?i:o.start!==a.start?o.start-a.start:a.end-o.end}),r=[];for(const o of n){const a={start:o.start,end:o.end},i=r.findIndex(u=>ih(a,u));if(i===-1){r.push({...o,ignoredOverlaps:o.ignoredOverlaps?[...o.ignoredOverlaps]:[]});continue}const s=r[i],l=[...s.ignoredOverlaps??[]];l.push({type:o.type,value:o.value,ruleId:o.ruleId}),r[i]={...s,ignoredOverlaps:l}}return r.sort((o,a)=>o.start-a.start)}function To(e,t={}){const n=[],r=[],o=Br(e);for(const i of o)n.push(i),r.push({start:i.start,end:i.end});lt(Gr(e),n,r),lt(Wr(e),n,r),lt(Kr(e),n,r);for(const i of Ur(e,r))n.push(i),r.push({start:i.start,end:i.end});for(const i of Vr(e,r))n.push(i),r.push({start:i.start,end:i.end});lt(Yr(e,t),n,r);for(const i of Fr(e,t))Bs(i.start,i.end,r)||(n.push(i),r.push({start:i.start,end:i.end}));lt(zr(e),n,r);for(const i of $r(e,r))n.push(i),r.push({start:i.start,end:i.end});const a=ch(n);return t.enabledTypes?a.filter(i=>ah(i.type,t.enabledTypes)):a}function $s(e={}){const t=e.maxIocs??Pa;return!Number.isFinite(t)||t<1?Pa:Math.floor(t)}function Gs(e,t,n,r){for(const o of t){if(e.length>=r)return!0;e.push({...o,textNode:n})}return!1}function lh(e=document.body,t={}){return zs(e,t).matches}function zs(e=document.body,t={}){const n=typeof performance<"u"?performance.now():0,r=t.ioc??{},o=t.walker??{},a=$s(t),i=Fs(e,o),s=[];let l=!1;for(const p of i.blocks){const f=To(p.text,r);if(Gs(s,f,p.node,a)){l=!0;break}}const u=typeof performance<"u"?performance.now():0;return{matches:s,profile:{textNodesScanned:i.textNodesScanned,textNodeCap:i.textNodeCap,capReached:i.capReached,iocCount:s.length,iocCap:a,iocCapReached:l,durationMs:Math.max(0,u-n)}}}function uh(e,t){let n=e.commonAncestorContainer;return n.nodeType===Node.TEXT_NODE&&(n=n.parentNode??t),n}function dh(e,t=document.body,n={}){const r=typeof performance<"u"?performance.now():0,o=n.ioc??{},a=n.walker??{},i=$s(n),s=Rn(a),l=uh(e,t),u=Fs(l,a),p=[];let f=0,h=!1;for(const S of u.blocks){if(!oh(S.node,e)||!mr(S.node,t,s)||Vs(S.node,t,s))continue;f+=1;const L=To(S.text,o);if(Gs(p,L,S.node,i)){h=!0;break}}const E=typeof performance<"u"?performance.now():0;return{matches:p,profile:{textNodesScanned:f,textNodeCap:u.textNodeCap,capReached:!1,iocCount:p.length,iocCap:i,iocCapReached:h,durationMs:Math.max(0,E-r)}}}const Ua="vera5-ui-styles",ph={empty:"vera5-hover-card-enrichment--empty",loading:"vera5-hover-card-enrichment--loading",error:"vera5-hover-card-enrichment--error",ready:"vera5-hover-card-enrichment--ready"};function fh(e,t="vera5-hover-card-enrichment"){return`${t} ${ph[e]}`}function mh(){return`
.vera5-hover-card-panel {
  --vera5-surface: #12171e;
  --vera5-text: #f5f7fa;
  --vera5-border: #313a45;
  --vera5-accent: #ffb224;
  --vera5-accent-text: #f5f7fa;
  --vera5-muted: #a7b0ba;
  --vera5-muted-label: #a7b0ba;
  --vera5-error: #ff4d5a;
  --vera5-ready: #f5f7fa;
  --vera5-button-bg: #19202a;
  --vera5-copy-success-bg: color-mix(in srgb, #22c7a9 16%, #12171e);
  --vera5-shadow: 0 6px 18px rgba(0, 0, 0, 0.28);
  box-sizing: border-box;
  min-width: 220px;
  max-width: 320px;
  padding: 10px 12px;
  border-radius: 8px;
  border: 1px solid var(--vera5-border);
  background-color: var(--vera5-surface);
  color: var(--vera5-text);
  font-family: system-ui, sans-serif;
  font-size: 13px;
  line-height: 1.45;
  box-shadow: var(--vera5-shadow);
  pointer-events: auto;
  animation: vera5-panel-reveal 0.16s ease-out;
}
@keyframes vera5-panel-reveal {
  from {
    opacity: 0;
    transform: translateY(4px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}
.vera5-hover-card-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  margin-bottom: 8px;
}
.vera5-hover-card-header-actions {
  display: flex;
  align-items: center;
  gap: 6px;
  margin-left: auto;
}
.vera5-hover-card-type {
  font-size: 11px;
  font-weight: 600;
  letter-spacing: 0.04em;
  text-transform: uppercase;
  color: var(--vera5-muted-label);
}
.vera5-hover-card-value {
  margin: 0 0 8px;
  font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
  font-size: 12px;
  word-break: break-all;
}
.vera5-hover-card-value-on-page {
  margin: 0 0 4px;
  font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
  font-size: 12px;
  word-break: break-all;
  color: var(--vera5-text);
}
.vera5-hover-card-refanged-value {
  margin: 0 0 8px;
  font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
  font-size: 11px;
  line-height: 1.45;
  word-break: break-all;
  color: var(--vera5-muted-label);
}
.vera5-hover-card-enrichment {
  margin: 0;
  font-size: 12px;
}
.vera5-hover-card-enrichment--empty,
.vera5-hover-card-enrichment--loading {
  color: var(--vera5-muted);
}
.vera5-hover-card-enrichment--loading {
  font-style: italic;
  animation: vera5-loading-pulse 1.4s ease-in-out infinite;
}
@keyframes vera5-loading-pulse {
  0%,
  100% {
    opacity: 1;
  }
  50% {
    opacity: 0.55;
  }
}
.vera5-hover-card-enrichment--error {
  color: var(--vera5-error);
}
.vera5-hover-card-enrichment--ready {
  color: var(--vera5-ready);
}
.vera5-hover-card-local-llm-summary {
  margin-top: 8px;
  padding-top: 8px;
  border-top: 1px solid var(--vera5-border);
}
.vera5-hover-card-local-llm-summary-heading {
  margin: 0 0 6px;
  font-size: 12px;
  font-weight: 600;
  letter-spacing: 0.02em;
  text-transform: none;
  color: var(--vera5-text);
}
.vera5-hover-card-local-llm-summary-panel {
  display: flex;
  flex-direction: column;
  gap: 0;
}
.vera5-hover-card-local-llm-summary-status {
  margin: 8px 0 0;
  font-size: 12px;
}
.vera5-hover-card-local-llm-summary-status--loading {
  color: var(--vera5-muted);
  font-style: italic;
  animation: vera5-loading-pulse 1.4s ease-in-out infinite;
}
.vera5-hover-card-local-llm-summary-status--error {
  color: var(--vera5-error);
}
.vera5-hover-card-local-llm-summary-disclaimer {
  margin: 8px 0 0;
  font-size: 11px;
  color: var(--vera5-muted-label);
}
.vera5-hover-card-local-llm-summary-body {
  margin: 8px 0 0;
  font-size: 12px;
  line-height: 1.45;
  white-space: pre-wrap;
  color: var(--vera5-text);
}
.vera5-hover-card-risk-score {
  margin: 8px 0;
}
.vera5-hover-card-risk-score-label {
  margin: 0 0 4px;
  font-size: 11px;
  color: var(--vera5-muted-label);
}
.vera5-hover-card-risk-score-unavailable {
  margin: 0 0 4px;
  font-size: 11px;
  font-weight: 600;
  color: var(--vera5-muted-label);
}
.vera5-hover-card-risk-score-insufficient {
  margin: 0 0 6px;
  font-size: 11px;
  line-height: 1.35;
  color: var(--vera5-muted-label);
}
.vera5-hover-card-risk-score-unavailable-detail {
  margin: 0;
  font-size: 11px;
  line-height: 1.35;
  color: var(--vera5-muted-label);
}
.vera5-hover-card-risk-disagreement {
  margin: 0 0 6px;
  font-size: 11px;
  line-height: 1.35;
  color: var(--vera5-error);
}
.vera5-hover-card-risk-reasoning {
  margin: 0 0 6px;
}
.vera5-hover-card-risk-reasoning-heading {
  margin: 0 0 4px;
  font-size: 10px;
  font-weight: 600;
  letter-spacing: 0.02em;
  text-transform: uppercase;
  color: var(--vera5-muted-label);
}
.vera5-hover-card-risk-reasoning-chain {
  margin: 0;
  padding-left: 18px;
  font-size: 11px;
  line-height: 1.4;
  color: var(--vera5-accent-text);
}
.vera5-hover-card-risk-reasoning-step {
  margin: 0 0 2px;
}
.vera5-hover-card-risk-reasoning-empty {
  margin: 0;
  font-size: 11px;
  line-height: 1.35;
  color: var(--vera5-muted-label);
}
.vera5-hover-card-risk-contributions {
  margin: 0;
  padding: 0;
  list-style: none;
  display: flex;
  flex-wrap: wrap;
  gap: 4px;
}
.vera5-hover-card-risk-contribution {
  margin: 0;
}
.vera5-hover-card-risk-contribution-chip {
  display: inline-flex;
  align-items: center;
  padding: 2px 6px;
  border-radius: 999px;
  border: 1px solid var(--vera5-border);
  background-color: var(--vera5-button-bg);
  color: var(--vera5-accent-text);
  font-size: 10px;
  font-weight: 600;
  line-height: 1.3;
}
.vera5-hover-card-tags {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
  margin-bottom: 8px;
}
.vera5-hover-card-tag {
  display: inline-flex;
  align-items: center;
  padding: 2px 8px;
  border-radius: 999px;
  border: 1px solid var(--vera5-border);
  background-color: var(--vera5-button-bg);
  color: var(--vera5-muted);
  font-size: 10px;
  font-weight: 600;
  line-height: 1.4;
  white-space: nowrap;
}
.vera5-hover-card-attribution {
  margin: 8px 0 0;
  padding-top: 8px;
  border-top: 1px solid var(--vera5-border);
  font-size: 11px;
  line-height: 1.4;
  color: var(--vera5-muted-label);
}
.vera5-hover-card-disclaimer {
  margin: 8px 0 0;
  padding-top: 8px;
  border-top: 1px solid var(--vera5-border);
  font-size: 10px;
  line-height: 1.35;
  color: var(--vera5-muted-label);
}
.vera5-hover-card-disclaimer p {
  margin: 0 0 4px;
}
.vera5-hover-card-disclaimer p:last-child {
  margin-bottom: 0;
}
.vera5-pre-query-disclosure {
  margin-bottom: 8px;
  padding: 8px;
  border: 1px solid var(--vera5-border);
  border-radius: 6px;
  background-color: var(--vera5-button-bg);
}
.vera5-pre-query-disclosure__message {
  margin: 0 0 8px;
  font-size: 11px;
  line-height: 1.45;
  color: var(--vera5-accent-text);
}
.vera5-pre-query-disclosure__remember {
  display: flex;
  align-items: center;
  gap: 6px;
  margin: 0 0 8px;
  font-size: 11px;
  line-height: 1.4;
  color: var(--vera5-muted-label);
  cursor: pointer;
}
.vera5-pre-query-disclosure__actions {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
}
  display: inline-block;
  font-size: 11px;
  font-weight: 600;
  padding: 4px 8px;
  border-radius: 4px;
  border: 1px solid var(--vera5-border);
  background-color: var(--vera5-button-bg);
  color: var(--vera5-accent-text);
  cursor: pointer;
  transition: background-color 0.15s ease, color 0.15s ease;
}
.vera5-hover-card-retry-hint {
  margin: 0;
  font-size: 11px;
  line-height: 1.4;
  color: var(--vera5-muted-label);
}
.vera5-hover-card-copy {
  font-size: 11px;
  font-weight: 600;
  padding: 4px 8px;
  border-radius: 4px;
  border: 1px solid var(--vera5-border);
  background-color: var(--vera5-button-bg);
  color: var(--vera5-accent-text);
  cursor: pointer;
  transition: background-color 0.15s ease, color 0.15s ease;
}
.vera5-hover-card-copy--copied {
  background-color: var(--vera5-copy-success-bg);
}
.vera5-hover-card-pivots {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
}
.vera5-hover-card-pivot-recipes {
  margin-bottom: 8px;
}
.vera5-hover-card-pivot-recipes-list {
  margin: 0;
  padding: 0;
  list-style: none;
}
.vera5-hover-card-pivot-recipe {
  display: flex;
  flex-wrap: wrap;
  align-items: baseline;
  gap: 6px;
  margin-bottom: 6px;
}
.vera5-hover-card-pivot-recipe:last-child {
  margin-bottom: 0;
}
.vera5-hover-card-pivot-recipe-source {
  flex-shrink: 0;
  font-size: 10px;
  font-weight: 700;
  padding: 1px 6px;
  border-radius: 4px;
  background: color-mix(in srgb, var(--vera5-accent) 18%, var(--vera5-button-bg));
  color: var(--vera5-accent-text);
}
.vera5-hover-card-pivot-recipe-guidance {
  flex: 1 1 100%;
  font-size: 11px;
  line-height: 1.4;
  color: var(--vera5-muted);
}
.vera5-hover-card-pivot-link {
  font-size: 11px;
  font-weight: 600;
  padding: 4px 8px;
  border-radius: 4px;
  border: 1px solid var(--vera5-border);
  background-color: var(--vera5-button-bg);
  color: var(--vera5-accent-text);
  text-decoration: none;
  white-space: nowrap;
  transition: background-color 0.15s ease, color 0.15s ease, border-color 0.15s ease;
}
.vera5-hover-card-sources {
  margin-bottom: 8px;
}
.vera5-hover-card-sources-heading {
  margin: 0 0 4px;
  font-size: 10px;
  font-weight: 600;
  letter-spacing: 0.04em;
  text-transform: uppercase;
  color: var(--vera5-muted-label);
}
.vera5-hover-card-section-heading {
  margin: 14px 0 8px;
  font-size: 12px;
  font-weight: 600;
  letter-spacing: 0.06em;
  text-transform: uppercase;
  text-align: left;
  color: var(--vera5-muted-label);
  line-height: 1.3;
}
.vera5-hover-card-intel-summary {
  margin-bottom: 8px;
}
.vera5-hover-card-sources-list {
  margin: 0;
  padding: 0;
  list-style: none;
  display: flex;
  flex-direction: column;
  gap: 4px;
}
.vera5-hover-card-source-item {
  margin: 0;
  display: flex;
  flex-direction: column;
  gap: 2px;
  font-size: 11px;
  color: var(--vera5-muted-label);
  line-height: 1.4;
  padding-bottom: 8px;
  margin-bottom: 8px;
  border-bottom: 1px solid var(--vera5-accent);
}
.vera5-hover-card-source-item:last-child {
  padding-bottom: 0;
  margin-bottom: 0;
  border-bottom: none;
}
.vera5-hover-card-source-badge {
  align-self: flex-start;
  font-size: 10px;
  font-weight: 600;
  letter-spacing: 0.02em;
  padding: 2px 6px;
  border-radius: 4px;
  border: 1px solid var(--vera5-border);
  white-space: nowrap;
}
.vera5-hover-card-source-badge--ok {
  color: #22c7a9;
  background-color: color-mix(in srgb, #22c7a9 16%, #12171e);
  border-color: color-mix(in srgb, #22c7a9 35%, var(--vera5-border));
}
.vera5-hover-card-source-badge--cached {
  color: #a7b0ba;
  background-color: var(--vera5-button-bg);
  border-color: var(--vera5-border);
}
.vera5-hover-card-source-last-updated {
  display: block;
  font-size: 10px;
  color: var(--vera5-muted-label);
  line-height: 1.35;
}
.vera5-hover-card-source-badge--error {
  color: #ff4d5a;
  background-color: color-mix(in srgb, #ff4d5a 14%, #12171e);
  border-color: color-mix(in srgb, #ff4d5a 35%, var(--vera5-border));
}
.vera5-hover-card-source-badge--skipped {
  color: var(--vera5-muted-label);
  background-color: var(--vera5-button-bg);
}
.vera5-hover-card-source-detail {
  display: block;
  color: var(--vera5-text);
}
.vera5-hover-card-raw-json {
  margin-top: 4px;
}
.vera5-hover-card-raw-json summary {
  cursor: pointer;
  font-size: 10px;
  font-weight: 600;
  color: var(--vera5-accent-text);
  list-style-position: outside;
}
.vera5-hover-card-raw-json-body {
  margin: 4px 0 0;
  padding: 6px 8px;
  max-height: 160px;
  overflow: auto;
  border-radius: 4px;
  border: 1px solid var(--vera5-border);
  background-color: var(--vera5-button-bg);
  font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
  font-size: 10px;
  line-height: 1.35;
  white-space: pre-wrap;
  word-break: break-word;
  color: var(--vera5-text);
}
.vera5-why-detected {
  margin-top: 4px;
}
.vera5-why-detected-row {
  margin: 0 0 4px;
  font-size: 11px;
  line-height: 1.45;
  color: var(--vera5-muted-label);
}
.vera5-why-detected-context {
  word-break: break-word;
}
.vera5-why-detected-overlaps-heading {
  margin: 0 0 4px;
  font-size: 11px;
  font-weight: 600;
  color: var(--vera5-muted-label);
}
.vera5-why-detected-list {
  margin: 0;
  padding-left: 16px;
  font-size: 11px;
  line-height: 1.45;
  color: var(--vera5-muted-label);
}
.vera5-why-detected-item {
  margin-bottom: 2px;
  word-break: break-word;
}
.vera5-tray-why-detected {
  width: 100%;
  margin-top: 4px;
  font-size: 11px;
  line-height: 1.45;
  color: var(--vera5-muted-label);
}
.vera5-tray-why-detected summary {
  cursor: pointer;
  color: var(--vera5-muted-label);
  font-weight: 600;
  list-style-position: outside;
}
.vera5-tray-why-detected .vera5-why-detected {
  margin-top: 4px;
}
.vera5-tray-save-collection {
  margin-top: 4px;
}
.vera5-tray-save-collection-toggle {
  border: none;
  background: transparent;
  color: var(--vera5-muted-label);
  cursor: pointer;
  font-size: 11px;
  font-weight: 600;
  padding: 0;
}
.vera5-workspace-tray-row .vera5-tray-save-collection-toggle,
.vera5-workspace-tray-row .vera5-tray-why-detected summary {
  opacity: 0.55;
  transition: opacity 0.14s ease;
}
.vera5-workspace-tray-row:hover .vera5-tray-save-collection-toggle,
.vera5-workspace-tray-row:focus-within .vera5-tray-save-collection-toggle,
.vera5-workspace-tray-row[aria-selected="true"] .vera5-tray-save-collection-toggle,
.vera5-workspace-tray-row:hover .vera5-tray-why-detected summary,
.vera5-workspace-tray-row:focus-within .vera5-tray-why-detected summary,
.vera5-workspace-tray-row[aria-selected="true"] .vera5-tray-why-detected summary {
  opacity: 1;
}
.vera5-tray-save-collection-panel {
  margin-top: 6px;
  padding: 8px 10px;
  border-radius: 6px;
  border: 1px solid var(--vera5-border);
  background: var(--vera5-surface);
}
.vera5-tray-save-collection-heading {
  margin: 0 0 8px;
  font-size: 12px;
  font-weight: 700;
  color: var(--vera5-accent-text);
}
.vera5-tray-save-collection-list {
  display: flex;
  flex-direction: column;
  gap: 4px;
  margin-bottom: 8px;
}
.vera5-tray-save-collection-feedback {
  margin: 8px 0 0;
  font-size: 12px;
  color: var(--vera5-text-muted);
  line-height: 1.4;
}
.vera5-workspace-field-label {
  display: block;
  margin: 0 0 8px;
  font-size: 11px;
  font-weight: 600;
  color: var(--vera5-text-muted);
}
.vera5-workspace-field-label input {
  display: block;
  width: 100%;
  margin-top: 4px;
  box-sizing: border-box;
}
.vera5-hover-card-analyst-notes {
  margin-top: 8px;
}
.vera5-hover-card-analyst-notes-label {
  display: block;
  margin-bottom: 4px;
  font-size: 10px;
  font-weight: 600;
  letter-spacing: 0.04em;
  text-transform: uppercase;
  color: var(--vera5-muted-label);
}
.vera5-hover-card-analyst-notes-input {
  box-sizing: border-box;
  width: 100%;
  min-height: 56px;
  padding: 6px 8px;
  border-radius: 4px;
  border: 1px solid var(--vera5-border);
  background-color: #19202a;
  color: #f5f7fa;
  font-family: inherit;
  font-size: 12px;
  line-height: 1.4;
  resize: vertical;
}
.vera5-hover-card-analyst-notes-input::placeholder {
  color: #6b7480;
}
.vera5-hover-card-analyst-notes-input:focus {
  outline: 2px solid color-mix(in srgb, var(--vera5-accent) 35%, transparent);
  outline-offset: 1px;
}
.vera5-hover-card-ioc-label {
  margin-top: 8px;
}
.vera5-hover-card-ioc-label-label {
  display: block;
  margin-bottom: 4px;
  font-size: 10px;
  font-weight: 600;
  letter-spacing: 0.04em;
  text-transform: uppercase;
  color: var(--vera5-muted-label);
}
.vera5-hover-card-ioc-label-select {
  box-sizing: border-box;
  width: 100%;
  padding: 6px 8px;
  border-radius: 4px;
  border: 1px solid var(--vera5-border);
  background-color: #19202a;
  color: #f5f7fa;
  font-family: inherit;
  font-size: 12px;
  line-height: 1.4;
}
.vera5-hover-card-ioc-label-select:focus {
  outline: 2px solid color-mix(in srgb, var(--vera5-accent) 35%, transparent);
  outline-offset: 1px;
}
.vera5-hover-card-ioc-timeline {
  margin-top: 8px;
}
.vera5-hover-card-ioc-timeline-label {
  display: block;
  margin-bottom: 4px;
  font-size: 10px;
  font-weight: 600;
  letter-spacing: 0.04em;
  text-transform: uppercase;
  color: var(--vera5-muted-label);
}
.vera5-hover-card-ioc-timeline-list {
  margin: 0;
  padding-left: 16px;
  color: #a7b0ba;
  font-size: 12px;
  line-height: 1.5;
}
.vera5-hover-card-ioc-timeline-item {
  margin: 0;
}
.vera5-hover-card-ioc-pin {
  border: 1px solid var(--vera5-border);
  border-radius: 4px;
  background: #19202a;
  color: #f5f7fa;
  font-family: inherit;
  font-size: 11px;
  font-weight: 600;
  line-height: 1.2;
  padding: 4px 8px;
  cursor: pointer;
}
.vera5-hover-card-ioc-pin--pinned {
  border-color: color-mix(in srgb, var(--vera5-accent) 45%, var(--vera5-border));
  color: var(--vera5-accent-text);
  background: color-mix(in srgb, var(--vera5-accent) 8%, #12171e);
}
.vera5-hover-card-ioc-pin:focus {
  outline: 2px solid color-mix(in srgb, var(--vera5-accent) 35%, transparent);
  outline-offset: 1px;
}
.vera5-hover-card-save-collection {
  margin-top: 8px;
}
.vera5-hover-card-save-collection-toggle {
  border: none;
  background: transparent;
  color: var(--vera5-accent);
  cursor: pointer;
  font-size: 12px;
  font-weight: 600;
  padding: 0;
}
.vera5-hover-card-save-collection-panel {
  margin-top: 6px;
  padding: 8px 10px;
  border-radius: 6px;
  border: 1px solid var(--vera5-border);
  background: var(--vera5-surface);
}
.vera5-hover-card-save-collection-heading {
  margin: 0 0 8px;
  font-size: 12px;
  font-weight: 700;
  color: var(--vera5-accent-text);
}
.vera5-hover-card-save-collection-list {
  display: flex;
  flex-direction: column;
  gap: 4px;
  margin-bottom: 8px;
}
.vera5-hover-card-save-collection-field {
  display: block;
  margin: 0 0 8px;
  font-size: 11px;
  font-weight: 600;
  color: var(--vera5-text-muted);
}
.vera5-hover-card-save-collection-field input {
  display: block;
  width: 100%;
  margin-top: 4px;
  box-sizing: border-box;
}
.vera5-hover-card-save-collection-feedback {
  margin: 8px 0 0;
  font-size: 12px;
  color: var(--vera5-text-muted);
  line-height: 1.4;
}
.vera5-hover-card-export {
  margin-top: 8px;
}
.vera5-hover-card-export-footer {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 10px;
}
.vera5-hover-card-export-footer .vera5-hover-card-export-actions {
  justify-content: center;
}
.vera5-hover-card-export-footer .vera5-hover-card-scan-export-template-row {
  justify-content: center;
  margin-top: 0;
  width: 100%;
}
.vera5-hover-card-export-footer .vera5-hover-card-scan-export-status {
  text-align: center;
  width: 100%;
}
.vera5-hover-card-export-actions {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
}
.vera5-hover-card-export-actions + .vera5-hover-card-export-actions {
  margin-top: 8px;
}
.vera5-hover-card-scan-export {
  display: flex;
  flex-direction: column;
  gap: 0;
}
.vera5-hover-card-scan-export-template-row {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
  align-items: center;
  margin-top: 8px;
}
.vera5-hover-card-scan-export-template-label {
  font-size: 11px;
  font-weight: 600;
  color: var(--vera5-text-muted);
}
.vera5-hover-card-scan-export-template-select {
  flex: 1 1 140px;
  min-width: 140px;
  padding: 4px 8px;
  border-radius: 4px;
  border: 1px solid var(--vera5-border);
  background-color: var(--vera5-button-bg);
  color: var(--vera5-accent-text);
  font-size: 11px;
  font-family: inherit;
}
.vera5-hover-card-scan-export-status {
  margin: 8px 0 0;
  font-size: 11px;
  line-height: 1.4;
  color: var(--vera5-text-muted);
}
.vera5-hover-card-scan-export-status--success {
  color: var(--vera5-success-text);
}
.vera5-hover-card-scan-export-status--error {
  color: var(--vera5-danger-text);
}
.vera5-hover-card-export-button {
  font-size: 11px;
  font-weight: 600;
  padding: 4px 8px;
  border-radius: 4px;
  border: 1px solid var(--vera5-border);
  background-color: var(--vera5-button-bg);
  color: var(--vera5-accent-text);
  cursor: pointer;
  transition: background-color 0.15s ease, color 0.15s ease;
}
.vera5-hover-card-export-dropdown {
  position: relative;
}
.vera5-hover-card-export-dropdown-menu {
  position: absolute;
  left: 0;
  bottom: calc(100% + 4px);
  z-index: 1;
  min-width: 100%;
  margin: 0;
  padding: 4px 0;
  list-style: none;
  border-radius: 4px;
  border: 1px solid var(--vera5-border);
  background-color: var(--vera5-button-bg);
  box-shadow: var(--vera5-shadow);
}
.vera5-hover-card-export-dropdown-item {
  display: block;
  width: 100%;
  box-sizing: border-box;
  padding: 6px 10px;
  border: 0;
  background: transparent;
  color: var(--vera5-accent-text);
  font: inherit;
  font-size: 11px;
  font-weight: 600;
  text-align: left;
  cursor: pointer;
}
.vera5-hover-card-export-dropdown-item:hover,
.vera5-hover-card-export-dropdown-item:focus-visible {
  background-color: color-mix(in srgb, var(--vera5-accent) 12%, transparent);
  outline: none;
}
.vera5-ioc-highlight {
  --vera5-highlight-accent: #ffb224;
  --vera5-highlight-underline: color-mix(in srgb, #ffb224 85%, transparent);
  --vera5-highlight-bg: color-mix(in srgb, #ffb224 22%, transparent);
  --vera5-highlight-badge-text: #0b0e11;
  --vera5-highlight-badge-bg: color-mix(in srgb, #ffb224 70%, #0b0e11);
  --vera5-enrich-icon: #ffb224;
  display: inline;
  box-decoration-break: clone;
  -webkit-box-decoration-break: clone;
  font: inherit;
  line-height: inherit;
  letter-spacing: inherit;
  text-decoration: underline;
  text-decoration-thickness: 1px;
  text-underline-offset: 2px;
  text-decoration-color: var(--vera5-highlight-underline);
  background-color: var(--vera5-highlight-bg);
  border-radius: 2px;
  padding: 0 1px;
  margin: 0;
  vertical-align: baseline;
  white-space: inherit;
  cursor: pointer;
}
.vera5-ioc-highlight:focus-visible {
  outline: 2px solid var(--vera5-highlight-accent);
  outline-offset: 2px;
}
.vera5-ioc-badge {
  display: inline;
  font-size: 0.65em;
  font-weight: 600;
  line-height: 1;
  margin-left: 2px;
  padding: 0 3px;
  vertical-align: super;
  border-radius: 3px;
  color: var(--vera5-highlight-badge-text);
  background-color: var(--vera5-highlight-badge-bg);
  letter-spacing: 0.02em;
  white-space: nowrap;
}
.vera5-ioc-enrich-icon {
  display: inline;
  font-size: 0.6em;
  line-height: 1;
  margin-left: 2px;
  vertical-align: super;
  color: var(--vera5-enrich-icon);
  opacity: 0.9;
  white-space: nowrap;
}
@media (prefers-reduced-motion: reduce) {
  .vera5-hover-card-panel,
  .vera5-hover-card-copy,
  .vera5-hover-card-export-button,
  .vera5-hover-card-pivot-link,
  .vera5-hover-card-enrichment--loading,
  .vera5-ioc-highlight {
    animation: none !important;
    transition: none !important;
  }
  .vera5-hover-card-enrichment--loading {
    font-style: normal;
  }
}
@media (prefers-color-scheme: dark) {
  .vera5-hover-card-panel {
    --vera5-surface: #12171e;
    --vera5-text: #f5f7fa;
    --vera5-border: #313a45;
    --vera5-accent: #ffb224;
    --vera5-accent-text: #f5f7fa;
    --vera5-muted: #a7b0ba;
    --vera5-muted-label: #a7b0ba;
    --vera5-error: #ff4d5a;
    --vera5-ready: #f5f7fa;
    --vera5-button-bg: #19202a;
    --vera5-copy-success-bg: color-mix(in srgb, #22c7a9 16%, #12171e);
    --vera5-shadow: 0 6px 18px rgba(0, 0, 0, 0.28);
  }
  .vera5-hover-card-source-badge--ok {
    color: #22c7a9;
    background-color: color-mix(in srgb, #22c7a9 22%, #12171e);
    border-color: color-mix(in srgb, #22c7a9 40%, #313a45);
  }
  .vera5-hover-card-source-badge--error {
    color: #ff4d5a;
    background-color: color-mix(in srgb, #ff4d5a 20%, #12171e);
    border-color: color-mix(in srgb, #ff4d5a 40%, #313a45);
  }
}
.vera5-workspace-host {
  position: fixed;
  top: 0;
  right: 0;
  width: calc(var(--vera5-workspace-width, 380px) + var(--vera5-workspace-gutter, 8px));
  height: 100vh;
  z-index: 2147483645;
  pointer-events: auto;
  box-sizing: border-box;
  padding: 8px 8px 8px 0;
}
.vera5-workspace-host[hidden] {
  display: none !important;
}
html.vera5-workspace-open {
  margin-right: var(--vera5-workspace-width, 388px);
  transition: margin-right 0.2s ease;
}
.vera5-workspace-sidebar {
  display: flex;
  flex-direction: column;
  flex: 1 1 auto;
  min-width: 0;
  height: 100%;
  background: #12171e;
  color: #f5f7fa;
  border: 1px solid #313a45;
  border-radius: 12px;
  box-shadow: -8px 0 24px rgba(0, 0, 0, 0.35);
  font-family: system-ui, -apple-system, "Segoe UI", Roboto, sans-serif;
  box-sizing: border-box;
  overflow: hidden;
}
.vera5-workspace-shell {
  position: relative;
  display: flex;
  align-items: stretch;
  height: calc(100vh - 16px);
}
.vera5-workspace-edge-tab {
  position: absolute;
  left: -13px;
  top: 50%;
  transform: translateY(-50%);
  width: 22px;
  height: 52px;
  padding: 0;
  margin: 0;
  border: 1px solid #313a45;
  border-right: none;
  border-radius: 8px 0 0 8px;
  background: #222b36;
  color: #ffb224;
  font-size: 18px;
  font-weight: 700;
  line-height: 1;
  cursor: pointer;
  z-index: 2;
  box-shadow: -3px 0 10px rgba(0, 0, 0, 0.28);
}
.vera5-workspace-edge-tab:hover,
.vera5-workspace-edge-tab:focus-visible {
  background: #222b36;
  color: #ffc24d;
  outline: none;
  box-shadow: 0 0 0 3px rgba(255, 178, 36, 0.35);
}
.vera5-workspace-sidebar--collapsed .vera5-workspace-top,
.vera5-workspace-sidebar--collapsed .vera5-workspace-bottom,
.vera5-workspace-sidebar--collapsed .vera5-workspace-divider {
  display: none;
}
.vera5-workspace-sidebar--collapsed .vera5-workspace-title {
  display: none;
}
.vera5-workspace-sidebar--collapsed .vera5-workspace-header {
  justify-content: center;
  padding-left: 8px;
  padding-right: 8px;
}
.vera5-workspace-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  padding: 12px 14px 10px;
  border-bottom: 1px solid #222b36;
  flex-shrink: 0;
}
.vera5-workspace-title {
  display: inline-flex;
  align-items: center;
  gap: 7px;
  margin: 0;
  font-family: "Space Grotesk", "Inter", system-ui, sans-serif;
  font-size: 18px;
  font-weight: 700;
  letter-spacing: -0.03em;
  color: #f5f7fa;
  text-decoration: none;
}
.vera5-workspace-title-mark {
  flex: 0 0 auto;
  width: 20px;
  height: 20px;
}
.vera5-workspace-title-5 {
  color: #ffb224;
  text-shadow: 0 0 26px rgba(255, 178, 36, 0.22);
}
.vera5-workspace-title:hover,
.vera5-workspace-title:focus-visible {
  color: #f5f7fa;
  text-decoration: none;
  outline: none;
  box-shadow: 0 0 0 3px rgba(255, 178, 36, 0.45);
  border-radius: 4px;
}
.vera5-workspace-close {
  flex-shrink: 0;
  width: 28px;
  height: 28px;
  padding: 0;
  font-size: 18px;
  font-weight: 600;
  line-height: 1;
  border-radius: 6px;
  border: 1px solid #313a45;
  background: #222b36;
  color: #a7b0ba;
  cursor: pointer;
}
.vera5-workspace-top,
.vera5-workspace-bottom {
  flex: 1 1 0;
  min-height: 0;
  overflow: auto;
  padding: 12px 14px;
  scrollbar-color: #313a45 #12171e;
  scrollbar-width: thin;
}
.vera5-workspace-top::-webkit-scrollbar,
.vera5-workspace-bottom::-webkit-scrollbar {
  width: 10px;
  height: 10px;
}
.vera5-workspace-top::-webkit-scrollbar-track,
.vera5-workspace-bottom::-webkit-scrollbar-track {
  background: #12171e;
}
.vera5-workspace-top::-webkit-scrollbar-thumb,
.vera5-workspace-bottom::-webkit-scrollbar-thumb {
  background: #313a45;
  border-radius: 999px;
  border: 2px solid #12171e;
}
.vera5-workspace-top::-webkit-scrollbar-button,
.vera5-workspace-bottom::-webkit-scrollbar-button {
  background: #313a45;
}
.vera5-workspace-divider {
  flex-shrink: 0;
  height: 4px;
  background: #313a45;
  border: 0;
  margin: 0;
}
.vera5-workspace-empty {
  margin: 0;
  font-size: 12px;
  line-height: 1.5;
  color: #a7b0ba;
}
.vera5-workspace-toggle-row {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  margin-bottom: 10px;
}
.vera5-workspace-toggle {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  flex: 1 1 calc(50% - 4px);
  min-width: 0;
  padding: 6px 8px 6px 10px;
  border-radius: 999px;
  border: 1px solid #313a45;
  background: #222b36;
  color: #a7b0ba;
  font-size: 11px;
  font-weight: 600;
  cursor: pointer;
  text-align: left;
}
.vera5-workspace-toggle-label {
  flex: 1 1 auto;
  min-width: 0;
  line-height: 1.2;
}
.vera5-workspace-toggle-switch {
  position: relative;
  flex-shrink: 0;
  width: 30px;
  height: 16px;
  border-radius: 999px;
  background: #222b36;
  border: 1px solid #313a45;
  transition: background 0.15s ease, border-color 0.15s ease;
}
.vera5-workspace-toggle-knob {
  position: absolute;
  top: 1px;
  left: 1px;
  width: 12px;
  height: 12px;
  border-radius: 50%;
  background: #a7b0ba;
  transition: transform 0.15s ease, background 0.15s ease;
}
.vera5-workspace-toggle--on {
  border-color: #313a45;
  background: #222b36;
  color: #a7b0ba;
}
.vera5-workspace-toggle--on .vera5-workspace-toggle-switch {
  background: #ffb224;
  border-color: #ffb224;
}
.vera5-workspace-toggle--on .vera5-workspace-toggle-knob {
  transform: translateX(14px);
  background: #0b0e11;
}
.vera5-workspace-toggle:disabled {
  opacity: 0.65;
  cursor: not-allowed;
}
.vera5-workspace-button {
  display: block;
  width: 100%;
  box-sizing: border-box;
  margin-bottom: 8px;
  padding: 8px 12px;
  border-radius: 6px;
  border: 1px solid #313a45;
  background: #19202a;
  color: #f5f7fa;
  font-size: 13px;
  font-weight: 600;
  cursor: pointer;
  transition: background-color 0.14s ease, border-color 0.14s ease,
    box-shadow 0.14s ease;
}
.vera5-workspace-button:hover:not(:disabled) {
  background: #222b36;
  border-color: rgba(255, 178, 36, 0.38);
}
.vera5-workspace-button--primary {
  border-color: transparent;
  background: #ffb224;
  color: #0b0e11;
}
.vera5-workspace-button--primary:hover:not(:disabled) {
  background: #ffc24d;
  border-color: #ffc24d;
}
.vera5-workspace-sidebar button:hover:not(:disabled),
.vera5-workspace-sidebar .vera5-hover-card-pivot-link:hover {
  box-shadow: 0 0 0 1.5px rgba(255, 178, 36, 0.45), 0 4px 16px rgba(255, 178, 36, 0.18);
}
.vera5-workspace-button:disabled {
  opacity: 0.65;
  cursor: not-allowed;
  border-color: #313a45;
  background: #222b36;
  color: #a7b0ba;
}
.vera5-workspace-tray-heading-row {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  margin: 14px 0 8px;
  padding-top: 12px;
  border-top: 1px solid #313a45;
}
.vera5-workspace-tray-heading {
  margin: 0;
  font-size: 15px;
  font-weight: 600;
  color: #f5f7fa;
}
.vera5-workspace-icon-button {
  flex-shrink: 0;
  width: 28px;
  height: 28px;
  padding: 0;
  border-radius: 6px;
  border: 1px solid #313a45;
  background: #222b36;
  color: #a7b0ba;
  font-size: 16px;
  line-height: 1;
  cursor: pointer;
}
.vera5-workspace-icon-button:disabled {
  opacity: 0.65;
  cursor: not-allowed;
}
.vera5-workspace-icon-button--spinning {
  animation: vera5-workspace-spin 0.8s linear infinite;
}
.vera5-hover-card-detail-clear {
  width: 28px;
  height: 28px;
  padding: 0;
  border-radius: 6px;
  border: 1px solid #313a45;
  background: #222b36;
  color: #a7b0ba;
  font-size: 16px;
  line-height: 1;
  cursor: pointer;
}
.vera5-hover-card-detail-clear:hover {
  background: #222b36;
  color: #ffc24d;
}
@keyframes vera5-workspace-spin {
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
}
.vera5-workspace-tray-summary {
  margin: 0 0 10px;
  font-size: 12px;
  color: #a7b0ba;
}
.vera5-workspace-filter-row {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
  margin-bottom: 10px;
}
.vera5-workspace-filter-chip {
  padding: 4px 8px;
  border-radius: 999px;
  border: 1px solid #313a45;
  background: #222b36;
  color: #a7b0ba;
  font-size: 11px;
  font-weight: 600;
  cursor: pointer;
}
.vera5-workspace-filter-chip[aria-pressed="true"] {
  border-color: #ffb224;
  background: #ffb224;
  color: #0b0e11;
}
.vera5-workspace-tray-list {
  list-style: none;
  margin: 0;
  padding: 0;
  display: flex;
  flex-direction: column;
  gap: 6px;
}
.vera5-workspace-tray-row {
  display: flex;
  flex-direction: column;
  align-items: stretch;
  gap: 4px;
  padding: 6px 8px;
  border-radius: 6px;
  border: 1px solid transparent;
  background: #19202a;
  font-size: 12px;
  line-height: 1.4;
  cursor: pointer;
  transition: background-color 0.14s ease;
}
.vera5-workspace-tray-row:hover {
  background: #222b36;
}
.vera5-workspace-tray-row-main {
  display: flex;
  align-items: flex-start;
  gap: 8px;
}
.vera5-workspace-tray-row--bulk-selected {
  border-color: color-mix(in srgb, #ffb224 45%, #313a45);
}
.vera5-workspace-tray-row--pinned {
  border-color: color-mix(in srgb, var(--vera5-accent) 35%, #313a45);
}
.vera5-workspace-tray-pin {
  flex-shrink: 0;
  margin-top: 1px;
  color: var(--vera5-accent-text);
  font-size: 12px;
  line-height: 1;
}
.vera5-workspace-tray-select {
  flex-shrink: 0;
  margin-top: 2px;
  cursor: pointer;
}
.vera5-workspace-tray-bulk-row {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  margin-top: 8px;
}
.vera5-workspace-tray-queue-status {
  margin: 8px 0 0;
  font-size: 12px;
  color: #a7b0ba;
  line-height: 1.5;
}
.vera5-tray-enrich-queue-warning-backdrop {
  position: fixed;
  inset: 0;
  z-index: 2147483646;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 16px;
  background: rgba(15, 23, 42, 0.72);
}
.vera5-tray-enrich-queue-warning-panel {
  width: min(420px, 100%);
  padding: 16px;
  border-radius: 8px;
  border: 1px solid #313a45;
  background: #12171e;
  color: #f5f7fa;
  box-shadow: 0 16px 40px rgba(15, 23, 42, 0.45);
}
.vera5-tray-enrich-queue-warning-heading {
  margin: 0 0 8px;
  font-size: 14px;
  font-weight: 700;
}
.vera5-tray-enrich-queue-warning-message {
  margin: 0 0 12px;
  white-space: pre-wrap;
  font-size: 12px;
  line-height: 1.5;
  color: #a7b0ba;
}
.vera5-tray-enrich-queue-warning-actions {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
}
.vera5-workspace-tray-row[aria-selected="true"] {
  border-color: #ffb224;
  background: color-mix(in srgb, #ffb224 12%, #19202a);
}
.vera5-workspace-tray-type {
  flex-shrink: 0;
  padding: 1px 6px;
  border-radius: 4px;
  background: #222b36;
  color: #a7b0ba;
  font-size: 10px;
  font-weight: 700;
}
.vera5-workspace-tray-value {
  flex: 1;
  min-width: 0;
  word-break: break-all;
  color: #f5f7fa;
  font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
  font-size: 13px;
  display: flex;
  flex-direction: column;
  gap: 2px;
}
.vera5-workspace-tray-value-on-page {
  display: block;
  word-break: break-all;
  color: #f5f7fa;
}
.vera5-workspace-tray-refanged-value {
  display: block;
  word-break: break-all;
  font-size: 11px;
  line-height: 1.45;
  color: #a7b0ba;
}
.vera5-workspace-tray-hint {
  flex-shrink: 0;
  font-size: 10px;
  font-weight: 600;
  padding: 1px 6px;
  border-radius: 4px;
  background: #222b36;
  color: #a7b0ba;
  pointer-events: none;
  user-select: none;
}
.vera5-workspace-tray-hint--live {
  color: #22c7a9;
}
.vera5-workspace-tray-hint--error {
  color: #ff4d5a;
}
.vera5-workspace-error {
  margin: 8px 0 0;
  font-size: 12px;
  color: #ff4d5a;
  line-height: 1.5;
}
.vera5-workspace-detail-panel {
  max-width: none !important;
  width: 100%;
  border: 0 !important;
  border-radius: 0 !important;
  box-shadow: none !important;
  animation: none !important;
  padding: 0 !important;
  --vera5-surface: #12171e;
  --vera5-text: #f5f7fa;
  --vera5-border: #313a45;
  --vera5-accent: #ffb224;
  --vera5-accent-text: #f5f7fa;
  --vera5-muted: #a7b0ba;
  --vera5-muted-label: #a7b0ba;
  --vera5-error: #ff4d5a;
  --vera5-ready: #f5f7fa;
  --vera5-button-bg: #19202a;
  --vera5-copy-success-bg: color-mix(in srgb, #22c7a9 16%, #12171e);
  --vera5-shadow: none;
}
.vera5-command-palette-backdrop {
  position: fixed;
  inset: 0;
  z-index: 2147483646;
  display: flex;
  align-items: flex-start;
  justify-content: center;
  padding: 12vh 16px 16px;
  background: rgba(15, 23, 42, 0.45);
}
.vera5-command-palette-panel {
  box-sizing: border-box;
  width: min(560px, 100%);
  max-height: min(70vh, 520px);
  display: flex;
  flex-direction: column;
  gap: 8px;
  padding: 12px;
  border-radius: 10px;
  border: 1px solid #313a45;
  background: #12171e;
  color: #f5f7fa;
  font-family: system-ui, sans-serif;
  box-shadow: 0 16px 40px rgba(15, 23, 42, 0.18);
}
.vera5-command-palette-input {
  box-sizing: border-box;
  width: 100%;
  padding: 10px 12px;
  border: 1px solid #313a45;
  border-radius: 8px;
  background: #19202a;
  color: #f5f7fa;
  font: 14px/1.4 system-ui, sans-serif;
}
.vera5-command-palette-input:focus-visible {
  outline: 2px solid #ffb224;
  outline-offset: 1px;
}
.vera5-command-palette-list {
  display: flex;
  flex-direction: column;
  gap: 4px;
  overflow: auto;
  max-height: min(48vh, 360px);
}
.vera5-command-palette-item {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  gap: 2px;
  width: 100%;
  padding: 8px 10px;
  border: 1px solid transparent;
  border-radius: 8px;
  background: transparent;
  color: inherit;
  text-align: left;
  cursor: pointer;
  font: inherit;
}
.vera5-command-palette-item:hover,
.vera5-command-palette-item--selected {
  border-color: #313a45;
  background: #19202a;
}
.vera5-command-palette-item-label {
  font-size: 14px;
  font-weight: 600;
  color: #f5f7fa;
}
.vera5-command-palette-item-description {
  font-size: 12px;
  color: #a7b0ba;
}
.vera5-command-palette-empty,
.vera5-command-palette-hint {
  margin: 0;
  font-size: 12px;
  color: #6b7480;
}
@media (prefers-color-scheme: dark) {
  .vera5-command-palette-panel {
    border-color: #313a45;
    background: #19202a;
    color: #f5f7fa;
    box-shadow: none;
  }
  .vera5-command-palette-input {
    border-color: #313a45;
    background: #12171e;
    color: #f5f7fa;
  }
  .vera5-command-palette-item:hover,
  .vera5-command-palette-item--selected {
    border-color: #313a45;
    background: #12171e;
  }
  .vera5-command-palette-item-label {
    color: #a7b0ba;
  }
  .vera5-command-palette-item-description,
  .vera5-command-palette-empty,
  .vera5-command-palette-hint {
    color: #a7b0ba;
  }
}
@media (prefers-reduced-motion: reduce) {
  html.vera5-workspace-open {
    transition: none;
  }
  .vera5-workspace-icon-button--spinning {
    animation: none;
  }
  .vera5-workspace-toggle-switch,
  .vera5-workspace-toggle-knob {
    transition: none;
  }
}
`.trim()}function Ft(e=document){if(e.getElementById(Ua))return;const t=e.createElement("style");t.id=Ua,t.textContent=mh(),e.head?.appendChild(t)}const tt="vera5-ioc-highlight",Ys="vera5-ioc-badge",Ks="vera5-ioc-enrich-icon",hh={ipv4:"IP",domain:"DOM",url:"URL",md5:"MD5",sha1:"SHA1",sha256:"SHA256",cve:"CVE",email:"EML",asn:"ASN",cidr:"CIDR",filepath:"PATH",onion:"ONION"};let Va=0;function gh(){return Va+=1,`vera5-hl-${Va}`}function vh(e){return e instanceof Document?e.body??e.documentElement:e}function Eh(e=document){Ft(e)}function yh(e){return e.dataset.vera5DisplayValue}function Sh(e){const t=e.dataset.vera5RuleId,n=e.dataset.vera5SourceTextHint;return!t||!n?null:{ruleId:t,sourceTextHint:n,ignoredOverlaps:bh(e)}}function bh(e){const t=e.dataset.vera5IgnoredOverlaps;if(!t)return[];try{const n=JSON.parse(t);if(!Array.isArray(n))return[];const r=[];for(const o of n){if(o===null||typeof o!="object")continue;const a=o;typeof a.type=="string"&&typeof a.value=="string"&&typeof a.ruleId=="string"&&a.value.length>0&&a.ruleId.length>0&&r.push({type:a.type,value:a.value,ruleId:a.ruleId})}return r}catch{return[]}}function On(e=document.body){const t=vh(e),n=Array.from(t.querySelectorAll(`.${tt}`));for(const r of n)Ch(r);return n.length}function Ch(e){const t=e.parentNode;if(t){for(e.querySelectorAll(`.${Ys}`).forEach(n=>{n.remove()});e.firstChild;)t.insertBefore(e.firstChild,e);t.removeChild(e),t.normalize()}}function Ah(e,t,n,r){const o=e.createElement("span");o.className=tt,o.dataset.vera5Ioc="true",o.dataset.vera5Type=n.type,o.dataset.vera5Value=n.value,o.dataset.vera5AnchorId=r,o.dataset.vera5RuleId=n.ruleId,o.dataset.vera5SourceTextHint=n.sourceTextHint,n.displayValue&&(o.dataset.vera5DisplayValue=n.displayValue),n.ignoredOverlaps&&n.ignoredOverlaps.length>0&&(o.dataset.vera5IgnoredOverlaps=JSON.stringify(n.ignoredOverlaps));const a=hh[n.type]??n.type.toUpperCase();o.setAttribute("role","button"),o.setAttribute("tabindex","0"),o.setAttribute("aria-label",`View indicator details for ${n.value}`),o.appendChild(e.createTextNode(t));const i=e.createElement("span");i.className=Ys,i.setAttribute("aria-hidden","true"),i.textContent=a,o.appendChild(i);const s=e.createElement("span");return s.className=Ks,s.setAttribute("aria-hidden","true"),s.textContent="›",o.appendChild(s),o}function _h(e,t){const n=new Map;for(const r of e){const{textNode:o}=r;if(!o.isConnected||!t.contains(o)||o.parentElement?.closest(`.${tt}`))continue;const a=n.get(o)??[];a.push(r),n.set(o,a)}return n}function Ih(e){if(!e.textNode.isConnected)return!1;const t=e.textNode.data;return e.start<0||e.end>t.length||e.start>=e.end?!1:t.slice(e.start,e.end)===e.value}function Th(e,t,n,r){const o=e.filter(Ih);return o.length>0||!n?o:lh(t,r)}function xh(e,t,n,r){const o=e.data,a=[...t].sort((u,p)=>u.start-p.start),i=n.createDocumentFragment();let s=0,l=0;for(const u of a){if(u.start<s||u.end>o.length||u.start>=u.end)continue;u.start>s&&i.appendChild(n.createTextNode(o.slice(s,u.start)));const p=gh();i.appendChild(Ah(n,o.slice(u.start,u.end),u,p)),r.push({anchorId:p,type:u.type,value:u.value,ruleId:u.ruleId,sourceTextHint:u.sourceTextHint,...u.displayValue?{displayValue:u.displayValue}:{},...u.ignoredOverlaps&&u.ignoredOverlaps.length>0?{ignoredOverlaps:[...u.ignoredOverlaps]}:{}}),s=u.end,l+=1}return l===0?0:(s<o.length&&i.appendChild(n.createTextNode(o.slice(s))),e.parentNode?.replaceChild(i,e),l)}function Lh(e,t={}){const n=t.root??document.body,r=t.doc??n.ownerDocument??document;Eh(r);const o=t.clearExisting!==!1;o&&On(n);const a=Th(e,n,o,t.scan),i=_h(a,n),s=[];let l=0;for(const u of i.values()){const p=u[0]?.textNode;p?.isConnected&&(l+=xh(p,u,r,s))}return{highlightedCount:l,skippedCount:Math.max(0,a.length-l),anchorLinks:s}}function Nh(e,t=document.body){return t.querySelector(`.${tt}[data-vera5-anchor-id="${CSS.escape(e)}"]`)}function wh(e=document.body){return Array.from(e.querySelectorAll(`.${tt}`)).filter(t=>t.isConnected)}function Rh(e,t,n=document.body){const r=wh(n);if(r.length===0)return null;if(!e)return t==="next"?r[0]:r[r.length-1];const o=r.indexOf(e);if(o===-1)return t==="next"?r[0]:r[r.length-1];const i=(o+(t==="next"?1:-1)+r.length)%r.length;return r[i]??null}function Oh(e){return e!==null&&typeof e=="object"&&"type"in e&&e.type===ve.SCAN_PAGE}function kh(e){return e!==null&&typeof e=="object"&&"type"in e&&e.type===ve.SCAN_SELECTION}function Bt(e=document){const t=e.getSelection();return!t||t.rangeCount===0||t.isCollapsed?null:t.getRangeAt(0).cloneRange()}function Dh(e,t,n){return n?Lh(e,{root:t,clearExisting:!0}).anchorLinks:(On(t),[])}async function xo(){const[e,t]=await Promise.all([Qm(),Zm()]);return{ioc:{includePrivateIpv4:e,enabledTypes:t}}}function Mh(e,t){return t.length>0?t.map(({type:n,value:r,anchorId:o,ruleId:a,sourceTextHint:i,displayValue:s,ignoredOverlaps:l})=>({type:n,value:r,anchorId:o,ruleId:a,sourceTextHint:i,...s?{displayValue:s}:{},...l&&l.length>0?{ignoredOverlaps:[...l]}:{}})):Bu(e)}async function Ph(e){const t=Fu({pageUrl:window.location.href,entries:[...e]}),n=await q(Ku(t));if(!n||typeof n!="object"||!("ok"in n))return{tabId:null,snapshot:t};if(n.ok!==!0)return{tabId:null,snapshot:t};const r=n.payload;return{tabId:r!==null&&typeof r=="object"&&"tabId"in r&&typeof r.tabId=="number"?r.tabId:null,snapshot:t}}async function Ws(e,t,n){const r=await Jm(),o=Dh(e,t,r),a=Mh(e,o),{tabId:i,snapshot:s}=await Ph(a);return e.length,{ok:!0,payload:{count:e.length,tabId:i,snapshot:s,profile:n}}}async function $t(e=document.body){const t=await xo(),{matches:n,profile:r}=zs(e,t);return Ws(n,e,r)}async function js(e=document.body){const t=Bt(document);if(!t)return{ok:!1,error:"No text selected."};const n=await xo(),{matches:r,profile:o}=dh(t,e,n);let a=t.commonAncestorContainer;return a.nodeType===Node.TEXT_NODE&&(a=a.parentNode??e),Ws(r,a,o)}function Hh(){chrome.runtime.onMessage.addListener((e,t,n)=>Oh(e)?($t().then(n).catch(r=>{_(r)}),!0):kh(e)?(js().then(n).catch(r=>{_(r)}),!0):!1)}function Uh(){chrome.storage.onChanged.addListener((e,t)=>{Cn(()=>{t==="local"&&e[fr]?.newValue===!1&&On(document.body)})})}const qs=400;let rn=null,yt=null,Xs=qs,hr=document.body,Js;function Qs(){yt!==null&&(clearTimeout(yt),yt=null)}async function Vh(){await Io()&&$t(hr).then(t=>{Js?.(t)}).catch(R)}function Fh(){Qs(),yt=setTimeout(()=>{yt=null,Vh()},Xs)}function Bh(e={}){return e.enabled!==!0?()=>{}:(gr(),Xs=e.debounceMs??qs,hr=e.root??document.body,Js=e.onScan,rn=new MutationObserver(()=>{Fh()}),rn.observe(hr,{childList:!0,subtree:!0,characterData:!0}),gr)}function gr(){Qs(),rn?.disconnect(),rn=null}let qt=null;function Zs(e=document){return e.location.hostname.trim().toLowerCase()}function $h(e){if(qt&&(qt(),qt=null),!e){gr();return}qt=Bh({enabled:!0})}async function ec(e=document){Zs(e);const t=await qm(e);$h(t)}async function Gh(e=document){Zs(e),await ec(e)}function zh(e=document){chrome.storage.onChanged.addListener((t,n)=>{Cn(()=>{n!=="local"||!Xm.some(o=>o in t)||ec(e)})})}let Lo=!1;function Yh(){return Lo}async function Kh(){const t=(await k(Ye))[Ye];Lo=t===void 0?!1:!!t}function Wh(){typeof chrome>"u"||!chrome.storage?.onChanged||chrome.storage.onChanged.addListener((e,t)=>{if(t!=="local")return;const n=e[Ye];n&&(Lo=!!n.newValue)})}let No=!1;function tc(){return No}async function jh(){const t=(await k(Ke))[Ke];No=t===void 0?!1:!!t}function qh(){typeof chrome>"u"||!chrome.storage?.onChanged||chrome.storage.onChanged.addListener((e,t)=>{if(t!=="local")return;const n=e[Ke];n&&(No=!!n.newValue)})}const nc=["benign","internal","suppress-false-positive","case-important"],Xh={benign:"Benign",internal:"Internal","suppress-false-positive":"Suppress false positive","case-important":"Case important"};function Jh(e){return typeof e=="string"&&nc.includes(e)}function wo(e){return Jh(e)?e:null}function Qh(e){return Xh[e]}const Nt="iocLabels";function rc(){return typeof chrome<"u"&&chrome.storage?.local!==void 0&&!D()}function Ro(e){return j(e)}function vr(e){if(e===null||typeof e!="object"||Array.isArray(e))return{};const t={};for(const[n,r]of Object.entries(e)){if(typeof n!="string")continue;const o=n.trim(),a=wo(r);o.length===0||!a||(t[o]=a)}return t}async function Oo(){if(!rc())return{};const e=await k(Nt);return vr(e[Nt])}async function Zh(e){const t=Ro(e);return t.length===0?null:(await Oo())[t]??null}async function eg(e,t){if(!rc())return;const n=Ro(e);if(n.length===0)return;const r=await Oo(),o=t?wo(t):null;if(o?r[n]=o:delete r[n],Object.keys(r).length===0){await Xr(Nt);return}await qr({[Nt]:r})}const wt=new Map;let oc=!1;function ko(){return typeof chrome<"u"&&chrome.storage?.local!==void 0&&!D()}function tn(){oc=!0}function ac(e){return Ro(e)}function ic(e,t){const n=ac(e);if(!t){wt.delete(n);return}wt.set(n,t)}function on(e){return wt.get(ac(e))??null}function tg(e,t){const n=t?wo(t):null;ic(e,n),ko()&&eg(e,n).catch(R)}function sc(e,t){ic(e,t)}async function ng(){if(!ko()){tn();return}try{const e=await Oo();for(const[t,n]of Object.entries(e))wt.has(t)||wt.set(t,n);tn()}catch(e){R(e),tn()}}function rg(e,t){const n=on(e);if(n){t(n);return}if(!oc){if(!ko()){tn();return}Zh(e).then(r=>{r&&(on(e)||(sc(e,r),t(r)))}).catch(R)}}function og(e,t){const n=on(e);return n||(t??null)}const an="enrichmentCache",ag=500,ig="|";function cc(){return{}}function sg(e){return e===null||typeof e!="object"||Array.isArray(e)?!1:Object.values(e).every(t=>{if(t===null||typeof t!="object"||Array.isArray(t))return!1;const n=t;return typeof n.fetchedAt=="number"&&Number.isFinite(n.fetchedAt)&&"payload"in n})}function cg(e){return sg(e)?{...e}:cc()}function sn(e){return Object.keys(e).length}function lg(e,t="oldest"){const n=Object.keys(e);return n.sort((r,o)=>{const a=e[r]?.fetchedAt??0,i=e[o]?.fetchedAt??0;return t==="oldest"?a-i:i-a}),n}function ug(e,t=ag,n=new Set){if(!Number.isFinite(t)||t<=0)return cc();const r={...e},o=a=>{for(;sn(r)>t;){const i=lg(r,"oldest").filter(s=>!a||!n.has(s));if(i.length===0)break;delete r[i[0]]}};return o(!0),o(!1),r}function dg(e,t){const n=e.trim();return n.length===0?null:`${n}${ig}${t}`}function pg(e,t=Date.now()){return Math.max(0,t-e.fetchedAt)}function fg(e,t,n=Date.now()){if(!Number.isFinite(t)||t<=0)return!0;const r=t*1e3;return pg(e,n)>=r}function mg(e,t,n={}){if(Object.prototype.hasOwnProperty.call(n,e)){const r=n[e];if(r!==void 0)return r}return t}function hg(e,t,n,r=Date.now()){const o=e[t];return!o||fg(o,n,r)?null:o}async function gg(e){const t=await wn();return mg(e,t.enrichmentCacheTtlSeconds,t.enrichmentSourceCacheTtlSeconds)}async function vg(){const e=await chrome.storage.local.get(an),t=cg(e[an]),n=ug(t);return sn(n)!==sn(t)&&await Eg(n),n}async function Eg(e){if(sn(e)===0){await Sg();return}await chrome.storage.local.set({[an]:e})}async function yg(e,t,n=Date.now()){const r=dg(e,t);if(!r)return null;const o=await gg(t),a=await vg();return hg(a,r,o,n)}async function Sg(e){await chrome.storage.local.remove(an)}async function lc(e,t,n=Date.now()){const r=await yg(e,t,n);if(!r)return null;const o=$p(r.payload);if(!o)return null;const a=o.status===_n.OK?!0:o.fromCache;return{...o,...a===!0?{fromCache:!0}:{},fetchedAt:new Date(r.fetchedAt).toISOString()}}async function bg(e,t,n=Date.now()){const r=await lc(e,t,n);return!r||r.status!==_n.OK?null:r}const Fa=200,Ba=4e3,Cg=5e3,Ag=new Set(Object.values(d));function Er(e){if(typeof e!="string")return null;const t=e.trim();return t.length>0?t:null}function $a(e){return typeof e!="number"||!Number.isFinite(e)?null:e}function _g(e){return typeof e=="string"&&Ag.has(e)}function Ig(e){return j(e)}function Tg(e){return`${e.iocType}:${e.value}`}function xg(e){if(e===null||typeof e!="object"||Array.isArray(e))return null;const t=e;if(!_g(t.iocType))return null;const n=Er(t.value);return n?{iocType:t.iocType,value:Ig(n)}:null}function kn(e){const t=e.trim();return t.length===0?null:t.length>Fa?t.slice(0,Fa):t}function Lg(e){if(e===void 0)return;const t=e.trim();if(t.length!==0)return t.length>Ba?t.slice(0,Ba):t}function Ng(e){if(!Array.isArray(e)||e.length>Cg)return!1;const t=new Set;for(const n of e){const r=xg(n);if(!r)return!1;const o=Tg(r);if(t.has(o)||(t.add(o),JSON.stringify(n)!==JSON.stringify(r)))return!1}return!0}function Dn(e){if(e===null||typeof e!="object"||Array.isArray(e))return!1;const t=e,n=Er(t.id),r=Er(t.name),o=$a(t.createdAt),a=$a(t.updatedAt);if(!n||!r||o===null||a===null||a<o||r!==kn(r)||!Ng(t.members))return!1;if(t.description===void 0)return!0;if(typeof t.description!="string")return!1;const i=Lg(t.description);return i===void 0?!1:t.description===i}const uc="Save to collection…",St="Save to collection",Do="Create new collection",qe="Collection name",Mo="Save to new collection",Po="No saved collections yet.",Ga="Add filtered to collection…",za="Add filtered indicators to collection";function cn(e){return e.added?`Saved to ${e.collectionName}.`:`Already in ${e.collectionName}.`}function Ya(e){if(e.addedCount===0)return`All ${e.totalCount} filtered indicators were already in ${e.collectionName}.`;const t=e.addedCount===1?"indicator":"indicators";if(e.duplicateCount===0)return`Added ${e.addedCount} ${t} to ${e.collectionName}.`;const n=e.duplicateCount===1?"was":"were";return`Added ${e.addedCount} ${t} to ${e.collectionName}. ${e.duplicateCount} ${n} already saved.`}function wg(e){return e>0?`${Ga} (${e})`:Ga}const dc=1,Rg=new Set(Object.values(d)),yr={ipv4:"IP",domain:"DOM",url:"URL",md5:"MD5",sha1:"SHA1",sha256:"SHA256",cve:"CVE",email:"EML",asn:"ASN",cidr:"CIDR",filepath:"PATH",onion:"ONION"},Og=[d.URL,d.EMAIL,d.FILEPATH,d.ONION,d.SHA256,d.SHA1,d.MD5,d.CVE,d.CIDR,d.IPV4,d.ASN,d.DOMAIN];function kg(e){const t=new Set(e);return Og.filter(n=>t.has(n))}function pc(e){return kg(Object.entries(e.countByType).filter(([,t])=>typeof t=="number"&&t>0).map(([t])=>t))}function ke(e,t){return t==="all"?[...e]:e.filter(n=>n.type===t)}function Dg(e){const t=[`${e.totalCount} indicator${e.totalCount===1?"":"s"}`];for(const n of pc(e)){const r=e.countByType[n];r&&r>0&&t.push(`${r} ${yr[n]}`)}return t.join(" · ")}function Xt(e){return e.map(t=>t.value).join(`
`)}function Mg(e){if(e.length===0)return null;const t=e.reduce((r,o)=>o.fetchedAtMs>r.fetchedAtMs?o:r),n=t.status==="ok"&&t.fromCache===!0?!0:void 0;return{badgeText:es(t.status,n),sourceLabel:t.sourceLabel,status:t.status,...n===!0?{fromCache:!0}:{}}}async function Pg(e){const t=[];for(const n of Co){const r=await lc(e.value,n);if(!r?.fetchedAt)continue;const o=Date.parse(r.fetchedAt);Number.isFinite(o)&&t.push({fetchedAtMs:o,sourceLabel:r.sourceLabel,status:r.status,fromCache:r.fromCache})}return Mg(t)}function fc(e){return`${e.sourceLabel} · ${e.badgeText}`}function Hg(e,t){const n=`View ${e} on page`;return t?`${n}. ${fc(t)}`:n}async function Ug(e){const t={};return await Promise.all(e.map(async n=>{const r=await Pg(n);r&&(t[n.anchorId]=r)})),t}async function Vg(e){if(e.length===0)return[];const t=await wn(),n=$m(t.enrichmentSourceEnabled),r=new Date().toISOString(),o=[];for(const a of e){const i=[];for(const s of Co){if(n.includes(s))continue;const l=await bg(a.value,s);l&&i.push({sourceId:l.sourceId,sourceLabel:l.sourceLabel,status:l.status,summary:l.summary,tags:l.tags,fromCache:l.fromCache,fetchedAt:l.fetchedAt,errorCode:l.errorCode,errorMessage:l.errorMessage,retryHint:l.retryHint,rawVendorJson:l.rawVendorJson})}o.push(vs({value:a.value,iocType:a.iocType,sourceResults:ts(i),disabledSources:n,exportedAt:r}))}return o}async function mc(e){return Vg(e.map(t=>({iocType:t.type,value:t.value})))}function hc(e){const t={};for(const n of e)t[n.type]=(t[n.type]??0)+1;return t}function Fg(e){return typeof e.ruleId!="string"||e.ruleId.length===0||typeof e.sourceTextHint!="string"||e.sourceTextHint.length===0?null:{ruleId:e.ruleId,sourceTextHint:e.sourceTextHint,...e.ignoredOverlaps&&e.ignoredOverlaps.length>0?{ignoredOverlaps:[...e.ignoredOverlaps]}:{}}}function Bg(e){return{schemaVersion:dc,tabId:e.tabId,pageUrl:e.pageUrl,scannedAt:e.scannedAt,totalCount:e.entries.length,countByType:hc(e.entries),entries:e.entries.map(t=>({...t}))}}function gc(e){return typeof e=="string"&&Rg.has(e)}function $g(e){if(e===null||typeof e!="object")return!1;const t=e;return!(!(gc(t.type)&&typeof t.value=="string"&&t.value.length>0&&typeof t.anchorId=="string"&&t.anchorId.length>0)||t.ruleId!==void 0&&typeof t.ruleId!="string"||t.sourceTextHint!==void 0&&typeof t.sourceTextHint!="string")}function Gg(e){if(e===null||typeof e!="object")return!1;const t=e;if(t.schemaVersion!==dc||typeof t.tabId!="number"||!Number.isFinite(t.tabId)||typeof t.pageUrl!="string"||typeof t.scannedAt!="number"||!Number.isFinite(t.scannedAt)||typeof t.totalCount!="number"||!Number.isFinite(t.totalCount)||t.countByType===null||typeof t.countByType!="object")return!1;for(const[n,r]of Object.entries(t.countByType))if(!gc(n)||typeof r!="number"||!Number.isFinite(r))return!1;return!Array.isArray(t.entries)||t.entries.length!==t.totalCount?!1:t.entries.every($g)}function Jt(e){if(!e.copied)return"Could not copy to clipboard.";const t=e.count===1?"indicator":"indicators";return e.filtered?`Copied ${e.count} filtered ${t} to clipboard.`:`Copied ${e.count} ${t} to clipboard.`}function Ka(e){if(!e.success)return e.format==="markdown"?"Could not export Markdown.":"Could not export JSON.";const t=e.count===1?"indicator":"indicators",n=e.format==="markdown"?"Markdown":"JSON";return`Exported ${e.count} ${t} as ${n}.`}function Wa(e){if(!e.success)return`Could not export ${Tt(e.templateId)}.`;const t=e.count===1?"indicator":"indicators";return`Exported ${e.count} ${t} as ${Tt(e.templateId)}.`}function ja(e){if(!e.success)return e.format==="markdown"?"Could not copy Markdown.":"Could not copy JSON.";const t=e.count===1?"indicator":"indicators",n=e.format==="markdown"?"Markdown":"JSON";return`Copied ${e.count} filtered ${t} as ${n}.`}function qa(e){if(!e.success)return`Could not copy ${Tt(e.templateId)}.`;const t=e.count===1?"indicator":"indicators";return`Copied ${e.count} filtered ${t} as ${Tt(e.templateId)}.`}const Xa="vera5-inv-",Ja=200,Qa=4e3,Qt="Investigation",ln=100,zg=new Set(Object.values(d));function Za(e){if(typeof e!="string")return null;const t=e.trim();return t.length>0?t:null}function Rt(e){return typeof e!="number"||!Number.isFinite(e)?null:e}function Mn(e){return typeof e=="string"&&zg.has(e)}function ne(e){return typeof e!="number"||!Number.isFinite(e)||!Number.isInteger(e)||e<0?null:e}function vc(e){let t=0;for(const n of Object.values(e))typeof n=="number"&&Number.isFinite(n)&&(t+=n);return t}function Yg(e){if(e===void 0)return{};const t={};for(const[n,r]of Object.entries(e)){if(!Mn(n))continue;const o=ne(r);o===null||o===0||(t[n]=o)}return t}function Ho(e){const t=Yg(e.iocCountByType),n=vc(t);if(e.totalIocCount===void 0)return{totalIocCount:n,iocCountByType:t};const r=ne(e.totalIocCount);return r===null||r!==n?null:{totalIocCount:r,iocCountByType:t}}function Kg(e){const t=hc(e);return{totalIocCount:e.length,iocCountByType:t}}function Wg(e){const t=e.trim();if(t.length===0)return Qt;try{const n=new URL(t).hostname.trim();if(n.length>0)return`${Qt} — ${n}`}catch{return Qt}return Qt}function re(e){return j(e)}function ei(e){if(!Array.isArray(e))return null;const t=[];for(const n of e){const r=Rt(n);if(r===null)return null;t.push(r)}return t}function jg(e){if(e===null||typeof e!="object"||Array.isArray(e))return null;const t=e,n=Rt(t.firstSeenAt),r=ei(t.enrichEvents),o=ei(t.exportEvents);if(n===null||r===null||o===null)return null;const a={firstSeenAt:n,enrichEvents:r.slice(0,ln),exportEvents:o.slice(0,ln)};if(t.iocType!==void 0){if(!Mn(t.iocType))return null;a.iocType=t.iocType}return a}function Pn(e){if(e===void 0||e===null||typeof e!="object"||Array.isArray(e))return;const t={};for(const[n,r]of Object.entries(e)){const o=re(n),a=jg(r);o.length===0||!a||(t[o]=a)}return Object.keys(t).length>0?t:void 0}function ti(e,t){const n=[...e,t];return n.length<=ln?n:n.slice(n.length-ln)}function Ec(e,t){const n=re(t.iocKey);if(n.length===0)return e;const r=t.at??Date.now(),o={...e.iocTimelines??{}},a=o[n];return t.event==="first-seen"?a?e:(o[n]={firstSeenAt:r,enrichEvents:[],exportEvents:[],...t.iocType?{iocType:t.iocType}:{}},{...e,iocTimelines:o}):a?(o[n]={...a,enrichEvents:t.event==="enrich"?ti(a.enrichEvents,r):a.enrichEvents,exportEvents:t.event==="export"?ti(a.exportEvents,r):a.exportEvents,...t.iocType&&!a.iocType?{iocType:t.iocType}:{}},{...e,iocTimelines:o}):(o[n]={firstSeenAt:r,enrichEvents:t.event==="enrich"?[r]:[],exportEvents:t.event==="export"?[r]:[],...t.iocType?{iocType:t.iocType}:{}},{...e,iocTimelines:o})}function qg(e,t){const n=re(t);return n.length===0?null:e.iocTimelines?.[n]??null}function Xg(e){return[{kind:"first-seen",at:e.firstSeenAt},...e.enrichEvents.map(t=>({kind:"enrich",at:t})),...e.exportEvents.map(t=>({kind:"export",at:t}))].sort((t,n)=>t.at-n.at)}function Jg(e){return Number.isFinite(e)?new Date(e).toLocaleString():"Unknown time"}function Qg(e){switch(e){case"first-seen":return"First seen";case"enrich":return"Enriched";case"export":return"Exported"}}function Zg(e){return Xg(e).map(t=>`${Qg(t.kind)} · ${Jg(t.at)}`)}function Hn(e){if(e===void 0||e===null||typeof e!="object"||Array.isArray(e))return;const t={};for(const[n,r]of Object.entries(e)){const o=re(n);if(o.length===0||r===null||typeof r!="object"||Array.isArray(r))continue;const a=r,i=Rt(a.pinnedAt);if(i===null)continue;const s={pinnedAt:i};if(a.iocType!==void 0){if(!Mn(a.iocType))continue;s.iocType=a.iocType}t[o]=s}return Object.keys(t).length>0?t:void 0}function ni(e,t){const n=re(t);return n.length===0?!1:!!e.pinnedIocs?.[n]}function ev(e){return e.pinnedIocs?Object.entries(e.pinnedIocs).sort((t,n)=>t[1].pinnedAt-n[1].pinnedAt).map(([t])=>t):[]}function tv(e,t){if(t.length===0)return[...e];const n=new Set(t),r=new Map;for(const i of e)r.set(re(i.value),i);const o=[];for(const i of t){const s=r.get(i);s&&o.push(s)}const a=e.filter(i=>!n.has(re(i.value)));return[...o,...a]}function nv(e,t){const n=re(t.iocKey);if(n.length===0)return e;const r={...e.pinnedIocs??{}},o=!!r[n];if((t.pinned===void 0?!o:t.pinned)?r[n]={pinnedAt:t.at??Date.now(),...t.iocType?{iocType:t.iocType}:{}}:delete r[n],Object.keys(r).length===0){const i={...e};return delete i.pinnedIocs,i}return{...e,pinnedIocs:r}}function yc(e){const t=e.enrichmentCount===void 0?0:ne(e.enrichmentCount),n=e.exportCount===void 0?0:ne(e.exportCount);return t===null||n===null?null:{enrichmentCount:t,exportCount:n}}function Uo(e){const t=e.trim();return t.length===0?null:t.length>Ja?t.slice(0,Ja):t}function Vo(e){return e.trim()}function Fo(e){if(e===void 0)return;const t=e.trim();if(t.length!==0)return t.length>Qa?t.slice(0,Qa):t}function rv(e=Date.now()){return typeof crypto<"u"&&typeof crypto.randomUUID=="function"?`${Xa}${crypto.randomUUID()}`:`${Xa}${e}-${Math.random().toString(36).slice(2,10)}`}function Sc(e){const t=Uo(e.title);if(!t)return null;const n=e.createdAt??Date.now(),r=e.updatedAt??n;if(!Number.isFinite(n)||!Number.isFinite(r)||r<n)return null;const o=e.id?.trim()||rv(n);if(o.length===0)return null;const a=Ho({totalIocCount:e.totalIocCount,iocCountByType:e.iocCountByType});if(!a)return null;const i=e.enrichmentCount===void 0?0:ne(e.enrichmentCount),s=e.exportCount===void 0?0:ne(e.exportCount);if(i===null||s===null)return null;const l=Fo(e.notes),u=Pn(e.iocTimelines),p=Hn(e.pinnedIocs),f={id:o,title:t,createdAt:n,updatedAt:r,pageUrl:Vo(e.pageUrl),totalIocCount:a.totalIocCount,iocCountByType:{...a.iocCountByType},enrichmentCount:i,exportCount:s};return l!==void 0&&(f.notes=l),u!==void 0&&(f.iocTimelines=u),p!==void 0&&(f.pinnedIocs=p),f}function Un(e,t){const n=t.title===void 0?e.title:Uo(t.title);if(!n)return null;const r=t.pageUrl===void 0?e.pageUrl:Vo(t.pageUrl);let o;t.notes===null?o=void 0:t.notes===void 0?o=e.notes:o=Fo(t.notes);const a=t.updatedAt??Date.now();if(!Number.isFinite(a)||a<e.createdAt)return null;const i=t.totalIocCount===void 0&&t.iocCountByType===void 0?{totalIocCount:e.totalIocCount,iocCountByType:{...e.iocCountByType}}:Ho({totalIocCount:t.totalIocCount??e.totalIocCount,iocCountByType:t.iocCountByType??e.iocCountByType});if(!i)return null;const s=t.enrichmentCount===void 0?e.enrichmentCount:ne(t.enrichmentCount),l=t.exportCount===void 0?e.exportCount:ne(t.exportCount);if(s===null||l===null)return null;let u;t.iocTimelines===null?u=void 0:t.iocTimelines===void 0?u=e.iocTimelines?{...e.iocTimelines}:void 0:u=Pn(t.iocTimelines);let p;t.pinnedIocs===null?p=void 0:t.pinnedIocs===void 0?p=e.pinnedIocs?{...e.pinnedIocs}:void 0:p=Hn(t.pinnedIocs);const f={id:e.id,title:n,createdAt:e.createdAt,updatedAt:a,pageUrl:r,totalIocCount:i.totalIocCount,iocCountByType:{...i.iocCountByType},enrichmentCount:s,exportCount:l};return o!==void 0&&(f.notes=o),u!==void 0&&(f.iocTimelines=u),p!==void 0&&(f.pinnedIocs=p),f}function ov(e){if(e===null||typeof e!="object")return!1;for(const[t,n]of Object.entries(e))if(!Mn(t)||ne(n)===null)return!1;return!0}function av(e){if(e===null||typeof e!="object")return!1;const t=e,n=Za(t.id),r=Za(t.title),o=Rt(t.createdAt),a=Rt(t.updatedAt),i=ne(t.totalIocCount);if(!n||!r||o===null||a===null||i===null||a<o||typeof t.pageUrl!="string"||!ov(t.iocCountByType)||vc(t.iocCountByType)!==i||yc(t)===null)return!1;if(t.iocTimelines!==void 0){const s=Pn(t.iocTimelines);if(!s||JSON.stringify(s)!==JSON.stringify(t.iocTimelines))return!1}if(t.pinnedIocs!==void 0){const s=Hn(t.pinnedIocs);if(!s||JSON.stringify(s)!==JSON.stringify(t.pinnedIocs))return!1}return t.notes===void 0?!0:typeof t.notes!="string"?!1:t.notes.trim().length>0}function bc(e){if(!av(e))return null;const t=Ho({totalIocCount:e.totalIocCount,iocCountByType:e.iocCountByType});if(!t)return null;const n=yc(e);if(!n)return null;const r=Fo(e.notes),o=Pn(e.iocTimelines),a=Hn(e.pinnedIocs),i={id:e.id.trim(),title:Uo(e.title)??e.title.trim(),createdAt:e.createdAt,updatedAt:e.updatedAt,pageUrl:Vo(e.pageUrl),totalIocCount:t.totalIocCount,iocCountByType:{...t.iocCountByType},enrichmentCount:n.enrichmentCount,exportCount:n.exportCount};return r!==void 0&&(i.notes=r),o!==void 0&&(i.iocTimelines=o),a!==void 0&&(i.pinnedIocs=a),i}const Gt=1,Ot="investigationSessions",Bo=10;function Cc(){return typeof chrome<"u"&&chrome.storage?.local!==void 0&&!D()}function Ac(e){return typeof e!="number"||!Number.isFinite(e)||!Number.isInteger(e)||e<0?null:e}function _c(e){if(typeof e!="string")return;const t=e.trim();return t.length>0?t:void 0}function Ic(e,t){if(!Array.isArray(e))return[];const n=[],r=new Set;for(const o of e){if(typeof o!="string")continue;const a=o.trim();a.length===0||r.has(a)||!t.has(a)||(r.add(a),n.push(a))}return n}function zt(e){return{schemaVersion:Gt,sessions:e.sessions,...e.activeSessionId?{activeSessionId:e.activeSessionId}:{},...e.archivedSessionIds&&e.archivedSessionIds.length>0?{archivedSessionIds:e.archivedSessionIds}:{}}}function bt(){return{schemaVersion:Gt,sessions:[]}}function Vn(e){if(e===null||typeof e!="object"||Array.isArray(e))return bt();const t=e;if(Ac(t.schemaVersion)!==Gt||!Array.isArray(t.sessions))return bt();const r=[],o=new Map;for(const l of t.sessions){const u=bc(l);if(!u)continue;const p=o.get(u.id);(!p||u.updatedAt>=p.updatedAt)&&o.set(u.id,u)}r.push(...o.values()),r.sort((l,u)=>u.updatedAt-l.updatedAt);const a=Ic(t.archivedSessionIds,o),i=_c(t.activeSessionId),s=i&&o.has(i)&&!a.includes(i)?i:void 0;return zt({sessions:r,activeSessionId:s,archivedSessionIds:a})}function iv(e){const t=Vn(e);if(e===null||typeof e!="object"||Array.isArray(e))return!1;const n=e;if(Ac(n.schemaVersion)!==Gt||!Array.isArray(n.sessions)||n.sessions.length!==t.sessions.length)return!1;for(let a=0;a<n.sessions.length;a+=1){const i=n.sessions[a],s=t.sessions[a];if(!i||!s||JSON.stringify(i)!==JSON.stringify(s))return!1}if(_c(n.activeSessionId)!==t.activeSessionId)return!1;const o=Ic(n.archivedSessionIds,new Map(t.sessions.map(a=>[a.id,a])));return JSON.stringify(o)===JSON.stringify(t.archivedSessionIds??[])}async function U(){if(!Cc())return bt();const e=await k(Ot);return Vn(e[Ot])}async function nt(e){if(!Cc())return;const t=Vn(e);if(t.sessions.length===0){await Xr(Ot);return}await qr({[Ot]:t})}function Tc(e,t=Bo){const n=new Set(e.archivedSessionIds??[]);return e.sessions.filter(r=>!n.has(r.id)).slice(0,t).map(r=>({...r}))}async function sv(){return(await U()).sessions.map(t=>({...t}))}async function cv(e=Bo){const t=await U();return Tc(t,e)}async function lv(e){const t=e.trim();if(t.length===0)return null;const r=(await U()).sessions.find(o=>o.id===t);return r?{...r}:null}async function $o(){const e=await U();if(!e.activeSessionId)return null;const t=e.sessions.find(n=>n.id===e.activeSessionId);return t?{...t}:null}async function rt(e,t){const n=bc(e);if(!n)return!1;const r=await U(),o=r.sessions.filter(i=>i.id!==n.id);o.push(n),o.sort((i,s)=>s.updatedAt-i.updatedAt);let a=r.activeSessionId;return t?.setActive?a=n.id:a&&!o.some(i=>i.id===a)&&(a=void 0),await nt(zt({sessions:o,activeSessionId:a,archivedSessionIds:r.archivedSessionIds})),!0}async function uv(e){const t=e.trim();if(t.length===0)return!1;const n=await U(),r=n.sessions.filter(i=>i.id!==t);if(r.length===n.sessions.length)return!1;const o=n.activeSessionId===t?void 0:n.activeSessionId,a=(n.archivedSessionIds??[]).filter(i=>i!==t);return await nt(zt({sessions:r,activeSessionId:o,archivedSessionIds:a})),!0}async function dv(e){await nt(e)}async function pv(e){const t=e.trim();if(t.length===0)return null;const n=await U(),r=n.sessions.find(o=>o.id===t);return!r||n.archivedSessionIds?.includes(t)?null:(await nt(zt({sessions:n.sessions,activeSessionId:t,archivedSessionIds:n.archivedSessionIds})),{...r})}async function xc(e){const t=e.sessionId.trim();if(t.length===0)return null;const n=await U(),r=n.sessions.find(i=>i.id===t);if(!r||n.archivedSessionIds?.includes(t))return null;const o=Un(r,{title:e.title,updatedAt:e.now??Date.now()});return o&&await rt(o,{setActive:n.activeSessionId===t})?o:null}async function fv(e){const t=e.trim();if(t.length===0)return!1;const n=await U();if(!n.sessions.some(a=>a.id===t))return!1;const r=[...n.archivedSessionIds??[]];r.includes(t)||r.push(t);const o=n.activeSessionId===t?void 0:n.activeSessionId;return await nt(zt({sessions:n.sessions,activeSessionId:o,archivedSessionIds:r})),!0}async function mv(e){const t=e.now??Date.now(),n=Kg(e.entries),r=await U(),o=r.activeSessionId?r.sessions.find(s=>s.id===r.activeSessionId)??null:null;let a=null;if(o?a=Un(o,{pageUrl:e.pageUrl,totalIocCount:n.totalIocCount,iocCountByType:n.iocCountByType,updatedAt:t}):a=Sc({title:Wg(e.pageUrl),pageUrl:e.pageUrl,createdAt:t,updatedAt:t,totalIocCount:n.totalIocCount,iocCountByType:n.iocCountByType}),!a)return null;for(const s of e.entries){const l=s.value?.trim();l&&(a=Ec(a,{iocKey:l,iocType:s.type,event:"first-seen",at:t}))}return await rt(a,{setActive:!0})?a:null}async function hv(e){const t=e.now??Date.now(),n=Sc({title:e.title,pageUrl:e.pageUrl,createdAt:t,updatedAt:t});return n&&await rt(n,{setActive:!0})?n:null}async function gv(e){const t=await U();return t.activeSessionId?xc({sessionId:t.activeSessionId,title:e.title,now:e.now}):null}async function Lc(e){const t=e.now??Date.now(),n=await U();if(!n.activeSessionId)return null;const r=n.sessions.find(s=>s.id===n.activeSessionId);if(!r||n.archivedSessionIds?.includes(r.id))return null;let o=r;for(const s of e.timelineEvents??[])o=Ec(o,{iocKey:s.iocValue,iocType:s.iocType,event:s.event,at:t});const a=Un(o,{[e.field]:r[e.field]+1,updatedAt:t,iocTimelines:o.iocTimelines});return a&&await rt(a,{setActive:!0})?a:null}function Nc(e,t){return e?.iocs&&e.iocs.length>0?e.iocs.map(n=>({iocValue:n.value,iocType:n.type,event:t})):e?.iocValue?.trim()?[{iocValue:e.iocValue,iocType:e.iocType,event:t}]:[]}async function vv(e){return Lc({field:"enrichmentCount",now:e?.now,timelineEvents:Nc(e,"enrich")})}async function un(e){return Lc({field:"exportCount",now:e?.now,timelineEvents:Nc(e,"export")})}async function wc(e){const t=e.now??Date.now(),n=await U();if(!n.activeSessionId)return null;const r=n.sessions.find(s=>s.id===n.activeSessionId);if(!r||n.archivedSessionIds?.includes(r.id))return null;const o=nv(r,{iocKey:e.iocValue,iocType:e.iocType,pinned:e.pinned,at:t}),a=Un(o,{pinnedIocs:o.pinnedIocs??null,updatedAt:t});return a&&await rt(a,{setActive:!0})?a:null}const Ev=Object.freeze(Object.defineProperty({__proto__:null,INVESTIGATION_SESSIONS_SCHEMA_VERSION:Gt,MAX_RECENT_INVESTIGATION_SESSIONS:Bo,STORAGE_KEY_INVESTIGATION_SESSIONS:Ot,archiveInvestigationSession:fv,createEmptyInvestigationSessionsStore:bt,deleteStoredInvestigationSession:uv,getActiveInvestigationSession:$o,getInvestigationSessionsStore:U,getStoredInvestigationSession:lv,hydrateInvestigationSessionsStore:dv,isInvestigationSessionsStore:iv,listRecentInvestigationSessions:cv,listRecentInvestigationSessionsFromStore:Tc,listStoredInvestigationSessions:sv,normalizeInvestigationSessionsStore:Vn,persistInvestigationSessionsStore:nt,recordActiveInvestigationSessionEnrichmentEvent:vv,recordActiveInvestigationSessionExportEvent:un,renameActiveInvestigationSession:gv,renameInvestigationSession:xc,reopenInvestigationSession:pv,saveStoredInvestigationSession:rt,startNewInvestigationSession:hv,syncActiveInvestigationSessionFromScan:mv,toggleActiveInvestigationSessionIocPin:wc},Symbol.toStringTag,{value:"Module"})),yv=new Set(Object.values(d));function Rc(e){return`tabScanTrayFilter:${e}`}function Sv(e){return e==="all"||typeof e=="string"&&yv.has(e)}async function dn(e,t){await ad({[Rc(e)]:t})}async function Oc(e){const t=Rc(e),r=(await od(t))[t];return Sv(r)?r:"all"}let Sr=null;function Go(){return Sr??{defaultExportTemplateId:"analyst-update",pivotEmphasisProviders:[]}}async function ri(){const e=await k([We,je]);return Sr={defaultExportTemplateId:xs(e[We]),pivotEmphasisProviders:Ls(e[je])},Sr}function bv(){ri(),!(typeof chrome>"u"||!chrome.storage?.onChanged)&&chrome.storage.onChanged.addListener((e,t)=>{t==="local"&&(We in e||je in e)&&ri()})}const Cv="(prefers-reduced-motion: reduce)";function Av(e=window){return e.matchMedia(Cv).matches}function _v(e=window){return Av(e)?0:1500}function Iv(e,t=window){const n=_v(t);if(n===0){e();return}t.setTimeout(e,n)}function Tv(e){if(!e?.ok||typeof e.payload!="object"||e.payload===null)return[];const t=e.payload.collections;return Array.isArray(t)?t.filter(n=>Dn(n)):[]}function xv(e){if(!e?.ok||typeof e.payload!="object"||e.payload===null)return null;const t=e.payload.collection;return Dn(t)?t:null}function Lv(e){if(!e?.ok||typeof e.payload!="object"||e.payload===null)return null;const t=e.payload;return Dn(t.collection)?{collection:t.collection,added:t.added===!0}:null}function Nv(e){if(!e?.ok||typeof e.payload!="object"||e.payload===null)return null;const t=e.payload;return!Dn(t.collection)||typeof t.addedCount!="number"||typeof t.duplicateCount!="number"||typeof t.totalCount!="number"?null:{collection:t.collection,addedCount:t.addedCount,duplicateCount:t.duplicateCount,totalCount:t.totalCount}}async function zo(){const e=await q(ju());return Tv(e)}async function Yo(e){const t=await q(qu(e));return xv(t)}async function pn(e){const t=await q(Xu({collectionId:e.collectionId,iocType:e.member.iocType,value:e.member.value}));return Lv(t)}async function oi(e){const t=await q(Ju({collectionId:e.collectionId,members:e.members.map(n=>({iocType:n.iocType,value:n.value}))}));return Nv(t)}const wv=8,Rv=8;function kc(e,t,n){const r=n.margin??wv,o=n.offset??Rv,a=Math.max(r,n.width-r-t.width),i=Math.max(r,n.height-r-t.height);let s=e.top+e.height+o;s+t.height>n.height-r&&(s=e.top-t.height-o),s=ai(s,r,i);let l=e.left;return l+t.width>n.width-r&&(l=n.width-r-t.width),l=ai(l,r,a),{top:s,left:l}}function ai(e,t,n){return Math.min(Math.max(e,t),n)}function Dc(e,t){e.style.position="fixed",e.style.top=`${t.top}px`,e.style.left=`${t.left}px`,e.style.margin="0",e.style.zIndex="2147483646"}function Ko(e=window){return{width:e.innerWidth,height:e.innerHeight}}const Ov=1,kv=1,Dv="Local enrichment summary prompt. Injects normalized export JSON only. See docs/ai-summary.md.",Mv=["ENRICHMENT_EXPORT_JSON"],Pv=["API keys or connector credentials","Full page HTML or DOM","Raw vendor HTTP response bodies","Settings or storage exports","Operator identity fields or other user PII placeholders"],Hv=`You summarize a single Vera5 enrichment export for a security analyst. Input is normalized enrichment JSON only (schemaVersion 1). Output is markdown only—no JSON, no code fences around the full answer, no preamble.

Grounding rules:
- Every factual claim must come from a field in the input JSON.
- Do not invent indicators, URLs, hashes, threat names, or vendor detection counts.
- Do not upgrade or downgrade severity beyond score.summaryText and score.label.
- Do not use verdict language such as confirmed malicious or confirmed benign; describe what sources report.
- For sources with status skipped, quote the skip reason and do not imply live vendor data.
- When score.compositeSignal is null, do not invent a /100 value.
- When score.reasoningLines is non-empty, copy those strings verbatim under ### How this score was computed.
- When disagreement is true, include disagreementNotice verbatim.
- When analystNotes is present, add ### Analyst notes (local) with the text unchanged and treat it as operator-authored, not model-generated.

Output sections in order:
1. Title: # IOC summary: {ioc} using input ioc verbatim.
2. **Type:** {iocTypeLabel}
3. One short overview paragraph from summary, tags, and sources only.
4. Bullet list: **{name}** ({badgeText}): {summary} for each sources[] row.
5. **Risk score:** line from score.summaryText, or score.headline/detail when mode is unavailable or none.
6. Optional ### How this score was computed numbered list when reasoningLines exist.
7. Optional disagreement callout when disagreement is true.
8. Optional ### Analyst notes (local) when analystNotes exists.
9. Required footer exactly:

---

**AI summary (local, unverified)** — Generated on your machine from enrichment JSON only. Vera5 does not operate the model or store prompts. Not a risk verdict. Verify per-source rows, pivots, and the local composite score before acting.

Keep overview and per-source sections roughly 120–250 words combined unless the operator configured a higher local limit.`,Uv=`Produce the markdown IOC summary for this enrichment export JSON. Use only fields present in the document.

{{ENRICHMENT_EXPORT_JSON}}`,Vv={promptTemplateVersion:Ov,compatibleEnrichmentExportSchemaVersion:kv,description:Dv,allowedPlaceholders:Mv,forbiddenPromptContent:Pv,system:Hv,user:Uv},Mc=Vv,Fv="ENRICHMENT_EXPORT_JSON",Bv=["apiKeys","rawVendorJson","html","dom","pageText","storage"];class gt extends Error{constructor(t){super(t),this.name="AiSummaryInputRejectedError"}}function $v(e){if(e.schemaVersion!==ur)throw new gt("Enrichment summary requires export schemaVersion 1.");if(e.enrichmentState!=="ready")throw new gt("Enrichment summary requires enrichmentState ready.");const t=e;for(const n of Bv)if(n in t)throw new gt(`Enrichment summary rejects forbidden export field: ${n}.`);if(Mc.compatibleEnrichmentExportSchemaVersion!==ur)throw new gt("Enrichment summary prompt template is incompatible with export schema.")}function Gv(e,t=Mc){$v(e);const n=`{{${Fv}}}`;if(!t.user.includes(n))throw new gt("Enrichment summary prompt template is missing the export JSON placeholder.");const r=JSON.stringify(e);return{system:t.system,user:t.user.replace(n,r)}}const Wo="127.0.0.1",Pc=8765;class ut extends Error{constructor(t){super(t),this.name="LocalBackendOutboundBlockedError"}}const Hc="/summarize",zv=3e4;function Yv(e=Wo,t=Pc){return`http://${e}:${t}${Hc}`}function Kv(e){let t;try{t=typeof e=="string"?new URL(e):e}catch{throw new ut("Local backend summarize URL is invalid.")}if(t.protocol!=="http:")throw new ut("Local backend summarize requires HTTP on localhost.");if(t.hostname!==Wo)throw new ut("Local backend summarize is restricted to 127.0.0.1.");if(t.pathname!==Hc)throw new ut("Local backend summarize path must be /summarize.");const n=t.port.length>0?Number.parseInt(t.port,10):80;if(!Number.isFinite(n)||n<1||n>65535)throw new ut("Local backend summarize port is invalid.")}function Wv(e){return e==="timeout"||e==="connection_refused"||e==="http_error"||e==="invalid_json"||e==="malformed_response"||e==="grounding_violation"}function jv(e){if(typeof e!="object"||e===null)return null;const t=e;if(t.ok===!0){if(typeof t.markdown!="string")return null;const n=t.markdown.trim();return n.length===0?null:{ok:!0,markdown:n}}return t.ok===!1?!Wv(t.errorCode)||typeof t.errorMessage!="string"?null:{ok:!1,errorCode:t.errorCode,errorMessage:t.errorMessage}:null}async function qv(e,t={}){const n=t.fetch??fetch,r=t.host??Wo,o=t.port??Pc,a=t.timeoutMs??zv,i=Yv(r,o);Kv(i);const s=new AbortController,l=setTimeout(()=>s.abort(),a);try{const u=await n(i,{method:"POST",headers:{Accept:"application/json","Content-Type":"application/json"},body:JSON.stringify(e),signal:s.signal});if(!u.ok)return null;const p=await u.json();return jv(p)}catch{return null}finally{clearTimeout(l)}}const Xv="127.0.0.1",Uc="http://127.0.0.1:11434/v1/chat/completions",Jv="local",Qv=3e4,me={TIMEOUT:"timeout",CONNECTION_REFUSED:"connection_refused",HTTP_ERROR:"http_error",INVALID_JSON:"invalid_json",MALFORMED_RESPONSE:"malformed_response",GROUNDING_VIOLATION:"grounding_violation"},dt={UNGROUNDED_INDICATOR:"ungrounded_indicator",VERDICT_LANGUAGE:"verdict_language",UNGROUNDED_DETECTION_COUNT:"ungrounded_detection_count",INVENTED_COMPOSITE_SCORE:"invented_composite_score",SEVERITY_OVERRIDE:"severity_override"};class pt extends Error{constructor(t){super(t),this.name="LocalLlmOutboundBlockedError"}}const Zv=`---

**AI summary (local, unverified)**`,eE=[/\bconfirmed malicious\b/i,/\bconfirmed benign\b/i,/\bdefinitely malicious\b/i,/\bdefinitely benign\b/i,/\b100%\s+malicious\b/i,/\b100%\s+benign\b/i],tE=/\b\d+\s+(?:detections|detection hits|malicious detections|engines detected|vendor detections|security vendors|positive detections)\b/gi,nE=/\b\d{1,3}\s*\/\s*100\b/g,rE=[/\b(high|critical|severe)\s+risk\b/i,/\brisk\s+(?:is\s+)?(?:high|critical|severe)\b/i,/\b(critical|severe)\s+severity\b/i];function he(e,t){return{ok:!1,errorCode:e,errorMessage:t}}function ft(e,t){return{ok:!1,violation:e,errorMessage:t}}function oE(e){let t;try{t=typeof e=="string"?new URL(e):e}catch{throw new pt("Local LLM summary URL is invalid.")}if(t.protocol!=="http:")throw new pt("Local LLM summary requires HTTP on 127.0.0.1.");if(t.hostname!==Xv)throw new pt("Local LLM summary is restricted to 127.0.0.1.");if(t.username.length>0||t.password.length>0)throw new pt("Local LLM summary URL must not embed credentials.");const n=t.port.length>0?Number.parseInt(t.port,10):80;if(!Number.isFinite(n)||n<1||n>65535)throw new pt("Local LLM summary port is invalid.")}function aE(e){const t=Gv(e.exportDocument);return{model:e.model??Jv,messages:[{role:"system",content:t.system},{role:"user",content:t.user}],stream:!1}}function iE(e){return typeof e=="object"&&e!==null&&"name"in e&&e.name==="AbortError"}function sE(e){if(!(e instanceof Error))return!1;if(e.message.toLowerCase().includes("connection refused"))return!0;const t=e.cause;return typeof t=="object"&&t!==null&&"code"in t?t.code==="ECONNREFUSED":!1}function cE(e){return iE(e)?he(me.TIMEOUT,"Local LLM request timed out."):sE(e)?he(me.CONNECTION_REFUSED,"Local LLM endpoint refused the connection on 127.0.0.1."):he(me.CONNECTION_REFUSED,"Local LLM endpoint is unreachable on 127.0.0.1.")}function lE(e){return e===408?he(me.TIMEOUT,"Local LLM request timed out."):he(me.HTTP_ERROR,`Local LLM returned HTTP ${e}.`)}function uE(e){if(typeof e!="object"||e===null)return null;const t=e.choices;if(!Array.isArray(t)||t.length===0)return null;const n=t[0];if(typeof n!="object"||n===null)return null;const r=n.message;if(typeof r?.content!="string")return null;const o=r.content.trim();return o.length>0?o:null}function dE(e){const t=[],n=r=>{if(typeof r=="string"){t.push(r);return}if(Array.isArray(r)){for(const o of r)n(o);return}if(r&&typeof r=="object")for(const o of Object.values(r))n(o)};return n(e),t}function br(e){return Oe(e).trim().toLowerCase()}function mt(e,t){const n=br(e);return n.length===0?!0:t.some(r=>br(r).includes(n))}function pE(e){const t=e.indexOf(Zv);return t>=0?e.slice(0,t):e}function fE(e){const t=new Set,n=[];for(const r of e){const o=`${r.type}:${br(r.value)}`;t.has(o)||(t.add(o),n.push(r))}return n}function mE(e){const t=Br(e),n=t.map(S=>({start:S.start,end:S.end})),r=Fr(e,{includePrivateIpv4:!0}).filter(S=>!n.some(L=>S.start>=L.start&&S.end<=L.end)),o=r.map(S=>({start:S.start,end:S.end})),a=[...n,...o],i=$r(e,a),s=Ur(e,a),l=Vr(e,a),u=Gr(e),p=zr(e),f=Yr(e),h=Kr(e),E=Wr(e);return fE([...t,...r,...i,...s,...l,...u,...p,...f,...h,...E])}function hE(e){const t=e.score;return t.mode==="available"||t.mode==="insufficient"?t.compositeSignal:null}function gE(e){const t=e.score;return t.mode==="available"||t.mode==="insufficient"?t.label:null}function vE(e,t){const n=dE(e),r=pE(t);for(const a of mE(r))if(!mt(a.value,n))return ft(dt.UNGROUNDED_INDICATOR,"Local LLM summary cites an indicator not present in enrichment JSON.");for(const a of eE){const i=r.match(a);if(i&&!mt(i[0],n))return ft(dt.VERDICT_LANGUAGE,"Local LLM summary uses verdict language not supported by enrichment JSON.")}for(const a of r.matchAll(tE))if(!mt(a[0],n))return ft(dt.UNGROUNDED_DETECTION_COUNT,"Local LLM summary cites vendor detection counts not present in enrichment JSON.");if(hE(e)===null){for(const a of r.matchAll(nE))if(!mt(a[0],n))return ft(dt.INVENTED_COMPOSITE_SCORE,"Local LLM summary invents a /100 score not present in enrichment JSON.")}if(gE(e)===H.UNKNOWN)for(const a of rE){const i=r.match(a);if(i&&!mt(i[0],n))return ft(dt.SEVERITY_OVERRIDE,"Local LLM summary overrides the exported risk band.")}return{ok:!0}}async function EE(e,t={}){oE(e.endpointUrl);const n=t.fetch??fetch,r=t.timeoutMs??Qv,o=new AbortController,a=setTimeout(()=>o.abort(),r);try{const i=await n(e.endpointUrl,{method:"POST",headers:{Accept:"application/json","Content-Type":"application/json"},body:JSON.stringify(aE(e)),signal:o.signal});if(!i.ok)return lE(i.status);let s;try{s=await i.json()}catch{return he(me.INVALID_JSON,"Local LLM returned invalid JSON.")}const l=uE(s);if(!l)return he(me.MALFORMED_RESPONSE,"Local LLM returned an unexpected response.");const u=vE(e.exportDocument,l);return u.ok?{ok:!0,markdown:l}:he(me.GROUNDING_VIOLATION,u.errorMessage)}catch(i){return cE(i)}finally{clearTimeout(a)}}async function yE(e,t={}){if(e.useLocalBackend){const n=await qv(e.exportDocument,{fetch:t.fetch,timeoutMs:t.timeoutMs});if(n!==null)return n}return EE({endpointUrl:e.endpointUrl??Uc,exportDocument:e.exportDocument},t)}function SE(e){if(!e?.ok||typeof e.payload!="object"||e.payload===null)return null;const t=e.payload.summary;return t===null||!Gg(t)?null:t}async function jo(e){const t=await q(Qu());return SE(t)}async function Vc(){return jo()}const ii=12e3,bE="[redacted]",CE=/^(key|api[_-]?key|x-otx-api-key|authorization|token|secret|password|bearer|access[_-]?token|refresh[_-]?token)$/i;function AE(e){return typeof e=="object"&&e!==null&&!Array.isArray(e)}function _E(e){const t=e.trim().toLowerCase();return t?CE.test(t)?!0:t.endsWith("_key")||t.endsWith("-key")||t.includes("apikey")||t.includes("api_key"):!1}function Cr(e){if(Array.isArray(e))return e.map(n=>Cr(n));if(!AE(e))return e;const t={};for(const[n,r]of Object.entries(e)){if(_E(n)){t[n]=bE;continue}t[n]=Cr(r)}return t}function IE(e){const t=Cr(e);let n;try{n=JSON.stringify(t,null,2)}catch{return}return n.length>ii?`${n.slice(0,ii)}
…`:n}function TE(e){const t=e.trim();if(!t)return t;try{return IE(JSON.parse(t))??t}catch{return t}}const kt="vera5-hover-card-host";function Ae(e){un(e&&e.length>0?{iocs:e}:void 0)}function qo(e){return e.map(t=>({value:t.value,type:t.type}))}let Xe=null,O=null,Ar=null,Ue=!1,ie=null,Ce="",_e=[],fn=!1,K={status:"idle"};const xE=["button:not([disabled])","a[href]","textarea:not([disabled])","input:not([disabled])","select:not([disabled])",'[tabindex]:not([tabindex="-1"])'].join(", ");function _r(e){Ar=e}function Fc(e){const t=e.querySelector(xE);return t?(t.focus(),!0):!1}function LE(e){const t=Ar;Ar=null,t?.isConnected&&e.contains(t)&&t.focus()}function Bc(){return Xe}function $c(){return O}const NE="vera5-hover-card-panel",wE="vera5-hover-card-copy",RE="vera5-hover-card-pivot-recipes",OE="vera5-hover-card-pivot-recipes-list",kE="vera5-hover-card-pivot-recipe",DE="vera5-hover-card-pivot-recipe-source",ME="vera5-hover-card-pivot-recipe-guidance",PE="vera5-hover-card-pivot-link",HE="vera5-hover-card-enrichment",UE="vera5-hover-card-tags",VE="vera5-hover-card-tag",FE="vera5-hover-card-attribution",BE="vera5-hover-card-disclaimer",De="vera5-hover-card-action",Gc="vera5-hover-card-retry-hint",zc="vera5-hover-card-sources",Yc="vera5-hover-card-source-item",$E="vera5-hover-card-source-detail",GE="vera5-hover-card-source-tags",zE="vera5-hover-card-raw-json",YE="vera5-hover-card-raw-json-body",Kc="vera5-hover-card-risk-score",KE="vera5-hover-card-risk-score-label",WE="vera5-hover-card-risk-disagreement",jE="vera5-hover-card-risk-score-unavailable",qE="vera5-hover-card-risk-score-unavailable-detail",XE="vera5-hover-card-risk-score-insufficient",JE="vera5-hover-card-analyst-notes",QE="vera5-hover-card-analyst-notes-input",ZE="vera5-hover-card-ioc-label",ey="vera5-hover-card-ioc-label-label",ty="vera5-hover-card-ioc-label-select",ny="vera5-hover-card-save-collection",ry="vera5-hover-card-save-collection-toggle",oy="vera5-hover-card-save-collection-panel",ay="vera5-hover-card-save-collection-heading",iy="vera5-hover-card-save-collection-list",sy="vera5-hover-card-save-collection-feedback",cy="vera5-hover-card-save-collection-field",ly="vera5-hover-card-ioc-timeline",uy="vera5-hover-card-ioc-timeline-label",dy="vera5-hover-card-ioc-timeline-list",si="vera5-hover-card-ioc-timeline-item",py="vera5-hover-card-ioc-pin",fy="vera5-hover-card-ioc-pin--pinned",my="vera5-hover-card-export",hy="vera5-hover-card-local-llm-summary",ci="vera5-hover-card-local-llm-summary-status",gy="vera5-hover-card-local-llm-summary-body",vy="vera5-hover-card-local-llm-summary-disclaimer",tr="AI summary (local, unverified)",Ey="vera5-hover-card-local-llm-summary-heading",yy="vera5-hover-card-local-llm-summary-panel",li="Generate summary",Sy="Generating summary…",by="This narrative is generated by a model you run on localhost from normalized enrichment JSON only. It is not a risk verdict and does not replace the local composite score or per-source vendor rows. Verify all claims against the enrichment card before acting.",Cy="vera5-hover-card-export-actions",mn="vera5-hover-card-export-button",Wc="vera5-hover-card-export-dropdown",jc="vera5-hover-card-export-dropdown-menu",Ay="vera5-hover-card-export-dropdown-item",_y="vera5-hover-card-export-footer",Iy="vera5-hover-card-scan-export-status",Ty="vera5-hover-card-scan-export-template-row",xy="vera5-hover-card-scan-export-template-label",Ly="vera5-hover-card-scan-export-template-select",ui="vera5-hover-card-scan-export-template-select",Ny="vera5-hover-card-section-heading",wy="vera5-hover-card-intel-summary",di="vera5-why-detected",Ry="vera5-why-detected-list",Oy="vera5-why-detected-item",qc="vera5-tray-why-detected",ky={ipv4:"IPv4 address",domain:"Domain",url:"URL",md5:"MD5 hash",sha1:"SHA1 hash",sha256:"SHA256 hash",cve:"CVE ID",email:"Email address",asn:"ASN",cidr:"IPv4 CIDR",filepath:"File path",onion:"Onion domain"};function Xc(e){return ky[e]}function oe(e,t){const n=t.createElement("h2");return n.className=Ny,n.textContent=e,n}function Dy(e,t,n){const r=n.createElement("section");r.className=Kc,r.setAttribute("aria-label","Risk score");const o=n.createElement("p");o.className=jE,o.textContent=e,r.appendChild(o);const a=n.createElement("p");return a.className=qE,a.setAttribute("role","note"),a.textContent=t,r.appendChild(a),r}function My(e,t){const n=e.disabledSources??[],r=e.sourceResults??[],o=fs(n,r);if(!o)return null;if(o.mode==="unavailable")return Dy(o.headline,o.detail,t);const a=o.view,i=t.createElement("section");i.className=Kc,i.setAttribute("aria-label","Risk score");const s=t.createElement("p");s.className=KE,s.textContent="Risk score: ";const l=t.createElement("strong");if(l.textContent=a.summaryText,s.appendChild(l),i.appendChild(s),o.insufficientCompositeNotice){const u=t.createElement("p");u.className=XE,u.setAttribute("role","note"),u.textContent=o.insufficientCompositeNotice,i.appendChild(u)}if(i.appendChild(ef(ps(a,o.insufficientCompositeNotice),t)),a.chain.showDisagreement){const u=t.createElement("p");u.className=WE,u.setAttribute("role","note"),u.textContent=a.chain.disagreementLine,i.appendChild(u)}return i}function Jc(e,t,n=Bd){const r=t.createElement("details");r.className=zE;const o=t.createElement("summary");o.textContent=n,r.appendChild(o);const a=t.createElement("pre");return a.className=YE,a.textContent=TE(e),r.appendChild(a),r}function Py(e,t){const n=Go(),r=cs(e.type,e.value,{enabledSourceIds:e.enabledEnrichmentSourceIds,showDisabledSources:e.showDisabledSourcesInWorkspace,emphasisProviders:n.pivotEmphasisProviders});if(r.length===0)return null;const o=t.createElement("section");o.className=RE,o.setAttribute("aria-label","Recommended next pivots"),o.appendChild(oe("Recommended next pivots",t));const a=t.createElement("ul");a.className=OE;for(const i of r){const s=t.createElement("li");s.className=kE;const l=t.createElement("span");l.className=DE,l.textContent=i.sourceLabel;const u=t.createElement("a");u.className=PE,u.href=i.href,u.target="_blank",u.rel="noopener noreferrer",u.textContent=i.label;const p=t.createElement("span");p.className=ME,p.textContent=i.guidance,s.append(l,u,p),a.appendChild(s)}return o.appendChild(a),o}function Hy(e,t){if(e.length<=1)return null;const n=t.createElement("section");n.className=zc,n.setAttribute("aria-label","Enrichment source results"),n.appendChild(oe("Sources",t));const r=t.createElement("ul");r.className="vera5-hover-card-sources-list";for(const o of e){const a=t.createElement("li");a.className=Yc;const i=t.createElement("span");i.className=ap(o.status,o.fromCache),i.textContent=`${o.label} · ${o.badgeText}`,a.appendChild(i);const s=t.createElement("span");if(s.className=$E,s.textContent=o.detail,a.appendChild(s),o.tags&&o.tags.length>0){const l=Qc(o.tags,t);l&&(l.classList.add(GE),a.appendChild(l))}if(o.lastUpdatedLine){const l=t.createElement("span");l.className="vera5-hover-card-source-last-updated",l.setAttribute("role","note"),l.textContent=o.lastUpdatedLine,a.appendChild(l)}if(o.retryHint){const l=t.createElement("span");l.className=Gc,l.setAttribute("role","note"),l.textContent=o.retryHint,a.appendChild(l)}o.rawVendorJson?.trim()&&a.appendChild(Jc(o.rawVendorJson,t)),r.appendChild(a)}return n.appendChild(r),n}function Uy(e,t){if(e.length===0)return null;const n=t.createElement("section");n.className=zc,n.setAttribute("aria-label","Enrichment sources"),n.appendChild(oe("Sources",t));const r=t.createElement("ul");r.className="vera5-hover-card-sources-list";for(const o of e){const a=t.createElement("li");a.className=Yc,a.textContent=`${o.label} — ${o.message}`,r.appendChild(a)}return n.appendChild(r),n}function Qc(e,t){const n=e.map(o=>o.trim()).filter(o=>o.length>0);if(n.length===0)return null;const r=t.createElement("div");r.className=UE,r.setAttribute("role","list"),r.setAttribute("aria-label","Threat intelligence tags");for(const o of n){const a=t.createElement("span");a.className=VE,a.setAttribute("role","listitem"),a.textContent=o,r.appendChild(a)}return r}function Vy(e,t,n){if(e.length===0)return null;const r=n.createElement("footer");r.className=BE,r.setAttribute("aria-label",ep(t));for(const o of e){const a=n.createElement("p");a.setAttribute("role","note"),a.textContent=o,r.appendChild(a)}return r}function Fy(e,t,n){const r=n.createElement("p");return r.className=FE,r.setAttribute("role","note"),r.textContent=qi(e,t),r}function By(e){const t=e.createElement("button");return t.type="button",t.className=De,t.textContent=Fd,t.setAttribute("aria-label","Open Vera5 Settings to add an API key"),t.addEventListener("click",n=>{n.stopPropagation(),Ui()}),t}function $y(e,t){const n=t.createElement("p");return n.className="vera5-hover-card-source-last-updated",n.setAttribute("role","note"),n.textContent=e,n}function Gy(e,t){const n=t.createElement("p");return n.className=Gc,n.setAttribute("role","note"),n.textContent=e,n}function zy(e,t,n,r){const o=r.createElement("button");return o.type="button",o.className=wE,o.textContent=t,o.setAttribute("aria-label",n),o.addEventListener("click",()=>{Z(e).then(a=>{if(!a)return;o.textContent=Ap,o.classList.add("vera5-hover-card-copy--copied");const i=r.defaultView??window;Iv(()=>{o.textContent=t,o.classList.remove("vera5-hover-card-copy--copied")},i)})}),o}function Yy(e,t){const n=t.createDocumentFragment(),r=so(e);for(const o of xp(r))n.appendChild(zy(o.copyValue,o.label,o.ariaLabel,t));return n}function Ky(e,t){const n=t.createElement("button");return n.type="button",n.className=De,n.textContent=Aa,n.setAttribute("aria-label",Aa),n.addEventListener("click",()=>{const r=t.defaultView??window;Np(r)&&wp(e,r)}),n}function Wy(e,t){const n=e.preQueryDisclosure;if(!n||n.sourceIds.length===0)return null;const r=n.sourceIds.map(h=>et[h]),o=ld({sourceLabels:r,value:e.displayValue??e.value,typeLabel:Xc(e.type)}),a=t.createElement("section");a.className="vera5-pre-query-disclosure",a.setAttribute("aria-label",Ip),a.appendChild(oe(Tp,t));const i=t.createElement("p");i.className="vera5-pre-query-disclosure__message",i.setAttribute("role","note"),i.textContent=o,a.appendChild(i);const s=t.createElement("label");s.className="vera5-pre-query-disclosure__remember";const l=t.createElement("input");l.type="checkbox",l.setAttribute("aria-label",Ta),s.appendChild(l),s.append(` ${Ta}`),a.appendChild(s);const u=t.createElement("div");u.className="vera5-pre-query-disclosure__actions";const p=t.createElement("button");p.type="button",p.className=De,p.textContent=_a,p.setAttribute("aria-label",_a),p.addEventListener("click",h=>{h.stopPropagation(),ir({proceed:!0,rememberDismiss:l.checked})}),u.appendChild(p);const f=t.createElement("button");return f.type="button",f.className=De,f.textContent=Ia,f.setAttribute("aria-label",Ia),f.addEventListener("click",h=>{h.stopPropagation(),ir({proceed:!1,rememberDismiss:!1})}),u.appendChild(f),a.appendChild(u),a}function Zc(e){return vs({value:e.value,iocType:e.type,enrichmentState:e.enrichmentState,summary:e.summary,tags:e.tags,disabledSources:e.disabledSources,sourceResults:e.sourceResults,analystNotes:An(e.value,e.analystNotes)})}function Ir(e){for(const t of e.querySelectorAll(`.${jc}`))t.hidden=!0;for(const t of e.querySelectorAll(`.${Wc} .${mn}`))t.setAttribute("aria-expanded","false")}function jy(e){e.documentElement.dataset.vera5ExportDropdownDismiss!=="1"&&(e.documentElement.dataset.vera5ExportDropdownDismiss="1",e.addEventListener("click",()=>{Ir(e)}))}function pi(e,t,n,r){const o=r.createElement("div");o.className=Wc;const a=r.createElement("button");a.type="button",a.className=mn,a.textContent=e,a.setAttribute("aria-label",t),a.setAttribute("aria-haspopup","menu"),a.setAttribute("aria-expanded","false");const i=r.createElement("ul");i.className=jc,i.setAttribute("role","menu"),i.hidden=!0;for(const s of n){const l=r.createElement("li");l.setAttribute("role","none");const u=r.createElement("button");u.type="button",u.className=Ay,u.textContent=s.label,u.setAttribute("role","menuitem"),u.addEventListener("mousedown",p=>{p.stopPropagation()}),u.addEventListener("click",p=>{p.stopPropagation(),Ir(r),Promise.resolve(s.action())}),l.appendChild(u),i.appendChild(l)}return a.addEventListener("mousedown",s=>{s.stopPropagation()}),a.addEventListener("click",s=>{s.stopPropagation();const l=i.hidden;Ir(r),i.hidden=!l,a.setAttribute("aria-expanded",l?"true":"false")}),o.appendChild(a),o.appendChild(i),o}function el(e,t,n){return[{format:"markdown",exportLabel:"Export Markdown",copyLabel:"Copy Markdown"},{format:"json",exportLabel:"Export JSON",copyLabel:"Copy JSON"},{format:"txt",exportLabel:"Export TXT",copyLabel:"Copy TXT"}].map(({format:o,exportLabel:a,copyLabel:i})=>({label:n==="export"?a:i,action:()=>{const s=e(),l=[{value:s.value,type:s.type}];if(n==="export"){qf(s,o,t),Ae(l);return}if(o==="markdown"){Vf(s).then(u=>{u&&Ae(l)});return}if(o==="json"){Uf(s).then(u=>{u&&Ae(l)});return}Ff(s).then(u=>{u&&Ae(l)})}}))}function qy(e,t){return[{label:"Copy all",action:()=>{const o=hn();if(o&&o.summary.entries.length>0){Z(Xt(o.summary.entries)).then(a=>{T(t,Jt({copied:a,count:o.summary.entries.length,filtered:!1}),a)});return}vn().then(a=>{if(!a||a.summary.entries.length===0){T(t,ee,!1);return}Z(Xt(a.summary.entries)).then(i=>{T(t,Jt({copied:i,count:a.summary.entries.length,filtered:!1}),i)})})}},{label:"Copy filtered",action:()=>{const o=hn();if(o){const a=ke(o.summary.entries,o.filter);if(a.length===0){T(t,ee,!1);return}Z(Xt(a)).then(i=>{T(t,Jt({copied:i,count:a.length,filtered:!0}),i)});return}vn().then(a=>{if(!a){T(t,ee,!1);return}const i=ke(a.summary.entries,a.filter);if(i.length===0){T(t,ee,!1);return}Z(Xt(i)).then(s=>{T(t,Jt({copied:s,count:i.length,filtered:!0}),s)})})}}]}function Xy(e,t,n){return[...qy(t,n),...nS(n),...el(e,t,"copy")]}function Jy(e,t,n){return[...tS(t,n),...el(e,t,"export")]}function T(e,t,n){e.textContent=t,e.hidden=t.length===0,e.classList.remove("vera5-hover-card-scan-export-status--success","vera5-hover-card-scan-export-status--error"),e.classList.add(n?"vera5-hover-card-scan-export-status--success":"vera5-hover-card-scan-export-status--error")}const ee="Scan this page first to export detected indicators.",Qy="Preparing export…";let Ie=null,Xo=null,Tr=null;function Jo(e){Tr=e}function hn(){return Tr?Tr():Ie?.context??null}async function tl(){try{const e=hn()??await vn();if(!e)return{context:null,records:[]};const t=ke(e.summary.entries,e.filter);if(t.length===0)return{context:e,records:[]};const n=await mc(t);return{context:e,records:n}}catch{return{context:null,records:[]}}}function xr(){Xo=tl().then(e=>(Ie=e,e))}function Zy(){Ie=null,Xo=null}function gn(e,t,n){const r=o=>{Promise.resolve(t(o)).catch(()=>{if(n){n();return}T(e,ee,!1)})};if(Ie&&Ie.records.length>0){r(Ie),xr();return}T(e,Qy,!1),(Xo??tl()).then(o=>{Ie=o,r(o),xr()}).catch(()=>{if(n){n();return}T(e,ee,!1)})}function eS(e,t,n){return!e.context||e.records.length===0?!1:(t==="markdown"?po("markdown-report",e.records,n):Yf(e.records,t,n),Ae(qo(e.records)),!0)}function tS(e,t){return[{format:"markdown",label:"Export filtered Markdown"},{format:"json",label:"Export filtered JSON"}].map(({format:r,label:o})=>({label:o,action:()=>{gn(t,a=>{if(!eS(a,r,e)){T(t,ee,!1);return}T(t,Ka({success:!0,count:a.records.length,format:r}),!0)},()=>{T(t,Ka({success:!1,count:0,format:r}),!1)})}}))}function nS(e){return[{format:"markdown",label:"Copy filtered Markdown"},{format:"json",label:"Copy filtered JSON"}].map(({format:n,label:r})=>({label:r,action:()=>{gn(e,async o=>{if(!o.context||o.records.length===0){T(e,ee,!1);return}const a=n==="markdown"?await fo("markdown-report",o.records):await Gf(o.records);T(e,ja({success:a,count:o.records.length,format:n}),a),a&&Ae(qo(o.records))},()=>{T(e,ja({success:!1,count:0,format:n}),!1)})}}))}function rS(e,t){const n=e.createElement("div");n.className=Ty,n.setAttribute("role","group"),n.setAttribute("aria-label","Export ticket templates");const r=e.createElement("label");r.className=xy,r.htmlFor=ui,r.textContent="Template";const o=e.createElement("select");o.id=ui,o.className=Ly;for(const s of Qf()){const l=e.createElement("option");l.value=s,l.textContent=Tt(s),o.appendChild(l)}o.value=Go().defaultExportTemplateId;const a=e.createElement("button");a.type="button",a.className=mn,a.textContent="Export template",a.setAttribute("aria-label","Export filtered indicators using the selected template"),a.addEventListener("click",()=>{const s=o.value;dr(s)&&gn(t,l=>{if(!l.context||l.records.length===0){T(t,ee,!1);return}po(s,l.records,e),T(t,Wa({success:!0,count:l.records.length,templateId:s}),!0)},()=>{T(t,Wa({success:!1,count:0,templateId:s}),!1)})});const i=e.createElement("button");return i.type="button",i.className=mn,i.textContent="Copy template",i.setAttribute("aria-label","Copy filtered indicators using the selected template"),i.addEventListener("click",()=>{const s=o.value;dr(s)&&gn(t,async l=>{if(!l.context||l.records.length===0){T(t,ee,!1);return}const u=await fo(s,l.records);T(t,qa({success:u,count:l.records.length,templateId:s}),u),u&&Ae(qo(l.records))},()=>{T(t,qa({success:!1,count:0,templateId:s}),!1)})}),n.append(r,o,a,i),n}async function vn(){const e=hn();if(e)return e;const t=await Vc();if(!t||t.entries.length===0)return null;const n=await Oc(t.tabId);return{summary:t,filter:n}}async function fi(){const e=await vn();if(!e)return[];const t=ke(e.summary.entries,e.filter);return t.length===0?[]:mc(t)}function oS(e,t){jy(t),Zy(),xr();const n=t.createElement("section");n.className=my,n.setAttribute("aria-label","Export case artifacts");const r=t.createElement("p");r.className=Iy,r.hidden=!0,r.setAttribute("aria-live","polite");const o=t.createElement("div");o.className=_y;const a=t.createElement("div");a.className=Cy,a.setAttribute("role","group"),a.setAttribute("aria-label","Export and copy case artifacts");const i=()=>Zc(e);return a.appendChild(pi("Export","Export case artifacts as a file",Jy(i,t,r),t)),a.appendChild(pi("Copy","Copy case artifacts to the clipboard",Xy(i,t,r),t)),o.appendChild(a),o.appendChild(rS(t,r)),o.appendChild(r),n.appendChild(o),n}function aS(e,t,n){const r=n.createElement("section");r.className=ZE,r.setAttribute("aria-label",Kd);const o=oe(Yd,n);o.id="vera5-ioc-label-heading",o.className=ey;const a=n.createElement("select");a.id=Xi,a.className=ty,a.setAttribute("aria-labelledby",o.id);const i=n.createElement("option");i.value=ht,i.textContent="None",a.appendChild(i);for(const s of nc){const l=n.createElement("option");l.value=s,l.textContent=Qh(s),a.appendChild(l)}return a.value=t??ht,a.addEventListener("change",()=>{const s=a.value===ht?null:a.value;tg(e,s)}),a.addEventListener("mousedown",s=>{s.stopPropagation()}),rg(e,s=>{a.value===ht&&s&&(a.value=s)}),r.appendChild(o),r.appendChild(a),r}function iS(e,t){const n=t.createElement("button");n.type="button",n.className=py,n.setAttribute("aria-label",Qd);const r=o=>{n.setAttribute("aria-pressed",o?"true":"false"),n.textContent=o?Jd:Xd,n.classList.toggle(fy,o)};return r(!1),$o().then(o=>{o&&r(ni(o,e.value))}),n.addEventListener("click",o=>{o.stopPropagation(),wc({iocValue:e.value,iocType:e.type}).then(a=>{a&&r(ni(a,e.value))})}),n}function sS(e,t){const n=t.createElement("section");n.className=ly,n.setAttribute("aria-label",jd);const r=oe(Wd,t);r.id="vera5-ioc-timeline-heading",r.className=uy;const o=t.createElement("ul");o.className=dy,o.setAttribute("aria-labelledby",r.id);const a=t.createElement("li");return a.className=si,a.textContent=qd,o.appendChild(a),n.appendChild(r),n.appendChild(o),$o().then(i=>{if(!i)return;const s=qg(i,e);if(s){o.replaceChildren();for(const l of Zg(s)){const u=t.createElement("li");u.className=si,u.textContent=l,o.appendChild(u)}}}),n}function Qo(){Ue=!1,ie=null,Ce="",_e=[],fn=!1}function Zo(){K={status:"idle"}}async function cS(e,t){if(!tc()){K={status:"error",message:"Enable local AI summary in Vera5 Settings."},$(t);return}if(e.enrichmentState!=="ready"){K={status:"error",message:"Complete enrichment before generating a summary."},$(t);return}K={status:"loading"},$(t);const n=uo(Zc(e)),r=await yE({exportDocument:n,useLocalBackend:Yh(),endpointUrl:Uc});if(!r.ok){K={status:"error",message:r.errorMessage},$(t);return}K={status:"success",markdown:r.markdown},$(t)}function lS(e,t){if(!tc())return null;const n=t.createElement("section");n.className=hy,n.setAttribute("aria-label",tr);const r=oe(tr,t);r.className=Ey,r.id="vera5-local-llm-summary-heading",n.setAttribute("aria-labelledby",r.id),n.appendChild(r);const o=t.createElement("div");o.className=yy,o.setAttribute("role","group"),o.setAttribute("aria-label",tr);const a=t.createElement("button");if(a.type="button",a.className=De,a.textContent=li,a.setAttribute("aria-label",li),a.disabled=e.enrichmentState!=="ready"||K.status==="loading",a.addEventListener("click",()=>{cS(e,t)}),o.appendChild(a),K.status==="loading"){const i=t.createElement("p");i.className=`${ci} vera5-hover-card-local-llm-summary-status--loading`,i.textContent=Sy,i.setAttribute("role","status"),i.setAttribute("aria-live","polite"),i.setAttribute("aria-busy","true"),o.appendChild(i)}if(K.status==="error"){const i=t.createElement("p");i.className=`${ci} vera5-hover-card-local-llm-summary-status--error`,i.textContent=K.message,i.setAttribute("role","alert"),o.appendChild(i)}if(K.status==="success"){const i=t.createElement("p");i.className=vy,i.textContent=by,o.appendChild(i);const s=t.createElement("div");s.className=gy,s.textContent=K.markdown,o.appendChild(s)}return n.appendChild(o),n}async function uS(e){Ue=!0,ie=null,Ce="",fn=!0,_e=[],$(e),_e=await zo(),fn=!1,$(e)}function dS(e,t){const n=t.createElement("section");n.className=ny,n.setAttribute("aria-label",St),n.addEventListener("click",u=>{u.stopPropagation()}),n.addEventListener("keydown",u=>{u.stopPropagation()});const r=t.createElement("button");if(r.type="button",r.className=ry,r.textContent=uc,r.setAttribute("aria-expanded",Ue?"true":"false"),r.addEventListener("click",()=>{if(Ue){Ue=!1,ie=null,$(t);return}uS(t)}),n.appendChild(r),!Ue)return n;const o=t.createElement("div");o.className=oy,o.setAttribute("role","group"),o.setAttribute("aria-label",St);const a=t.createElement("p");if(a.className=ay,a.textContent=St,o.appendChild(a),fn){const u=t.createElement("p");u.className="vera5-workspace-empty",u.textContent="Loading collections…",o.appendChild(u)}else if(_e.length===0){const u=t.createElement("p");u.className="vera5-workspace-empty",u.textContent=Po,o.appendChild(u)}else{const u=t.createElement("div");u.className=iy;for(const p of _e){const f=t.createElement("button");f.type="button",f.className=De,f.textContent=p.name,f.addEventListener("click",()=>{(async()=>{const h=await pn({collectionId:p.id,member:{iocType:e.type,value:e.value}});ie=h?cn({collectionName:h.collection.name,added:h.added}):"Could not save to collection.",$(t)})()}),u.appendChild(f)}o.appendChild(u)}const i=t.createElement("label");i.className=cy,i.textContent=Do;const s=t.createElement("input");s.type="text",s.value=Ce,s.placeholder=qe,s.setAttribute("aria-label",qe),s.addEventListener("input",()=>{Ce=s.value,$(t)}),s.addEventListener("mousedown",u=>{u.stopPropagation()}),i.appendChild(s),o.appendChild(i);const l=t.createElement("button");if(l.type="button",l.className=De,l.textContent=Mo,l.disabled=kn(Ce)===null,l.addEventListener("click",()=>{(async()=>{const u=await Yo({name:Ce});if(!u){ie="Could not create collection.",$(t);return}const p=await pn({collectionId:u.id,member:{iocType:e.type,value:e.value}});if(!p){ie="Collection created, but indicator was not saved.",$(t);return}_e=[p.collection,..._e.filter(f=>f.id!==p.collection.id)],Ce="",ie=cn({collectionName:p.collection.name,added:p.added}),$(t)})()}),o.appendChild(l),ie){const u=t.createElement("p");u.className=sy,u.setAttribute("aria-live","polite"),u.textContent=ie,o.appendChild(u)}return n.appendChild(o),n}function pS(e,t,n){const r=n.createElement("section");r.className=JE,r.setAttribute("aria-label",zd);const o=oe($d,n);o.id="vera5-analyst-notes-heading";const a=n.createElement("textarea");return a.id=ro,a.className=QE,a.placeholder=Gd,a.rows=3,a.value=t,a.setAttribute("aria-labelledby",o.id),a.addEventListener("input",()=>{hd(e,a.value)}),a.addEventListener("mousedown",i=>{i.stopPropagation()}),vd(e,i=>{a.value.length===0&&i.length>0&&(a.value=i)}),r.appendChild(o),r.appendChild(a),r}function nl(e=document){const t=e.getElementById(kt);if(t)return t;const n=e.createElement("div");return n.id=kt,n.style.position="fixed",n.style.top="0",n.style.left="0",n.style.width="0",n.style.height="0",n.style.zIndex="2147483646",n.style.pointerEvents="none",e.body.appendChild(n),n}function fS(e,t){const n=t.createElement("button");return n.type="button",n.className="vera5-hover-card-detail-clear",n.textContent="↻",n.setAttribute("aria-label","Clear indicator details"),n.addEventListener("click",e.onClear),n}function mS(e,t){const n=t.createDocumentFragment(),r=so(e);if(!r.showRefangedPair){const i=t.createElement("p");return i.className="vera5-hover-card-value",i.textContent=r.refangedValue,n.appendChild(i),n}const o=t.createElement("p");o.className="vera5-hover-card-value-on-page",o.textContent=`${yp} ${r.onPageValue}`,n.appendChild(o);const a=t.createElement("p");return a.className="vera5-hover-card-refanged-value",a.textContent=`${as} ${r.refangedValue}`,n.appendChild(a),n}function rl(e,t,n={}){const r=t.createElement("section");r.className=n.compact?`${di} ${qc}`:di,r.setAttribute("aria-label",vp),n.omitHeading||r.appendChild(oe(rs,t));const o=t.createElement("p");o.className="vera5-why-detected-row",o.textContent=`Type: ${e.typeLabel}`,r.appendChild(o);const a=t.createElement("p");a.className="vera5-why-detected-row",a.textContent=`Reason: ${e.reason}`,r.appendChild(a);const i=t.createElement("p");if(i.className="vera5-why-detected-row vera5-why-detected-context",i.textContent=`Source context: ${e.sourceTextHint}`,r.appendChild(i),e.ignoredOverlaps.length>0){const s=t.createElement("p");s.className="vera5-why-detected-overlaps-heading",s.textContent="Ignored overlaps:",r.appendChild(s);const l=t.createElement("ul");l.className=Ry;for(const u of e.ignoredOverlaps){const p=t.createElement("li");p.className=Oy,p.textContent=`${u.typeLabel} ${u.value} — ${u.reason}`,l.appendChild(p)}r.appendChild(l)}else{const s=t.createElement("p");s.className="vera5-why-detected-row",s.textContent="Ignored overlaps: none",r.appendChild(s)}return r}function ea(e,t=document,n={}){Ft(t);const r=Go(),o=cs(e.type,e.value,{emphasisProviders:r.pivotEmphasisProviders}),a=e.sourceResults??[],i=gp({enrichmentState:e.enrichmentState,summary:e.summary,tags:e.tags,sourceAttribution:e.sourceAttribution,errorMessage:e.errorMessage,errorCode:e.errorCode,retryHint:e.retryHint,disabledSources:e.disabledSources,sourceResults:a,pivotLinkCount:o.length}),s=i.enrichment,l=i.showMultiSourceResults?Hy(a,t):null,u=i.showSingleSourceRawJson&&i.singleSourceRawJson?.trim()?Jc(i.singleSourceRawJson,t):null,p=Uy(i.disabledSourcePlaceholders,t),f=Py(e,t),h=i.showTags?Qc(i.enrichmentTags,t):null,E=Zi(e.sourceAttribution,a),S={enrichmentState:s.variant,includeRiskScoreDisclaimer:i.includeRiskScoreDisclaimer},L=i.showAttribution&&E?Fy(E,s.variant,t):null,z=i.showDisclaimer?Vy(i.disclaimerLines,S,t):null,m=i.showMissingKeyAction?By(t):null,V=i.showRateLimitRetryHint&&e.retryHint?Gy(e.retryHint,t):null,X=i.singleSourceLastUpdatedLine?$y(i.singleSourceLastUpdatedLine,t):null,A=i.showBelowSummary,N=i.showFooter,J=i.showRiskScore?My(e,t):null,Ee=pS(e.value,An(e.value,e.analystNotes),t),ye=aS(e.value,og(e.value,e.iocLabel),t),Se=sS(e.value,t),ue=dS(e,t),it=oS(e,t),C=lS(e,t),ae=os({type:e.type,ruleId:e.ruleId,sourceTextHint:e.sourceTextHint,ignoredOverlaps:e.ignoredOverlaps}),be=ae?rl(ae,t):null,jn=Wy(e,t),I=t.createElement("aside");I.className=NE,I.setAttribute("role","region"),I.setAttribute("aria-label",`Indicator details for ${e.value}`),e.ruleId&&(I.dataset.vera5RuleId=e.ruleId),e.sourceTextHint&&(I.dataset.vera5SourceTextHint=e.sourceTextHint);const Wt=t.createElement("div");Wt.className="vera5-hover-card-header";const qn=t.createElement("span");qn.className="vera5-hover-card-type",qn.textContent=Xc(e.type),Wt.appendChild(qn);const st=t.createElement("div");if(st.className="vera5-hover-card-header-actions",st.appendChild(iS(e,t)),st.appendChild(Yy(e,t)),n.detailClear&&st.appendChild(fS(n.detailClear,t)),Wt.appendChild(st),I.appendChild(Wt),I.appendChild(mS(e,t)),Lp(e.type)){const ma=Ky(e.value,t);ma.style.marginBottom="8px",I.appendChild(ma)}be&&(be.style.marginBottom="8px",I.appendChild(be)),jn&&(jn.style.marginBottom="8px",I.appendChild(jn));const de=t.createElement("section");de.className=wy,de.setAttribute("aria-label","Threat intelligence summary"),de.appendChild(oe("Intel Summary",t));const pe=t.createElement("p");return pe.className=fh(s.variant,HE),A&&(pe.style.marginBottom="8px"),pe.textContent=s.text,s.variant==="error"?pe.setAttribute("role","alert"):pe.setAttribute("role","status"),s.variant==="loading"&&(pe.setAttribute("aria-live","polite"),pe.setAttribute("aria-busy","true")),de.appendChild(pe),J&&(J.style.marginBottom=A?"8px":"0",de.appendChild(J)),m&&(m.style.marginBottom=A?"8px":"0",de.appendChild(m)),V&&(V.style.marginBottom=A?"8px":"0",de.appendChild(V)),I.appendChild(de),C&&(C.style.marginBottom=N?"8px":"0",I.appendChild(C)),u&&(u.style.marginBottom=N?"8px":"0",I.appendChild(u)),X&&(X.style.marginBottom=N?"8px":"0",I.appendChild(X)),h&&(h.style.marginBottom=N?"8px":"0",I.appendChild(h)),l&&(l.style.marginBottom=N?"8px":"0",I.appendChild(l)),p&&I.appendChild(p),f&&I.appendChild(f),ye.style.marginBottom=N?"8px":"0",I.appendChild(ye),Se.style.marginBottom=N?"8px":"0",I.appendChild(Se),ue.style.marginBottom=N?"8px":"0",I.appendChild(ue),Ee.style.marginBottom=N?"8px":"0",I.appendChild(Ee),it.style.marginBottom=N?"8px":"0",I.appendChild(it),L&&I.appendChild(L),z&&I.appendChild(z),I}function hS(e,t,n=Ko()){const r=t.getBoundingClientRect();e.style.visibility="hidden",e.style.display="block";const o=e.getBoundingClientRect(),a={width:Math.max(o.width,e.offsetWidth,220),height:Math.max(o.height,e.offsetHeight,80)},i=kc(r,a,n);return Dc(e,i),e.style.visibility="visible",i}function En(e,t,n=document,r={}){O&&O.value!==t.value&&(Qo(),Zo()),Xe=e;const o=nl(n);o.replaceChildren();const a=An(t.value,t.analystNotes),i={...t,analystNotes:a.length>0?a:void 0};O=i;const s=ea(i,n);return o.appendChild(s),hS(s,e,Ko(n.defaultView??window)),r.moveFocus&&Fc(s),s}function gS(e,t,n=document,r={}){let o=n.body,a=e.commonAncestorContainer;a.nodeType===Node.TEXT_NODE&&(a=a.parentElement),a instanceof Element&&(o=a),O&&O.value!==t.value&&(Qo(),Zo()),Xe=o;const i=nl(n);i.replaceChildren();const s=An(t.value,t.analystNotes),l={...t,analystNotes:s.length>0?s:void 0};O=l;const u=ea(l,n);i.appendChild(u);const p=e.getBoundingClientRect();u.style.visibility="hidden",u.style.display="block";const f=u.getBoundingClientRect(),h={width:Math.max(f.width,u.offsetWidth,220),height:Math.max(f.height,u.offsetHeight,80)},E=kc(p,h,Ko(n.defaultView??window));return Dc(u,E),u.style.visibility="visible",r.moveFocus&&Fc(u),u}function vS(e,t,n=document){if(!O||j(O.value)!==j(e))return;const r=n.getElementById(ro);if(!r||r.value===t)return;const o=n.activeElement===r,a=r.selectionStart,i=r.selectionEnd;if(r.value=t,O={...O,analystNotes:t.length>0?t:void 0},o){r.focus();const s=Math.min(a,t.length);r.setSelectionRange(s,Math.min(i,t.length))}}function ES(e,t,n=document){if(!O||j(O.value)!==j(e))return;const r=n.getElementById(Xi),o=t??ht;if(!r||r.value===o)return;const a=n.activeElement===r;r.value=o,O={...O,iocLabel:t??void 0},a&&r.focus()}function $(e=document){!Xe||!O||En(Xe,O,e)}function Fn(e=document){Gi(),Qo(),Zo();const t=e.getElementById(kt);t&&(t.replaceChildren(),Xe=null,O=null,LE(e))}const yS="modulepreload",SS=function(e){return"/"+e},mi={},Lr=function(t,n,r){let o=Promise.resolve();if(n&&n.length>0){let i=function(u){return Promise.all(u.map(p=>Promise.resolve(p).then(f=>({status:"fulfilled",value:f}),f=>({status:"rejected",reason:f}))))};document.getElementsByTagName("link");const s=document.querySelector("meta[property=csp-nonce]"),l=s?.nonce||s?.getAttribute("nonce");o=i(n.map(u=>{if(u=SS(u),u in mi)return;mi[u]=!0;const p=u.endsWith(".css"),f=p?'[rel="stylesheet"]':"";if(document.querySelector(`link[href="${u}"]${f}`))return;const h=document.createElement("link");if(h.rel=p?"stylesheet":yS,p||(h.as="script"),h.crossOrigin="",h.href=u,l&&h.setAttribute("nonce",l),document.head.appendChild(h),p)return new Promise((E,S)=>{h.addEventListener("load",E),h.addEventListener("error",()=>S(new Error(`Unable to preload CSS for ${u}`)))})}))}function a(i){const s=new Event("vite:preloadError",{cancelable:!0});if(s.payload=i,window.dispatchEvent(s),!s.defaultPrevented)throw i}return o.then(i=>{for(const s of i||[])s.status==="rejected"&&a(s.reason);return t().catch(a)})};function bS(e){const t=`chrome-extension://${e}`;return`chrome://settings/content/siteDetails?site=${encodeURIComponent(t)}`}function CS(e=chrome.runtime.id){const t=bS(e);if(typeof chrome.tabs?.create=="function"){chrome.tabs.create({url:t});return}q(Wu())}function AS(e){return e.enabled?e.scanState==="scanning"?"scanning":e.scanState==="done"&&e.scanSummary?e.scanSummary.totalCount>0?"results":"empty":"prompt":null}const _S=60,IS=3600,TS=15e3,xS=15e3,LS=400,NS={[g.ABUSEIPDB]:{liveEnrichment:!0,requestTimeoutSeconds:TS/1e3,quotaSummary:"Typical free tier: 1,000 checks/day (resets 00:00 UTC). Confirm limits in your AbuseIPDB account.",rateLimitHeaderHints:["Retry-After","X-RateLimit-Limit","X-RateLimit-Remaining","X-RateLimit-Reset"]},[g.OTX]:{liveEnrichment:!0,requestTimeoutSeconds:xS/1e3,quotaSummary:"Typical keyed tier: 10,000 requests/hour. Confirm limits in your OTX account.",rateLimitHeaderHints:["Retry-After"]},[g.URLSCAN]:{liveEnrichment:!1,requestTimeoutSeconds:null,quotaSummary:"Live enrichment not shipped. Toggle stores preference and pivot links only.",rateLimitHeaderHints:["X-Rate-Limit-Limit","X-Rate-Limit-Remaining"]},[g.GREYNOISE]:{liveEnrichment:!1,requestTimeoutSeconds:null,quotaSummary:"Live enrichment not shipped. Toggle stores preference and pivot links only.",rateLimitHeaderHints:[]}};function ol(){return{defaultGlobalCooldownSeconds:_S,maxGlobalCooldownSeconds:IS,hoverEnrichmentDebounceMs:LS,manualRefreshBypassesGlobalCooldown:!0,sources:x.map(e=>({sourceId:e,...NS[e]}))}}function wS(e){return e===d.IPV4}function al(e,t){return e[t]===!0}function RS(e,t){return Dd(e).liveConnector?e===g.CENSYS?wS(t):Md(e,t):!1}function il(e,t){return ji.filter(n=>al(e,n)&&RS(n,t))}function OS(e){return ji.some(t=>al(e,t))}function kS(e,t,n){const r=new Map(e.map(l=>[l.anchorId,l])),o=new Set;let a=0;for(const l of t){const u=r.get(l);if(!u)continue;const p=il(n,u.type);a+=p.length;for(const f of p)o.add(f)}const i=ol(),s=[...o].map(l=>{const u=i.sources.find(p=>p.sourceId===l);return{sourceId:l,label:et[l],quotaSummary:u?.quotaSummary??"Confirm limits in your vendor account."}});return{iocCount:t.length,maxLiveRequests:a,quotaSummaries:s}}function DS(e){const t=[],n=ol();if(e.maxLiveRequests===0)t.push(`Enrich ${e.iocCount} selected indicator${e.iocCount===1?"":"s"} without live vendor queries (no live enrichment sources are enabled for these types).`);else{t.push(`Enrich ${e.iocCount} selected indicator${e.iocCount===1?"":"s"} with up to ${e.maxLiveRequests} live vendor request${e.maxLiveRequests===1?"":"s"}.`),t.push("Vendor quotas apply:");for(const r of e.quotaSummaries)t.push(`• ${r.label}: ${r.quotaSummary}`)}return t.push(`Rate limits may pause or fail queue items. After a vendor rate limit, Vera5 may wait up to ${n.maxGlobalCooldownSeconds} seconds before retrying.`),t.join(`

`)}const hi="manualOnlyMode";async function MS(){const t=(await k(hi))[hi];return t===void 0?!0:!!t}let Nr=null;function PS(e){Nr=e}async function HS(){return!await MS()}async function ta(e){return D()||!await HS()?!1:(Nr&&await Nr(e),!0)}const US="ENRICH_IOC";function sl(e){if(!Array.isArray(e))return;const t=e.filter(n=>typeof n=="string").map(n=>n.trim()).filter(n=>n.length>0);return t.length>0?t:void 0}function VS(e){if(typeof e!="object"||e===null)return!1;const t=e;return!(typeof t.sourceId!="string"||typeof t.sourceLabel!="string"||t.status!=="ok"&&t.status!=="error"&&t.status!=="skipped"||t.summary!==void 0&&typeof t.summary!="string"||t.tags!==void 0&&sl(t.tags)===void 0||t.errorMessage!==void 0&&typeof t.errorMessage!="string"||t.fromCache!==void 0&&typeof t.fromCache!="boolean"||t.errorCode!==void 0&&typeof t.errorCode!="string"||t.retryHint!==void 0&&typeof t.retryHint!="string"||t.rawVendorJson!==void 0&&typeof t.rawVendorJson!="string")}function wr(e){if(!VS(e))return null;const t=e,n={sourceId:t.sourceId,sourceLabel:t.sourceLabel,status:t.status};t.summary&&(n.summary=t.summary);const r=sl(t.tags);r&&(n.tags=r),t.errorMessage&&(n.errorMessage=t.errorMessage),t.fromCache===!0&&(n.fromCache=!0),typeof t.fetchedAt=="string"&&t.fetchedAt.trim()&&(n.fetchedAt=t.fetchedAt.trim()),t.errorCode&&(n.errorCode=t.errorCode),t.retryHint&&(n.retryHint=t.retryHint);const o=t.rawVendorJson?.trim();return o&&(n.rawVendorJson=o),n}function FS(e){if(!Array.isArray(e))return[];const t=[];for(const n of e){const r=wr(n);r&&t.push(r)}return t}async function BS(e){const t=Pu({value:e.value,type:e.iocType});if(!t)return null;const n={type:US,value:t.value,iocType:t.type};e.sourceId&&(n.sourceId=e.sourceId),e.bypassCache===!0&&(n.bypassCache=!0);const r=await q(n);if(!r?.ok||typeof r.payload!="object"||r.payload===null)return null;const o=r.payload,a=FS(o.sources);if(a.length===0){const s=wr(o.source);return s?{sources:[s],primary:s}:null}const i=wr(o.source)??a[0]??null;return{sources:a,primary:i}}const gi="enrichmentSourceEnabled",vi="showDisabledSourcesInWorkspace";function $S(){return Object.fromEntries(x.map(e=>[e,le[e].enabledDefault]))}function GS(e){const t=$S();if(e===null||typeof e!="object"||Array.isArray(e))return t;for(const n of x){const r=e[n];typeof r=="boolean"&&(t[n]=r)}return t}async function na(){const e=await k(gi);return GS(e[gi])}async function zS(){return(await k(vi))[vi]===!0}async function YS(){const e=await k(Te);return e[Te]===void 0?!0:e[Te]===!0}async function KS(e){await Gm(e)}function WS(e,t=!0){const n=x.filter(r=>!e[r]);return t?n:[]}function jS(e){return x.filter(t=>e[t])}async function Bn(){const[e,t]=await Promise.all([na(),zS()]);return{sources:e,showDisabledSourcesInWorkspace:t,disabledSourceIds:WS(e,t),enabledSourceIds:jS(e)}}async function qS(){const e=await k([Be,$e,Ge]),t=vm();return e[Be]===void 0&&e[$e]===void 0&&e[Ge]===void 0?t:Sm({domains:e[Be]??t.domains,cidrRanges:e[$e]??t.cidrRanges,vendorLabels:e[Ge]??t.vendorLabels})}async function XS(){const e=await k(Fe);return e[Fe]===void 0?!0:e[Fe]===!0}async function JS(e,t){const n=await XS();if(!n)return!0;const r=await qS();return _m(r)?!Am(e,t,r):!0}let we={open:!1,selectedAnchorId:null,payloadValue:null},Rr=null;function QS(e){Rr=e}function ot(e){we={open:e.open,selectedAnchorId:e.selectedAnchorId===void 0?we.selectedAnchorId:e.selectedAnchorId,payloadValue:e.payloadValue===void 0?we.payloadValue:e.payloadValue}}function $n(){we={open:we.open,selectedAnchorId:null,payloadValue:null}}function cl(e,t=document){return!we.open||we.payloadValue!==e.value?!1:t.getElementById("vera5-workspace-host")!==null}function Ei(e,t=document){return!cl(e,t)||!Rr?!1:(Rr(e,t),!0)}const ZS=400,ll="Threat intelligence queries are blocked for this site by domain policy.",eb="Threat intelligence queries are blocked for this indicator because it matches a configured internal asset list.";let Ct=null;function G(){Ct!==null&&(clearTimeout(Ct),Ct=null),Gi()}async function ra(e=document){return await jm(e)?{allowed:!0}:{allowed:!1,errorCode:In.DOMAIN_POLICY,errorMessage:ll}}async function ul(e,t){return await JS(e,t)?{allowed:!0}:{allowed:!1,errorCode:In.INTERNAL_ASSET,errorMessage:eb}}function Or(e,t,n=document){Re({...e,enrichmentState:"error",errorCode:t.errorCode,errorMessage:t.errorMessage,preQueryDisclosure:void 0},n)}function tb(e,t=document,n=ZS){G(),Ct=setTimeout(()=>{Ct=null,Yt(e,t)},n)}function nb(e,t){const n=ns(t);return{...e,enrichmentState:n.enrichmentState,summary:n.summary,tags:n.tags,sourceAttribution:n.sourceAttribution,errorMessage:n.errorMessage,errorCode:n.errorCode,retryHint:n.retryHint,sourceResults:n.sourceResults,preQueryDisclosure:void 0}}function Re(e,t){if(Ei(e,t))return!0;const n=Bc(),r=$c();return n&&r?.value===e.value?(En(n,e,t),!0):Ei(e,t)}function yi(e,t){if(cl(e,t))return!0;const n=Bc(),r=$c();return!!(n&&r?.value===e.value)}async function rb(e,t,n){const r=await YS();if(!r||t.length===0)return!0;const o=cd();Re({...e,enrichmentState:"empty",preQueryDisclosure:{sourceIds:t}},n);const a=await o;return a.rememberDismiss&&await KS(!1),a.proceed}async function ob(e,t,n){Re({...e,enrichmentState:"loading",preQueryDisclosure:void 0},t);const r={value:e.value,iocType:e.type};n.bypassCache===!0&&(r.bypassCache=!0);const o=await BS(r);if(!o||o.sources.length===0){Re({...e,enrichmentState:"error",errorMessage:"Threat intelligence could not be loaded.",preQueryDisclosure:void 0},t);return}Re(nb(e,o.sources),t)}async function Yt(e,t=document,n={}){if(D()||!yi(e,t))return"skipped";const r=await na();if(!OS(r))return Re({...e,enrichmentState:"error",errorCode:In.DISABLED,errorMessage:"No enrichment sources are enabled in extension settings.",preQueryDisclosure:void 0},t),"blocked";const o=il(r,e.type),a=await ra(t);if(!a.allowed)return Or(e,a,t),"blocked";const i=await ul(e.value,e.type);return i.allowed?await rb(e,o,t)?yi(e,t)?(await ob(e,t,n),"completed"):"skipped":(Re({...e,enrichmentState:"empty",preQueryDisclosure:void 0},t),"cancelled"):(Or(e,i,t),"blocked")}function ab(){PS(e=>{tb(e)})}const ib=new Set(Object.values(d));function dl(e){return ib.has(e)}function Dt(e){if(!e)return null;const t=e.closest(`.${tt}`);if(!t)return null;const n=t.dataset.vera5Value,r=t.dataset.vera5Type;return!n||!r||!dl(r)?null:t}function at(e){const t=e.dataset.vera5Value,n=e.dataset.vera5Type;if(!t||!n||!dl(n))return null;const r=Sh(e),o=yh(e);return{value:t,type:n,...r??{},...o?{displayValue:o}:{},enrichmentState:"empty"}}function pl(e){return e.closest(`.${Ks}`)!==null}function Gn(e,t={},n=document){const r=at(e);return r?(t.moveFocusToPanel?_r(e):_r(null),D()?(En(e,r,n,{moveFocus:t.moveFocusToPanel}),!0):(Bn().then(({disabledSourceIds:o,enabledSourceIds:a,showDisabledSourcesInWorkspace:i})=>{const s={...r,...o.length>0?{disabledSources:o}:{},enabledEnrichmentSourceIds:a,showDisabledSourcesInWorkspace:i};En(e,s,n,{moveFocus:t.moveFocusToPanel}),t.enrichmentTrigger==="manual"?(G(),Yt(s,n,{bypassCache:!0}).catch(R)):t.enrichmentTrigger!=="none"&&ta(s).catch(R)}).catch(R),!0)):!1}function sb(e){return e.closest(`#${kt}`)!==null}function cb(e,t){const n=e.target;if(!(n instanceof Element))return;const r=Dt(n);if(r){e.preventDefault(),e.stopPropagation(),Gn(r,{enrichmentTrigger:pl(n)?"manual":"auto"},t);return}sb(n)||(G(),Fn(t))}function lb(e,t){return e?e===t.body||e===t.documentElement:!0}function ub(e,t){if(e.key!=="ArrowDown"&&e.key!=="ArrowUp")return!1;const n=e.target instanceof Element?e.target:null;if(n?.closest(`#${kt}`))return!1;const r=e.key==="ArrowDown"?"next":"previous",a=Dt(n)??(lb(t.activeElement,t)?null:void 0);if(a===void 0)return!1;const i=Rh(a,r,t.body);return i?(e.preventDefault(),G(),Fn(t),_r(null),i.scrollIntoView({block:"center",inline:"nearest",behavior:"smooth"}),i.focus(),!0):!1}function db(e,t){if(e.key==="Escape"){G(),Fn(t);return}if(ub(e,t)||e.key!=="Enter"&&e.key!==" ")return;const n=Dt(e.target instanceof Element?e.target:null);n&&(e.preventDefault(),Gn(n,{enrichmentTrigger:pl(e.target instanceof Element?e.target:n)?"manual":"auto",moveFocusToPanel:!0},t))}function pb(e=document){const t=r=>{cb(r,e)},n=r=>{db(r,e)};return e.addEventListener("click",t,!0),e.addEventListener("keydown",n,!0),()=>{e.removeEventListener("click",t,!0),e.removeEventListener("keydown",n,!0),G(),Fn(e)}}function fb(e){return e!==null&&typeof e=="object"&&"type"in e&&e.type===ve.ENRICH_SELECTION}function mb(e){return e!==null&&typeof e=="object"&&"type"in e&&e.type===ce.GET_SELECTION_ACTION_STATE}async function hb(e=document){return Bt(e)!==null?{textSelectionAvailable:!0,selectionEnrichAvailable:await zn(e)!==null}:{textSelectionAvailable:!1,selectionEnrichAvailable:!1}}async function gb(e=document){return{ok:!0,payload:await hb(e)}}function Si(e,t){const r=(t.ownerDocument??document).createRange();try{r.selectNodeContents(t)}catch{return!1}return e.compareBoundaryPoints(Range.END_TO_START,r)<0&&e.compareBoundaryPoints(Range.START_TO_END,r)>0}function vb(e=document){const t=e.getSelection();if(!t||t.rangeCount===0||t.isCollapsed)return null;const n=t.getRangeAt(0);for(const o of[t.anchorNode,t.focusNode]){if(!o)continue;const a=o.nodeType===Node.ELEMENT_NODE?o:o.parentElement,i=Dt(a);if(i&&Si(n,i))return i}let r=n.commonAncestorContainer;for(r.nodeType===Node.TEXT_NODE&&(r=r.parentElement);r instanceof Element;){const o=Dt(r);if(o&&Si(n,o))return o;r=r.parentElement}return null}function Eb(e,t={}){const n=e.trim();if(n.length===0)return null;const r=To(n,t);if(r.length===0)return null;for(const o of Object.values(d)){const a=Mi(n,o);if(!a)continue;const i=r.find(s=>s.type===o&&s.value===a&&s.start===0&&s.end===n.length);return i||{value:a,type:o,start:0,end:n.length,ruleId:Ti(o),sourceTextHint:n}}return[...r].sort((o,a)=>a.value.length-o.value.length)[0]??null}async function zn(e=document){const t=Bt(e);if(!t)return null;const n=vb(e);if(n){const a=at(n);return a?{value:a.value,type:a.type,ruleId:a.ruleId,sourceTextHint:a.sourceTextHint,highlight:n,range:null}:null}const r=await xo(),o=Eb(e.getSelection()?.toString()??"",r.ioc??{});return o?{value:o.value,type:o.type,ruleId:o.ruleId,sourceTextHint:o.sourceTextHint,highlight:null,range:t}:null}function yb(e){if(e.highlight){const t=at(e.highlight);if(t)return t}return{value:e.value,type:e.type,ruleId:e.ruleId,sourceTextHint:e.sourceTextHint,enrichmentState:"empty"}}async function bi(e,t,n=document){return await fl(e,n,{enrichmentTrigger:"none"})?(Or(yb(e),t,n),!0):!1}function Sb(e,t){let n=e.commonAncestorContainer;return n.nodeType===Node.TEXT_NODE&&(n=n.parentElement),n instanceof HTMLElement?n:t.body}async function fl(e,t=document,n={enrichmentTrigger:"manual"}){if(e.highlight){const u=await Lr(()=>Promise.resolve().then(()=>Ii),void 0);if(u.isWorkspaceOpen(t)){const p=at(e.highlight);return p?(u.presentWorkspaceEnrichmentForPayload(p,e.highlight,n,t),!0):!1}return Gn(e.highlight,n,t)}if(!e.range)return!1;const r={value:e.value,type:e.type,ruleId:e.ruleId,sourceTextHint:e.sourceTextHint,enrichmentState:"empty"},o=await Lr(()=>Promise.resolve().then(()=>Ii),void 0);if(o.isWorkspaceOpen(t))return o.presentWorkspaceEnrichmentForPayload(r,Sb(e.range,t),n,t),!0;const{disabledSourceIds:a,enabledSourceIds:i,showDisabledSourcesInWorkspace:s}=await Bn(),l={...r,...a.length>0?{disabledSources:a}:{},enabledEnrichmentSourceIds:i,showDisabledSourcesInWorkspace:s};return gS(e.range,l,t),n.enrichmentTrigger==="manual"?(G(),Yt(l,t,{bypassCache:!0}).catch(R)):ta(l).catch(R),!0}async function oa(e=document){const t=e.getSelection();if(!t||t.rangeCount===0||t.isCollapsed)return{ok:!1,error:"No text selected."};const n=await zn(e);if(!n)return{ok:!1,error:"No indicator found in selection."};const r=await ra(e);if(!r.allowed)return await bi(n,r,e)?{ok:!0,payload:{value:n.value,type:n.type}}:{ok:!1,error:"No indicator found in selection."};const o=await ul(n.value,n.type);return o.allowed?await fl(n,e,{enrichmentTrigger:"manual"})?{ok:!0,payload:{value:n.value,type:n.type}}:{ok:!1,error:"No indicator found in selection."}:await bi(n,o,e)?{ok:!0,payload:{value:n.value,type:n.type}}:{ok:!1,error:"No indicator found in selection."}}function bb(){chrome.runtime.onMessage.addListener((e,t,n)=>mb(e)?(gb().then(n).catch(r=>{_(r)}),!0):fb(e)?(oa().then(n).catch(r=>{_(r)}),!0):!1)}let M=null;function Cb(){return M}function ml(){return M?.running===!0}function Mt(){M?.running&&(M={...M,cancelRequested:!0})}function Ab(){M=null}async function _b(e,t,n){if(e.length===0||M?.running)return{completedCount:0,cancelled:!1};let r=0,o=!1;M={running:!0,cancelRequested:!1,currentIndex:0,totalCount:e.length,currentAnchorId:null},n?.(M);for(let a=0;a<e.length;a+=1){if(M.cancelRequested){o=!0;break}const i=e[a];if(M={...M,currentIndex:a+1,currentAnchorId:i},n?.(M),await t(i),r+=1,M.cancelRequested){o=!0;break}}return M=null,{completedCount:r,cancelled:o}}const Je="vera5-workspace-host",aa=380,hl=44,ia=8,gl="vera5-workspace-open",vl="https://www.vera5.io/",Ib="Run a scan to detect indicators on this page.",Tb="Select an indicator to view details.",Ci="Confirm bulk enrich",xb="Start enrich queue",Lb="Cancel";let c=El();function El(){return{open:!1,collapsed:!1,ready:!1,enabled:!0,highlightEnabled:!0,scanState:"idle",textSelectionAvailable:!1,selectionEnrichAvailable:!1,scanSummary:null,typeFilter:"all",trayFilterReady:!1,trayNavigationMessage:null,trayEnrichmentStatuses:{},trayMultiSelectAnchorIds:{},sessionPinnedIocKeys:[],selectedAnchorId:null,saveToCollectionAnchorId:null,saveToCollectionFeedback:null,saveToCollectionNewName:"",saveToCollectionOptions:[],saveToCollectionLoading:!1,addFilteredToCollectionOpen:!1,addFilteredToCollectionFeedback:null,addFilteredToCollectionNewName:"",addFilteredToCollectionOptions:[],addFilteredToCollectionLoading:!1,selection:null}}function Yn(e=document){return c.open&&e.getElementById(Je)!==null}function Nb(){return c.selection}function yl(e){return e!==null&&typeof e=="object"&&"type"in e&&e.type===ve.TOGGLE_WORKSPACE}function Sl(e){return e!==null&&typeof e=="object"&&"type"in e&&e.type===ve.OPEN_WORKSPACE}function bl(e){const t=e.getElementById(Je);if(t)return t;Ft(e);const n=e.createElement("div");return n.id=Je,n.className="vera5-workspace-host",n.hidden=!0,n.style.setProperty("--vera5-workspace-width",`${aa}px`),n.style.setProperty("--vera5-workspace-gutter",`${ia}px`),e.body.appendChild(n),n}function Cl(){return c.collapsed?hl:aa}function Al(e){const t=e.getElementById(Je);if(!t)return;const n=Cl();t.style.setProperty("--vera5-workspace-width",`${n}px`),t.classList.toggle("vera5-workspace-host--collapsed",c.collapsed),sa(c.open,e)}function sa(e,t){if(t.documentElement.classList.toggle(gl,e),e){const n=Cl();t.documentElement.style.setProperty("--vera5-workspace-width",`${n+ia}px`);return}t.documentElement.style.removeProperty("--vera5-workspace-width")}function yn(e,t){const n=t.querySelector(".vera5-workspace-bottom");if(!(n instanceof HTMLElement))return;Jo(()=>!c.scanSummary||c.scanSummary.entries.length===0?null:{summary:c.scanSummary,filter:c.typeFilter}),n.replaceChildren();const r=ea(e,t,{detailClear:{onClear:()=>{Gb(t)}}});r.classList.add("vera5-workspace-detail-panel"),n.appendChild(r)}function Qe(e){const t=e.querySelector(".vera5-workspace-bottom");if(!(t instanceof HTMLElement))return;t.replaceChildren();const n=e.createElement("p");n.className="vera5-workspace-empty",n.textContent=Tb,t.appendChild(n)}function _l(e,t=document){c.open&&(c.selection&&(c.selection={...c.selection,payload:e}),yn(e,t),y(t))}function Il(e,t,n=document){if(!c.selection||j(c.selection.payload.value)!==j(e))return;const r=n.querySelector(`.vera5-workspace-bottom #${ro}`);if(!r||r.value===t)return;const o=n.activeElement===r,a=r.selectionStart,i=r.selectionEnd;if(r.value=t,c.selection={...c.selection,payload:{...c.selection.payload,analystNotes:t.length>0?t:void 0}},o){r.focus();const s=Math.min(a,t.length);r.setSelectionRange(s,Math.min(i,t.length))}}async function wb(){if(!c.scanSummary||c.scanSummary.entries.length===0){c.trayEnrichmentStatuses={};return}try{c.trayEnrichmentStatuses=await Ug(c.scanSummary.entries)}catch(e){_(e),c.trayEnrichmentStatuses={}}}async function Rb(){try{const{getActiveInvestigationSession:e}=await Lr(async()=>{const{getActiveInvestigationSession:n}=await Promise.resolve().then(()=>Ev);return{getActiveInvestigationSession:n}},void 0),t=await e();c.sessionPinnedIocKeys=t?ev(t):[]}catch(e){_(e),c.sessionPinnedIocKeys=[]}}async function Kn(){await Promise.all([wb(),Rb()])}function Tl(e){if(e===null||typeof e!="object")return null;const t=e;if(!Yu(t.snapshot))return null;const n=typeof t.tabId=="number"?t.tabId:null;return n===null?null:Bg({...t.snapshot,tabId:n})}async function xl(e){if(c.scanState!=="scanning"){try{const[t,n,r]=await Promise.all([Um(),Fm(),Vc()]);if(c.enabled=t,c.highlightEnabled=n,r){c.scanSummary=r,c.scanState="done";const o=await Oc(r.tabId);c.typeFilter=o,c.trayFilterReady=!0}else c.scanState!=="error"&&(c.scanSummary=null,c.scanState="idle",c.typeFilter="all",c.trayFilterReady=!1,c.trayEnrichmentStatuses={})}catch(t){_(t)}finally{c.ready=!0,c.open&&(y(e),c.selection||Qe(e))}c.scanSummary&&c.scanSummary.entries.length>0&&Kn().then(()=>{c.open&&y(e)}).catch(t=>{_(t)})}}function B(e,t,n,r=!1,o=!1){const a=t.createElement("button");return a.type="button",a.className=o?"vera5-workspace-button vera5-workspace-button--primary":"vera5-workspace-button",a.textContent=e,a.disabled=r,a.addEventListener("click",n),a}async function Ob(e,t){c.saveToCollectionAnchorId=e,c.saveToCollectionFeedback=null,c.saveToCollectionNewName="",c.saveToCollectionLoading=!0,c.saveToCollectionOptions=[],y(t),c.saveToCollectionOptions=await zo(),c.saveToCollectionLoading=!1,y(t)}function kb(e,t,n){const r=n.createElement("div");r.className="vera5-tray-save-collection",r.addEventListener("click",p=>{p.stopPropagation()}),r.addEventListener("keydown",p=>{p.stopPropagation()});const o=c.saveToCollectionAnchorId===t.anchorId,a=n.createElement("button");if(a.type="button",a.className="vera5-tray-save-collection-toggle",a.textContent=uc,a.setAttribute("aria-expanded",o?"true":"false"),a.addEventListener("click",()=>{if(o){c.saveToCollectionAnchorId=null,c.saveToCollectionFeedback=null,y(n);return}Ob(t.anchorId,n)}),r.appendChild(a),!o){e.appendChild(r);return}const i=n.createElement("div");i.className="vera5-tray-save-collection-panel",i.setAttribute("role","group"),i.setAttribute("aria-label",St);const s=n.createElement("p");if(s.className="vera5-tray-save-collection-heading",s.textContent=St,i.appendChild(s),c.saveToCollectionLoading){const p=n.createElement("p");p.className="vera5-workspace-empty",p.textContent="Loading collections…",i.appendChild(p)}else if(c.saveToCollectionOptions.length===0){const p=n.createElement("p");p.className="vera5-workspace-empty",p.textContent=Po,i.appendChild(p)}else{const p=n.createElement("div");p.className="vera5-tray-save-collection-list";for(const f of c.saveToCollectionOptions)p.appendChild(B(f.name,n,()=>{(async()=>{const h=await pn({collectionId:f.id,member:{iocType:t.type,value:t.value}});c.saveToCollectionFeedback=h?cn({collectionName:h.collection.name,added:h.added}):"Could not save to collection.",y(n)})()}));i.appendChild(p)}const l=n.createElement("label");l.className="vera5-workspace-field-label",l.textContent=Do;const u=n.createElement("input");if(u.type="text",u.value=c.saveToCollectionNewName,u.placeholder=qe,u.setAttribute("aria-label",qe),u.addEventListener("input",()=>{c.saveToCollectionNewName=u.value,y(n)}),l.appendChild(u),i.appendChild(l),i.appendChild(B(Mo,n,()=>{(async()=>{const p=await Yo({name:c.saveToCollectionNewName});if(!p){c.saveToCollectionFeedback="Could not create collection.",y(n);return}const f=await pn({collectionId:p.id,member:{iocType:t.type,value:t.value}});if(!f){c.saveToCollectionFeedback="Collection created, but indicator was not saved.",y(n);return}c.saveToCollectionOptions=[f.collection,...c.saveToCollectionOptions.filter(h=>h.id!==f.collection.id)],c.saveToCollectionNewName="",c.saveToCollectionFeedback=cn({collectionName:f.collection.name,added:f.added}),y(n)})()},kn(c.saveToCollectionNewName)===null)),c.saveToCollectionFeedback){const p=n.createElement("p");p.className="vera5-tray-save-collection-feedback",p.setAttribute("aria-live","polite"),p.textContent=c.saveToCollectionFeedback,i.appendChild(p)}r.appendChild(i),e.appendChild(r)}async function Db(e){c.addFilteredToCollectionOpen=!0,c.addFilteredToCollectionFeedback=null,c.addFilteredToCollectionNewName="",c.addFilteredToCollectionLoading=!0,c.addFilteredToCollectionOptions=[],y(e),c.addFilteredToCollectionOptions=await zo(),c.addFilteredToCollectionLoading=!1,y(e)}function Mb(e,t,n){const r=n.createElement("div");r.className="vera5-tray-save-collection",r.addEventListener("click",f=>{f.stopPropagation()}),r.addEventListener("keydown",f=>{f.stopPropagation()});const o=t.map(f=>({iocType:f.type,value:f.value})),a=c.addFilteredToCollectionOpen,i=n.createElement("button");if(i.type="button",i.className="vera5-tray-save-collection-toggle",i.textContent=wg(t.length),i.setAttribute("aria-expanded",a?"true":"false"),i.disabled=t.length===0,i.addEventListener("click",()=>{if(a){c.addFilteredToCollectionOpen=!1,c.addFilteredToCollectionFeedback=null,y(n);return}Db(n)}),r.appendChild(i),!a){e.appendChild(r);return}const s=n.createElement("div");s.className="vera5-tray-save-collection-panel",s.setAttribute("role","group"),s.setAttribute("aria-label",za);const l=n.createElement("p");if(l.className="vera5-tray-save-collection-heading",l.textContent=za,s.appendChild(l),c.addFilteredToCollectionLoading){const f=n.createElement("p");f.className="vera5-workspace-empty",f.textContent="Loading collections…",s.appendChild(f)}else if(c.addFilteredToCollectionOptions.length===0){const f=n.createElement("p");f.className="vera5-workspace-empty",f.textContent=Po,s.appendChild(f)}else{const f=n.createElement("div");f.className="vera5-tray-save-collection-list";for(const h of c.addFilteredToCollectionOptions)f.appendChild(B(h.name,n,()=>{(async()=>{const E=await oi({collectionId:h.id,members:o});c.addFilteredToCollectionFeedback=E?Ya({collectionName:E.collection.name,addedCount:E.addedCount,duplicateCount:E.duplicateCount,totalCount:E.totalCount}):"Could not add filtered indicators to collection.",y(n)})()}));s.appendChild(f)}const u=n.createElement("label");u.className="vera5-workspace-field-label",u.textContent=Do;const p=n.createElement("input");if(p.type="text",p.value=c.addFilteredToCollectionNewName,p.placeholder=qe,p.setAttribute("aria-label",qe),p.addEventListener("input",()=>{c.addFilteredToCollectionNewName=p.value,y(n)}),u.appendChild(p),s.appendChild(u),s.appendChild(B(Mo,n,()=>{(async()=>{const f=await Yo({name:c.addFilteredToCollectionNewName});if(!f){c.addFilteredToCollectionFeedback="Could not create collection.",y(n);return}const h=await oi({collectionId:f.id,members:o});if(!h){c.addFilteredToCollectionFeedback="Collection created, but filtered indicators were not saved.",y(n);return}c.addFilteredToCollectionOptions=[h.collection,...c.addFilteredToCollectionOptions.filter(E=>E.id!==h.collection.id)],c.addFilteredToCollectionNewName="",c.addFilteredToCollectionFeedback=Ya({collectionName:h.collection.name,addedCount:h.addedCount,duplicateCount:h.duplicateCount,totalCount:h.totalCount}),y(n)})()},kn(c.addFilteredToCollectionNewName)===null)),c.addFilteredToCollectionFeedback){const f=n.createElement("p");f.className="vera5-tray-save-collection-feedback",f.setAttribute("aria-live","polite"),f.textContent=c.addFilteredToCollectionFeedback,s.appendChild(f)}r.appendChild(s),e.appendChild(r)}function Pb(e,t,n,r=!1,o=""){const a=t.createElement("button");return a.type="button",a.className=`vera5-workspace-icon-button${o?` ${o}`:""}`,a.textContent="↻",a.setAttribute("aria-label",e),a.disabled=r,a.addEventListener("click",n),a}function Ai(e,t,n,r,o){const a=r.createElement("button");a.type="button",a.className="vera5-workspace-toggle",t&&a.classList.add("vera5-workspace-toggle--on"),a.setAttribute("role","switch"),a.setAttribute("aria-checked",t?"true":"false"),a.setAttribute("aria-label",e),a.disabled=n;const i=r.createElement("span");i.className="vera5-workspace-toggle-label",i.textContent=e;const s=r.createElement("span");s.className="vera5-workspace-toggle-switch",s.setAttribute("aria-hidden","true");const l=r.createElement("span");return l.className="vera5-workspace-toggle-knob",s.appendChild(l),a.append(i,s),a.addEventListener("click",()=>{a.disabled||o(!t)}),a}function _i(e,t,n,r){const o=n.createElement("button");return o.type="button",o.className="vera5-workspace-filter-chip",o.textContent=e,o.setAttribute("aria-pressed",t?"true":"false"),o.addEventListener("click",r),o}function Hb(e){return e==="Live"?"vera5-workspace-tray-hint vera5-workspace-tray-hint--live":e==="Error"?"vera5-workspace-tray-hint vera5-workspace-tray-hint--error":"vera5-workspace-tray-hint"}async function Ub(e){if(c.enabled){c.scanState="scanning",c.typeFilter="all",c.trayFilterReady=!1,c.trayNavigationMessage=null,c.trayEnrichmentStatuses={},y(e);try{const t=await $t();if(!t.ok){c.scanState="error";return}const n=Tl(t.payload)??await jo();if(!n){c.scanState="error";return}c.scanSummary=n,c.scanState="done",c.typeFilter="all",c.trayFilterReady=!0,dn(n.tabId,"all").catch(r=>{_(r)}),Kn().then(()=>{c.open&&c.scanState==="done"&&y(e)}).catch(r=>{_(r)})}catch(t){_(t),c.scanState="error"}finally{c.scanState==="scanning"&&(c.scanState="error"),c.open&&y(e)}}}async function Vb(e){if(c.enabled){c.scanState="scanning",c.typeFilter="all",c.trayFilterReady=!1,c.trayNavigationMessage=null,c.trayEnrichmentStatuses={},y(e);try{const t=await js();if(!t.ok){c.scanState="error";return}const n=Tl(t.payload)??await jo();if(!n){c.scanState="error";return}c.scanSummary=n,c.scanState="done",c.typeFilter="all",c.trayFilterReady=!0,dn(n.tabId,"all").catch(r=>{_(r)}),Kn().then(()=>{c.open&&c.scanState==="done"&&y(e)}).catch(r=>{_(r)})}catch(t){_(t),c.scanState="error"}finally{c.scanState==="scanning"&&(c.scanState="error"),c.open&&y(e)}}}function Fb(e){const t=Bt(e)!==null,n=t!==c.textSelectionAvailable;n&&(c.textSelectionAvailable=t),zn(e).then(r=>{const o=r!==null;o===c.selectionEnrichAvailable&&!n||(c.selectionEnrichAvailable=o,c.open&&y(e))}).catch(r=>{_(r)}),n&&c.open&&y(e)}async function Bb(e){if(c.enabled)try{await oa(e)}catch(t){_(t)}}function $b(e){c.scanState!=="scanning"&&(c.scanSummary=null,c.scanState="idle",c.typeFilter="all",c.trayFilterReady=!1,c.trayNavigationMessage=null,c.trayEnrichmentStatuses={},c.trayMultiSelectAnchorIds={},Mt(),c.selection&&(G(),c.selection=null,c.selectedAnchorId=null,$n(),ot({open:!0,selectedAnchorId:null,payloadValue:null}),Jo(null),Qe(e)),y(e))}function Gb(e){if(!c.selection){Qe(e);return}G(),c.selection=null,c.selectedAnchorId=null,$n(),ot({open:!0,selectedAnchorId:null,payloadValue:null}),Qe(e),y(e)}function zb(e){c.collapsed=!c.collapsed,Al(e);const t=e.querySelector(".vera5-workspace-sidebar");t instanceof HTMLElement&&t.classList.toggle("vera5-workspace-sidebar--collapsed",c.collapsed);const n=e.querySelector(".vera5-workspace-edge-tab");n instanceof HTMLButtonElement&&(n.textContent=c.collapsed?"«":"»",n.setAttribute("aria-label",c.collapsed?"Expand workspace":"Collapse workspace"))}function Yb(e,t={},n=document){const r=at(e);return r?(ca(r,e,t,n,e.dataset.vera5AnchorId??null),!0):!1}function ca(e,t,n={},r=document,o=t.dataset.vera5AnchorId??null){c.selectedAnchorId=o,c.trayNavigationMessage=null,(i=>{c.selection={highlight:t,payload:i},ot({open:!0,selectedAnchorId:c.selectedAnchorId,payloadValue:i.value}),yn(i,r),y(r)})(e),!D()&&Bn().then(({disabledSourceIds:i,enabledSourceIds:s,showDisabledSourcesInWorkspace:l})=>{const u={...e,...i.length>0?{disabledSources:i}:{},enabledEnrichmentSourceIds:s,showDisabledSourcesInWorkspace:l};c.selection?.highlight===t&&c.selectedAnchorId===o&&(c.selection={highlight:t,payload:u},yn(u,r)),n.enrichmentTrigger==="manual"?(G(),Yt(u,r,{bypassCache:!0}).catch(p=>{_(p)})):n.enrichmentTrigger!=="none"&&ta(u).catch(p=>{_(p)})}).catch(i=>{_(i)})}function la(e,t=document){const n=t.querySelector(`[data-vera5-anchor-id="${CSS.escape(e)}"]`);return n?(n.scrollIntoView({block:"center",inline:"nearest",behavior:"smooth"}),Yb(n,{enrichmentTrigger:"auto"},t)):(c.trayNavigationMessage="This indicator is no longer on the page. Scan again to refresh the list.",y(t),!1)}function Kb(e,t){t?c.trayMultiSelectAnchorIds[e]=!0:delete c.trayMultiSelectAnchorIds[e]}function Wb(){const e=c.scanSummary;return e?ke(e.entries,c.typeFilter).map(n=>n.anchorId).filter(n=>c.trayMultiSelectAnchorIds[n]):[]}async function jb(e,t){const n=t.querySelector(`[data-vera5-anchor-id="${CSS.escape(e)}"]`);if(!n){c.trayNavigationMessage="This indicator is no longer on the page. Scan again to refresh the list.",y(t);return}const r=at(n);if(!r)return;n.scrollIntoView({block:"center",inline:"nearest",behavior:"smooth"});const{disabledSourceIds:o,enabledSourceIds:a,showDisabledSourcesInWorkspace:i}=await Bn(),s={...r,...o.length>0?{disabledSources:o}:{},enabledEnrichmentSourceIds:a,showDisabledSourcesInWorkspace:i};ca(r,n,{enrichmentTrigger:"none"},t,e),G(),await Yt(s,t,{bypassCache:!0})==="cancelled"&&Mt()}function qb(e,t){return Ft(t),new Promise(n=>{const r=t.createElement("div");r.className="vera5-tray-enrich-queue-warning-backdrop";const o=t.createElement("div");o.className="vera5-tray-enrich-queue-warning-panel",o.setAttribute("role","dialog"),o.setAttribute("aria-modal","true"),o.setAttribute("aria-label",Ci);const a=t.createElement("h3");a.className="vera5-tray-enrich-queue-warning-heading",a.textContent=Ci;const i=t.createElement("p");i.className="vera5-tray-enrich-queue-warning-message",i.setAttribute("role","note"),i.textContent=e;const s=t.createElement("div");s.className="vera5-tray-enrich-queue-warning-actions";const l=f=>{r.remove(),n(f)},u=B(xb,t,()=>{l(!0)}),p=B(Lb,t,()=>{l(!1)});s.append(u,p),o.append(a,i,s),r.appendChild(o),r.addEventListener("click",f=>{f.target===r&&l(!1)}),t.body.appendChild(r),u.focus()})}async function Xb(e,t){if(ml()||e.length===0)return;const n=c.scanSummary;if(!n)return;if(!(await ra(t)).allowed){c.trayNavigationMessage=ll,y(t);return}const o=ke(n.entries,c.typeFilter),a=await na(),i=kS(o,e,a);if(await qb(DS(i),t)){c.trayNavigationMessage=null;try{await _b(e,l=>jb(l,t),()=>{c.open&&y(t)})}catch(l){_(l)}finally{await Kn(),c.open&&y(t)}}}function y(e){const t=e.querySelector(".vera5-workspace-top");if(!(t instanceof HTMLElement))return;t.replaceChildren();const n=e.createElement("div");n.className="vera5-workspace-controls";const r=e.createElement("div");if(r.className="vera5-workspace-toggle-row",r.appendChild(Ai("Extension enabled",c.enabled,!c.ready,e,m=>{c.enabled=m,Vm(m),m||(c.scanState="idle",c.scanSummary=null,c.typeFilter="all",c.trayFilterReady=!1,c.trayNavigationMessage=null,c.trayEnrichmentStatuses={},c.trayMultiSelectAnchorIds={},Mt(),c.selection=null,c.selectedAnchorId=null,Qe(e)),y(e)})),r.appendChild(Ai("Highlight indicators",c.highlightEnabled,!c.ready||!c.enabled,e,m=>{c.highlightEnabled=m,Bm(m),y(e)})),n.appendChild(r),n.appendChild(B(c.scanState==="scanning"?"Scanning…":"Scan page",e,()=>{Ub(e).catch(m=>{_(m)})},!c.ready||!c.enabled||c.scanState==="scanning",!0)),n.appendChild(B(c.scanState==="scanning"?"Scanning…":"Scan selection",e,()=>{Vb(e).catch(m=>{_(m)})},!c.ready||!c.enabled||c.scanState==="scanning"||!c.textSelectionAvailable)),n.appendChild(B("Enrich selection",e,()=>{Bb(e).catch(m=>{_(m)})},!c.ready||!c.enabled||!c.selectionEnrichAvailable)),n.appendChild(B("Settings",e,()=>{q(Pi())},!c.ready)),n.appendChild(B("Permissions",e,()=>{CS()},!c.ready)),c.scanState==="error"){const m=e.createElement("p");m.className="vera5-workspace-error",m.textContent="Scan failed. Reload the tab and try again.",n.appendChild(m)}t.appendChild(n);const o=AS({enabled:c.enabled,scanState:c.scanState,scanSummary:c.scanSummary});if(!o)return;const a=e.createElement("div");a.className="vera5-workspace-tray-heading-row";const i=e.createElement("h2");i.className="vera5-workspace-tray-heading",i.textContent="Detected indicators";const s=Pb("Clear detected indicators",e,()=>{$b(e)},!c.ready||!c.enabled||c.scanState==="scanning");if(a.append(i,s),t.appendChild(a),o==="prompt"){const m=e.createElement("p");m.className="vera5-workspace-empty",m.textContent=Ib,t.appendChild(m);return}if(o==="scanning"){const m=e.createElement("p");m.className="vera5-workspace-empty",m.setAttribute("aria-live","polite"),m.textContent="Scanning page…",t.appendChild(m);return}if(o==="empty"){const m=e.createElement("p");m.className="vera5-workspace-empty",m.setAttribute("aria-live","polite"),m.textContent="No indicators detected on this page.",t.appendChild(m);return}const l=c.scanSummary;if(!l)return;const u=e.createElement("p");u.className="vera5-workspace-tray-summary",u.textContent=Dg(l),t.appendChild(u);const p=e.createElement("div");p.className="vera5-workspace-filter-row",p.setAttribute("role","group"),p.setAttribute("aria-label","Filter by indicator type"),p.appendChild(_i(`All (${l.totalCount})`,c.typeFilter==="all",e,()=>{c.typeFilter="all",c.trayFilterReady&&c.scanSummary&&dn(c.scanSummary.tabId,"all"),y(e)}));for(const m of pc(l))p.appendChild(_i(`${yr[m]} (${l.countByType[m]??0})`,c.typeFilter===m,e,()=>{c.typeFilter=m,c.trayFilterReady&&c.scanSummary&&dn(c.scanSummary.tabId,m),y(e)}));t.appendChild(p);const f=tv(ke(l.entries,c.typeFilter),c.sessionPinnedIocKeys),h=Wb(),E=ml(),S=Cb(),L=e.createElement("div");if(L.className="vera5-workspace-tray-bulk-row",L.appendChild(B(`Enrich selected (${h.length})`,e,()=>{Xb(h,e).catch(m=>{_(m)})},!c.ready||!c.enabled||h.length===0||E)),E&&L.appendChild(B("Cancel enrich queue",e,()=>{Mt(),G(),y(e)},!1)),t.appendChild(L),Mb(L,f,e),E&&S){const m=e.createElement("p");m.className="vera5-workspace-tray-queue-status",m.setAttribute("aria-live","polite"),m.textContent=`Enriching ${S.currentIndex} of ${S.totalCount}…`,t.appendChild(m)}if(c.trayNavigationMessage){const m=e.createElement("p");m.className="vera5-workspace-error",m.setAttribute("role","alert"),m.setAttribute("aria-live","polite"),m.textContent=c.trayNavigationMessage,t.appendChild(m)}if(f.length===0){const m=e.createElement("p");m.className="vera5-workspace-empty",m.textContent="No indicators match this filter.",t.appendChild(m);return}const z=e.createElement("ul");z.className="vera5-workspace-tray-list";for(const m of f){const V=c.trayEnrichmentStatuses[m.anchorId],X=Fg(m),A=e.createElement("li");A.className="vera5-workspace-tray-row",A.dataset.vera5TrayEntry="true",A.dataset.vera5Type=m.type,A.dataset.vera5Value=m.value,A.dataset.vera5AnchorId=m.anchorId,X&&(A.dataset.vera5RuleId=X.ruleId,A.dataset.vera5SourceTextHint=X.sourceTextHint),m.displayValue&&(A.dataset.vera5DisplayValue=m.displayValue),A.tabIndex=0,A.setAttribute("role","button"),A.setAttribute("aria-label",Hg(m.value,V)),A.setAttribute("aria-selected",c.selectedAnchorId===m.anchorId?"true":"false"),A.classList.toggle("vera5-workspace-tray-row--bulk-selected",!!c.trayMultiSelectAnchorIds[m.anchorId]),A.classList.toggle("vera5-workspace-tray-row--pinned",c.sessionPinnedIocKeys.includes(re(m.value)));const N=e.createElement("input");N.type="checkbox",N.className="vera5-workspace-tray-select",N.checked=!!c.trayMultiSelectAnchorIds[m.anchorId],N.disabled=E,N.setAttribute("aria-label",`Select ${m.value} for bulk enrich`),N.addEventListener("click",C=>{C.stopPropagation()}),N.addEventListener("change",()=>{Kb(m.anchorId,N.checked),y(e)});const J=()=>{la(m.anchorId,e)};A.addEventListener("click",J),A.addEventListener("keydown",C=>{C.key!=="Enter"&&C.key!==" "||(C.preventDefault(),J())});const Ee=e.createElement("span");Ee.className="vera5-workspace-tray-type",Ee.setAttribute("aria-hidden","true"),Ee.textContent=yr[m.type];const ye=so({value:m.value,displayValue:m.displayValue}),Se=e.createElement("span");if(Se.className="vera5-workspace-tray-value",ye.showRefangedPair){const C=e.createElement("span");C.className="vera5-workspace-tray-value-on-page",C.textContent=ye.onPageValue;const ae=e.createElement("span");ae.className="vera5-workspace-tray-refanged-value",ae.textContent=`${as} ${ye.refangedValue}`,Se.append(C,ae)}else Se.textContent=ye.refangedValue;const ue=e.createElement("div");if(ue.className="vera5-workspace-tray-row-main",c.sessionPinnedIocKeys.includes(re(m.value))){const C=e.createElement("span");C.className="vera5-workspace-tray-pin",C.textContent="★",C.setAttribute("aria-label","Pinned for triage"),ue.appendChild(C)}if(ue.append(N,Ee,Se),V){const C=e.createElement("span");C.className=Hb(V.badgeText),C.setAttribute("aria-hidden","true"),C.textContent=fc(V),ue.appendChild(C)}A.appendChild(ue),kb(A,m,e);const it=os({type:m.type,ruleId:m.ruleId,sourceTextHint:m.sourceTextHint,ignoredOverlaps:m.ignoredOverlaps});if(it){const C=e.createElement("details");C.className=qc,C.addEventListener("click",be=>{be.stopPropagation()}),C.addEventListener("keydown",be=>{be.stopPropagation()});const ae=e.createElement("summary");ae.textContent=rs,C.appendChild(ae),C.appendChild(rl(it,e,{compact:!0,omitHeading:!0})),A.appendChild(C)}z.appendChild(A)}t.appendChild(z)}function Jb(e){const t=bl(e);t.replaceChildren();const n=e.createElement("div");n.className="vera5-workspace-shell";const r=e.createElement("button");r.type="button",r.className="vera5-workspace-edge-tab",r.textContent=c.collapsed?"«":"»",r.setAttribute("aria-label",c.collapsed?"Expand workspace":"Collapse workspace"),r.addEventListener("click",()=>{zb(e)});const o=e.createElement("div");o.className="vera5-workspace-sidebar",c.collapsed&&o.classList.add("vera5-workspace-sidebar--collapsed"),o.setAttribute("role","complementary"),o.setAttribute("aria-label","Vera5 workspace");const a=e.createElement("div");a.className="vera5-workspace-header";const i=e.createElement("a");i.className="vera5-workspace-title",i.href=vl,i.target="_blank",i.rel="noopener noreferrer";const s=e.createElement("span");s.className="vera5-workspace-title-5",s.textContent="5";const l="http://www.w3.org/2000/svg",u=e.createElementNS(l,"svg");u.setAttribute("class","vera5-workspace-title-mark"),u.setAttribute("viewBox","0 0 1197 1178"),u.setAttribute("fill","none"),u.setAttribute("aria-hidden","true");const p=[{tag:"line",attrs:{x1:"7.5",y1:"-7.5",x2:"438.506",y2:"-7.5",transform:"matrix(-0.999985 -0.00550504 0.00392659 -0.999992 833.294 307.353)",stroke:"#FFB224","stroke-width":"15","stroke-linecap":"round"}},{tag:"line",attrs:{x1:"387.294",y1:"251.583",x2:"830.294",y2:"251.583",stroke:"#FFB224","stroke-width":"15"}},{tag:"path",attrs:{d:"M586.763 776.721L585.966 777.324L4.29366 8.68633L5.09106 8.08289L586.763 776.721Z",fill:"#FFB224"}},{tag:"path",attrs:{d:"M596.09 778.804L595.299 778.192L1193.29 4.08288L1194.09 4.69421L596.09 778.804Z",fill:"#FFB224"}},{tag:"line",attrs:{x1:"394.794",y1:"247.083",x2:"394.794",y2:"319.083",stroke:"#FFB224","stroke-width":"15"}},{tag:"path",attrs:{d:"M828.797 317.442L598.768 528.083",stroke:"#FFB224","stroke-width":"15","stroke-linecap":"round"}},{tag:"path",attrs:{d:"M593.757 528.083L400.323 345.328",stroke:"#FFB224","stroke-width":"15","stroke-linecap":"round"}},{tag:"path",attrs:{d:"M494.198 363.761L707.501 366.692L599.831 469.234L494.198 363.761Z",fill:"#262D36",stroke:"#FFB224","stroke-width":"15"}},{tag:"path",attrs:{d:"M587.794 590.583L585.794 775.583L20.2936 28.0829L587.794 590.583Z",fill:"#262D36",stroke:"#13171C","stroke-width":"12"}},{tag:"path",attrs:{d:"M1173.29 31.5829L587.794 1164.08L23.2936 33.5829L584.294 775.083L586.794 780.083H594.794L1173.29 31.5829Z",fill:"#1A2027",stroke:"#13171C"}},{tag:"path",attrs:{d:"M596.784 585.461C598.745 587.406 598.758 590.571 596.814 592.532C594.87 594.493 591.704 594.506 589.743 592.562L1.84403 9.60348C-0.116813 7.65911 -0.130171 4.49332 1.81419 2.53248C3.75856 0.571633 6.92435 0.558275 8.8852 2.50264L596.784 585.461Z",fill:"#FFB224"}},{tag:"path",attrs:{d:"M591.005 1170.14C592.239 1172.61 591.237 1175.61 588.767 1176.85C586.296 1178.08 583.293 1177.08 582.059 1174.61L0.528187 10.5558C-0.705917 8.08547 0.296229 5.08245 2.76654 3.84834C5.23686 2.61424 8.23988 3.61638 9.47398 6.0867L591.005 1170.14Z",fill:"#FFB224"}},{tag:"path",attrs:{d:"M598.794 590.583L597.298 775.078L1174.79 28.0829L598.794 590.583Z",fill:"#262D36"}},{tag:"path",attrs:{d:"M597.294 775.583L598.794 590.583L1174.79 28.0829L597.294 775.083",stroke:"#13171C","stroke-width":"12"}},{tag:"path",attrs:{d:"M1187.73 1.42334C1189.7 -0.506288 1192.87 -0.469239 1194.8 1.5061C1196.73 3.48145 1196.69 6.64706 1194.72 8.57669L596.87 592.589C594.895 594.519 591.729 594.482 589.8 592.506C587.87 590.531 587.907 587.365 589.882 585.436L1187.73 1.42334Z",fill:"#FFB224"}},{tag:"path",attrs:{d:"M1187.11 4.9312C1188.38 2.47845 1191.4 1.51793 1193.85 2.78614C1196.31 4.05435 1197.27 7.07105 1196 9.52399L593.59 1174.64C592.322 1177.09 589.305 1178.05 586.852 1176.79C584.399 1175.52 583.439 1172.5 584.707 1170.05L1187.11 4.9312Z",fill:"#FFB224"}},{tag:"path",attrs:{d:"M593.346 1166.93L583.346 1166.85L588.294 584.04L598.293 584.125L593.346 1166.93Z",fill:"#FFB224"}}];for(const L of p){const z=e.createElementNS(l,L.tag);for(const[m,V]of Object.entries(L.attrs))z.setAttribute(m,V);u.appendChild(z)}i.append(u,"Vera",s);const f=e.createElement("button");f.type="button",f.className="vera5-workspace-close",f.textContent="×",f.setAttribute("aria-label","Close Vera5 workspace"),f.addEventListener("click",()=>{da(e)}),a.append(i,f);const h=e.createElement("div");h.className="vera5-workspace-top";const E=e.createElement("hr");E.className="vera5-workspace-divider",E.setAttribute("aria-hidden","true");const S=e.createElement("div");S.className="vera5-workspace-bottom",o.append(a,h,E,S),n.append(r,o),t.appendChild(n),Al(e),y(e),c.selection?yn(c.selection.payload,e):Qe(e)}function ua(e=document){c.open=!0,c.textSelectionAvailable=Bt(e)!==null,zn(e).then(n=>{c.selectionEnrichAvailable=n!==null,c.open&&y(e)}).catch(n=>{_(n)}),ot({open:!0,selectedAnchorId:c.selectedAnchorId,payloadValue:c.selection?.payload.value??null});const t=bl(e);t.hidden=!1,sa(!0,e),Jb(e),xl(e).catch(n=>{_(n)})}function da(e=document){c.open=!1,c.selection=null,c.selectedAnchorId=null,Jo(null),$n(),ot({open:!1,selectedAnchorId:null,payloadValue:null}),G();const t=e.getElementById(Je);t&&(t.hidden=!0,t.replaceChildren()),sa(!1,e)}function Ll(e=document){if(Yn(e)){da(e);return}ua(e)}let kr=!1,Dr=!1;function Nl(e=document){QS((t,n)=>{_l(t,n)}),e.addEventListener("selectionchange",()=>{Fb(e)}),typeof chrome<"u"&&chrome.runtime?.onMessage&&!kr&&(kr=!0,chrome.runtime.onMessage.addListener((t,n,r)=>{if(yl(t)){try{Ll(e),r({ok:!0,payload:{open:Yn(e)}})}catch(o){R(o)}return!0}if(Sl(t)){try{ua(e),r({ok:!0,payload:{open:!0}})}catch(o){R(o)}return!0}return!1})),!(typeof chrome>"u"||!chrome.storage?.onChanged||Dr)&&(Dr=!0,chrome.storage.onChanged.addListener((t,n)=>{if(n!=="session"||!c.open)return;Object.keys(t).some(o=>o.startsWith("tabScanSnapshot:"))&&xl(e).catch(o=>{_(o)})}))}function Qb(){Mt(),Ab(),c=El(),kr=!1,Dr=!1,$n(),ot({open:!1,selectedAnchorId:null,payloadValue:null})}const Ii=Object.freeze(Object.defineProperty({__proto__:null,VERA5_WEBSITE_URL:vl,WORKSPACE_COLLAPSED_WIDTH_PX:hl,WORKSPACE_HOST_GUTTER_PX:ia,WORKSPACE_HOST_ID:Je,WORKSPACE_HTML_CLASS:gl,WORKSPACE_WIDTH_PX:aa,activateWorkspaceIndicatorByAnchorId:la,closeWorkspace:da,getWorkspaceSelection:Nb,isOpenWorkspaceMessage:Sl,isToggleWorkspaceMessage:yl,isWorkspaceOpen:Yn,openWorkspace:ua,presentWorkspaceEnrichmentForPayload:ca,resetWorkspaceSidebarForTests:Qb,setupWorkspaceSidebarListener:Nl,toggleWorkspace:Ll,updateWorkspaceAnalystNoteIfOpen:Il,updateWorkspaceDetailPanel:_l},Symbol.toStringTag,{value:"Module"}));async function Zb(){await gd()}function eC(){chrome.storage.onChanged.addListener((e,t)=>{Cn(()=>{if(t!=="local")return;const n=e[At];if(!n)return;const r=sr(n.oldValue),o=sr(n.newValue),a=new Set([...Object.keys(r),...Object.keys(o)]);for(const i of a){const s=r[i]??"",l=o[i]??"";if(s===l)continue;const u=It(i);Wi(i,l),u!==l&&(vS(i,l),Il(i,l))}})})}async function tC(){await ng()}function nC(){chrome.storage.onChanged.addListener((e,t)=>{Cn(()=>{if(t!=="local")return;const n=e[Nt];if(!n)return;const r=vr(n.oldValue),o=vr(n.newValue),a=new Set([...Object.keys(r),...Object.keys(o)]);for(const i of a){const s=r[i]??null,l=o[i]??null;if(s===l)continue;const u=on(i);sc(i,l),u!==l&&ES(i,l)}})})}const pa=new Map;function Pe(e){pa.set(e.id,e)}function rC(){return[...pa.values()].sort((e,t)=>e.label.localeCompare(t.label))}function oC(e,t){if(t.length===0)return!0;const n=[e.id,e.label,e.description??"",...e.keywords??[]].join(" ").toLowerCase();return t.split(/\s+/).filter(Boolean).every(r=>n.includes(r))}function aC(e){const t=e.trim().toLowerCase();return rC().filter(n=>n.isEnabled&&!n.isEnabled()?!1:oC(n,t))}async function iC(e){const t=pa.get(e);return!t||t.isEnabled&&!t.isEnabled()?!1:(await t.run(),!0)}const He={SCAN_PAGE:"scan-page",ENRICH_SELECTION:"enrich-selection",COPY_FILTERED_MARKDOWN:"copy-filtered-markdown",EXPORT_TRAY_SUBSET:"export-tray-subset",CLEAR_HIGHLIGHTS:"clear-highlights",OPEN_OPTIONS:"open-options"};function sC(e=document){const t=e.getSelection();return!!(t&&t.rangeCount>0&&!t.isCollapsed)}function cC(){Pe({id:He.SCAN_PAGE,label:"Scan page",description:"Detect indicators in visible page text",keywords:["detect","ioc","scan"],run:()=>{$t()}}),Pe({id:He.ENRICH_SELECTION,label:"Enrich selection",description:"Look up the indicator in the current text selection",keywords:["enrich","ioc","lookup","selection"],isEnabled:()=>sC(),run:()=>{oa()}}),Pe({id:He.COPY_FILTERED_MARKDOWN,label:"Copy filtered Markdown",description:"Copy filtered tray indicators as Markdown",keywords:["clipboard","copy","markdown","tray"],run:async()=>{const e=await fi();e.length!==0&&(await fo("markdown-report",e),un({iocs:e.map(t=>({value:t.value,type:t.type}))}))}}),Pe({id:He.EXPORT_TRAY_SUBSET,label:"Export tray subset",description:"Download filtered tray indicators as Markdown",keywords:["download","export","markdown","tray"],run:async()=>{const e=await fi();e.length!==0&&(po("markdown-report",e),un({iocs:e.map(t=>({value:t.value,type:t.type}))}))}}),Pe({id:He.CLEAR_HIGHLIGHTS,label:"Clear highlights",description:"Remove all indicator highlights on this page",keywords:["clear","highlight","reset"],run:()=>{On(document.body)}}),Pe({id:He.OPEN_OPTIONS,label:"Open options",description:"Open extension settings",keywords:["options","preferences","settings"],run:()=>{Ui()}})}const wl="vera5-command-palette-host",lC="vera5-command-palette-backdrop",uC="vera5-command-palette-panel",Rl="vera5-command-palette-input",Ol="vera5-command-palette-list",dC="vera5-command-palette-item",pC="vera5-command-palette-item--selected",kl="vera5-command-palette-empty",fC="vera5-command-palette-hint",mC="Vera5 command palette",hC="Filter commands",gC="No matching commands.",vC="Type to filter · Enter to run · Esc to close · ↑↓ to navigate";let w={open:!1,query:"",selectedIndex:0},vt=null;function fa(e){return aC(e)}function Mr(e,t){return t<=0?0:e<0?t-1:e>=t?0:e}function Kt(e){return e.getElementById(wl)}function EC(e){return Kt(e)?.querySelector(`.${Rl}`)??null}function Sn(e){const t=Kt(e);if(!t)return;const n=t.querySelector(`.${Ol}`),r=t.querySelector(`.${kl}`);if(!n||!r)return;const o=fa(w.query);if(w.selectedIndex=Mr(w.selectedIndex,o.length),n.replaceChildren(),o.length===0){r.textContent=gC,r.hidden=!1;return}r.hidden=!0,o.forEach((a,i)=>{const s=e.createElement("button");s.type="button",s.className=dC,s.dataset.commandId=a.id,s.setAttribute("role","option"),s.setAttribute("aria-selected",i===w.selectedIndex?"true":"false"),i===w.selectedIndex&&s.classList.add(pC);const l=e.createElement("span");if(l.className="vera5-command-palette-item-label",l.textContent=a.label,s.appendChild(l),a.description){const u=e.createElement("span");u.className="vera5-command-palette-item-description",u.textContent=a.description,s.appendChild(u)}s.addEventListener("click",()=>{w.selectedIndex=i,Dl(e)}),n.appendChild(s)})}function yC(e){Ft(e);let t=Kt(e);if(t)return t;t=e.createElement("div"),t.id=wl,t.hidden=!0;const n=e.createElement("div");n.className=lC,n.addEventListener("click",l=>{l.target===n&&Wn(e)});const r=e.createElement("div");r.className=uC,r.setAttribute("role","dialog"),r.setAttribute("aria-modal","true"),r.setAttribute("aria-label",mC);const o=e.createElement("input");o.type="search",o.className=Rl,o.setAttribute("aria-label",hC),o.autocomplete="off",o.spellcheck=!1,o.addEventListener("input",()=>{w.query=o.value,w.selectedIndex=0,Sn(e)}),o.addEventListener("keydown",l=>{SC(l,e)});const a=e.createElement("div");a.className=Ol,a.setAttribute("role","listbox");const i=e.createElement("p");i.className=kl,i.hidden=!0;const s=e.createElement("p");return s.className=fC,s.textContent=vC,r.append(o,a,i,s),n.appendChild(r),t.appendChild(n),e.body.appendChild(t),t}function SC(e,t){if(!w.open)return;const n=fa(w.query);if(e.key==="ArrowDown"){e.preventDefault(),w.selectedIndex=Mr(w.selectedIndex+1,n.length),Sn(t);return}if(e.key==="ArrowUp"){e.preventDefault(),w.selectedIndex=Mr(w.selectedIndex-1,n.length),Sn(t);return}if(e.key==="Enter"){e.preventDefault(),Dl(t);return}e.key==="Escape"&&(e.preventDefault(),Wn(t))}async function Dl(e){const n=fa(w.query)[w.selectedIndex];n&&(Wn(e),await iC(n.id))}function bC(e=document){const t=Kt(e);return w.open&&t!==null&&!t.hidden}function CC(e=document){const t=yC(e);vt=e.activeElement instanceof HTMLElement?e.activeElement:null,w={open:!0,query:"",selectedIndex:0},t.hidden=!1;const n=EC(e);n&&(n.value=""),Sn(e),n?.focus()}function Wn(e=document){w.open=!1,w.query="",w.selectedIndex=0;const t=Kt(e);t&&(t.hidden=!0),vt&&e.contains(vt)&&vt.focus(),vt=null}function AC(e=document){if(bC(e)){Wn(e);return}CC(e)}function _C(e){return e!==null&&typeof e=="object"&&"type"in e&&e.type===ve.TOGGLE_COMMAND_PALETTE}function IC(){cC(),chrome.runtime.onMessage.addListener(e=>(_C(e)&&AC(document),!1))}function TC(e){return e!==null&&typeof e=="object"&&"type"in e&&e.type===ve.NAVIGATE_TO_IOC_ANCHOR&&typeof e.anchorId=="string"&&e.anchorId.length>0}function xC(e,t=document.body,n=document){const r=Nh(e,t);return r?(r.scrollIntoView({block:"center",inline:"nearest",behavior:"smooth"}),Yn(n)?la(e,n)?{ok:!0}:{ok:!1,error:"highlight not found"}:(Gn(r,{enrichmentTrigger:"auto"},n),{ok:!0})):{ok:!1,error:"highlight not found"}}function LC(){chrome.runtime.onMessage.addListener((e,t,n)=>{if(!TC(e))return!1;try{n(xC(e.anchorId))}catch(r){R(r)}return!0})}const NC="127.0.0.1",wC="8765",Ml="vera5ExamplesFixtureBridge";function RC(){return window.location.hostname===NC&&window.location.port===wC}function OC(e){window.postMessage({[Ml]:!0,action:e},"*")}function kC(){window.addEventListener("message",e=>{if(e.source!==window||!RC())return;const t=e.data;if(t?.[Ml]){if(t.action==="setStorage"&&t.payload){chrome.storage.local.set(t.payload).then(()=>{OC("setStorageDone")});return}t.action==="scanPage"&&$t()}})}const DC=document.documentElement.dataset.vera5ContentInit==="1";DC||(document.documentElement.dataset.vera5ContentInit="1",document.documentElement.dataset.vera5Content="active",q({type:ve.CONTENT_REGISTER}),Hh(),bb(),LC(),Uh(),zh(),ct(Gh),eC(),nC(),bv(),qh(),Wh(),ct(jh),ct(Kh),ct(Zb),ct(tC),ab(),IC(),pb(),kC());Nl();
