const p={IPV4:"ipv4",DOMAIN:"domain",URL:"url",MD5:"md5",SHA1:"sha1",SHA256:"sha256",CVE:"cve"},R={URL:"ioc.regex.url",SHA256:"ioc.regex.sha256",SHA1:"ioc.regex.sha1",MD5:"ioc.regex.md5",CVE:"ioc.regex.cve",IPV4:"ioc.regex.ipv4",DOMAIN:"ioc.regex.domain"},kc=32,Dc=80;function Do(e){switch(e){case R.URL:return"Matched a visible URL in page text, including defanged hxxp and bracket-dot forms.";case R.SHA256:return"Matched a 64-character hexadecimal SHA-256 hash.";case R.SHA1:return"Matched a 40-character hexadecimal SHA-1 hash.";case R.MD5:return"Matched a 32-character hexadecimal MD5 hash.";case R.CVE:return"Matched a CVE identifier (CVE-YYYY-NNNN+).";case R.IPV4:return"Matched an IPv4 address in visible text, including bracket-dot defanged forms.";case R.DOMAIN:return"Matched a domain name in visible text, including bracket-dot defanged forms.";default:return e}}function Va(e){switch(e){case p.URL:return R.URL;case p.SHA256:return R.SHA256;case p.SHA1:return R.SHA1;case p.MD5:return R.MD5;case p.CVE:return R.CVE;case p.IPV4:return R.IPV4;case p.DOMAIN:return R.DOMAIN;default:return e}}function Pc(e,t,n,r={}){const o=r.radius??kc,a=r.maxLength??Dc,i=Math.max(0,t-o),s=Math.min(e.length,n+o);let l=e.slice(i,s).replace(/\s+/g," ").trim();if(i>0&&(l=`…${l}`),s<e.length&&(l=`${l}…`),l.length<=a)return l;const u=e.slice(t,n),d=l.indexOf(u);if(d===-1)return l.slice(0,a-1)+"…";const f=Math.floor((a-u.length)/2),h=Math.max(0,d-f);let E=l.slice(h,h+a);return h>0&&(E=`…${E.replace(/^…/,"")}`),h+a<l.length&&(E=`${E.replace(/…$/,"")}…`),E}function Mc(e,t,n,r,o,a,i){return{value:a,type:t,start:r,end:o,ruleId:n,sourceTextHint:Pc(e,r,o),...i?{displayValue:i}:{}}}const Hc=[{length:64,type:p.SHA256},{length:40,type:p.SHA1},{length:32,type:p.MD5}],wt="(?:25[0-5]|2[0-4]\\d|1?\\d?\\d)",hr="(?:\\[\\.\\]|\\(\\\\.\\)|\\[dot\\]|\\(dot\\))",kn="(?:\\.|"+hr+")",Vc=new RegExp(`(?<![\\d.])(${wt}${kn}${wt}${kn}${wt}${kn}${wt})(?![\\d.])`,"gi"),Uc="[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?",Fc="(?:\\.|"+hr+")",$c=new RegExp(`(?<![@/\\w.-])((?:${Uc}${Fc})+[a-zA-Z]{2,63})(?![@\\w.])`,"gi"),Bc="(?:https?|hxxps?)",Gc="(?::\\/\\/|\\[:\\/\\/\\]|\\[:\\]\\/\\/)",zc=`(?:[^\\s<>"'{}|\\\\^\\x60]|`+hr+")",Kc=new RegExp(`(?<![\\w/])(${Bc}${Gc}${zc}+)`,"gi"),Yc=/(?<![A-Za-z0-9_-])(CVE-\d{4}-\d{4,})(?![A-Za-z0-9_-])/gi,Wc=new Set(["bmp","css","csv","dll","doc","exe","gif","htm","html","ico","jpeg","jpg","js","json","jsx","log","map","md","pdf","png","svg","ts","tsx","txt","wasm","xml","yaml","yml"]),jc=[[10,0,0,0,10,255,255,255],[127,0,0,0,127,255,255,255],[169,254,0,0,169,254,255,255],[172,16,0,0,172,31,255,255],[192,168,0,0,192,168,255,255]];function qc(e){return new RegExp(`(?<![0-9a-fA-F])([0-9a-fA-F]{${e}})(?![0-9a-fA-F])`,"g")}function Xc(e){const t=e.split(".");if(t.length!==4)return null;const n=[];for(const r of t){if(!/^\d{1,3}$/.test(r))return null;const o=Number(r);if(o>255)return null;n.push(o)}return n}function Jc(e){for(const t of jc){let n=!0;for(let r=0;r<4;r+=1)if(e[r]<t[r]||e[r]>t[r+4]){n=!1;break}if(n)return!0}return!1}function Qc(e,t){const n=Math.max(0,t-24),r=e.slice(n,t).toLowerCase();return/(?:\bv|version\s+|release\s+|build\s+|engine\s+|from\s+version\s+)$/.test(r)}function Zc(e,t){return/^[-_][a-z0-9]/i.test(e.slice(t,t+6))}function el(e){const t=e.split(".");return t.length===4&&t.every(n=>n.length===1&&/^\d$/.test(n))}function tl(e,t,n,r){if(!el(r))return!1;const o=e.slice(n,Math.min(e.length,n+24));if(!/^\s+to\s+\d+(?:\.\d+){0,3}\b/.test(o))return!1;const a=Math.max(0,t-20),i=e.slice(a,t).toLowerCase();return/\bfrom\s+$/.test(i)}function nl(e,t){const n=Math.max(0,t-64),r=e.slice(n,t),o=r.lastIndexOf("@");if(o===-1)return!1;const a=r.slice(o+1);return!/\s/.test(a)}function rl(e){const t=e.toLowerCase();return/^(.)\1+$/.test(t)}function ol(e){const t=e.toUpperCase().split("-");if(t.length!==3||t[0]!=="CVE")return!1;const n=Number(t[1]),r=t[2];return!(!/^\d{4}$/.test(t[1])||!/^\d{4,}$/.test(r)||n<1999||n>2099)}function al(e){return e.toUpperCase()}function Po(e){return e.replace(/[.,;:!?)]+$/g,"")}function gr(e){return e.replace(/\[:\/\/\]/gi,"://").replace(/\[:]\/\//gi,"://").replace(/\[:]/gi,":").replace(/\[\.\]/g,".").replace(/\(\.\)/g,".").replace(/\[dot\]/gi,".").replace(/\(dot\)/gi,".").replace(/^hxxps:\/\//i,"https://").replace(/^hxxp:\/\//i,"http://")}function Mo(e){return gr(e)}function il(e){const t=e.split(".").pop()?.toLowerCase();return t!==void 0&&Wc.has(t)}function sl(e){return e.toLowerCase()==="localhost"}function cl(e){const t=e.split(".");if(t.length<2)return!1;for(const r of t)if(r.length<1||r.length>63||!/^[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?$/.test(r))return!1;const n=t[t.length-1];return/^[a-zA-Z]{2,63}$/.test(n)}function vr(e,t,n){return n.some(r=>e<r.end&&t>r.start)}function yt(e,t,n,r,o,a){const i=t.flags.includes("g")?t.flags:`${t.flags}g`,s=new RegExp(t.source,i),l=[];let u=s.exec(e);for(;u!==null;){const d=u[1]??u[0],f=u.index+(u[0].length-d.length),h=a?a(d):d,E=f+d.length;o(h,f,E)&&l.push(Mc(e,n,r,f,E,h,d!==h?d:void 0)),u=s.exec(e)}return l}function ll(e,t,n,r){return yt(e,qc(t),n,Va(n),(o,a,i)=>!(o.length!==t||!/^[0-9a-f]+$/i.test(o)||rl(o)||vr(a,i,r)),o=>o.toLowerCase())}function Ua(e,t=[]){const n=[],r=[...t];for(const o of Hc){const a=ll(e,o.length,o.type,r);for(const i of a)n.push(i),r.push({start:i.start,end:i.end})}return n.sort((o,a)=>o.start-a.start)}function Fa(e,t=[]){return yt(e,Yc,p.CVE,R.CVE,(n,r,o)=>!(!ol(n)||vr(r,o,t)),al)}function $a(e,t={}){const n=t.includePrivateIpv4??!1;return yt(e,Vc,p.IPV4,R.IPV4,(r,o,a)=>{const i=Xc(r);return!(!i||!n&&Jc(i)||Qc(e,o)||Zc(e,a)||tl(e,o,a,r))},gr)}function Ba(e){return yt(e,Kc,p.URL,R.URL,t=>{const n=Po(t);if(n.length<10)return!1;try{const r=Mo(n),o=new URL(r);return o.protocol==="http:"||o.protocol==="https:"}catch{return!1}},t=>Mo(Po(t)))}function Ga(e,t=[]){return yt(e,$c,p.DOMAIN,R.DOMAIN,(n,r,o)=>{const a=n.toLowerCase();return!cl(n)||il(n)?!1:sl(a)?!0:!(nl(e,r)||vr(r,o,t))},n=>gr(n).toLowerCase())}const ul=2048,dl=["type","value","iocType","sourceId","bypassCache"];new Set(dl);const pl=/<[a-z!/]/i;function fl(e,t){switch(t){case p.IPV4:return $a(e);case p.DOMAIN:return Ga(e);case p.URL:return Ba(e);case p.MD5:case p.SHA1:case p.SHA256:return Ua(e).filter(n=>n.type===t);case p.CVE:return Fa(e);default:return[]}}function za(e,t){const n=e.trim();return n.length===0||n.length>ul||/[\r\n\t]/.test(n)||pl.test(n)?null:fl(n,t).find(a=>a.start===0&&a.end===n.length)?.value??null}function ml(e){const t=za(e.value,e.type);return t?{value:t,type:e.type}:null}const hl=["api.abuseipdb.com","otx.alienvault.com"];new Set(hl);const Er=2,gl=new Set(Object.values(p));function vl(e,t,n){return`vera5-loc-${e}-${t}-${n}`}function El(e){return{schemaVersion:Er,pageUrl:e.pageUrl,scannedAt:e.scannedAt??Date.now(),entries:e.entries}}function yl(e){return e.map(t=>({type:t.type,value:t.value,anchorId:vl(t.type,t.start,t.end),ruleId:t.ruleId,sourceTextHint:t.sourceTextHint,...t.displayValue?{displayValue:t.displayValue}:{},...t.ignoredOverlaps&&t.ignoredOverlaps.length>0?{ignoredOverlaps:[...t.ignoredOverlaps]}:{}}))}function bl(e){return typeof e=="string"&&gl.has(e)}function Sl(e){return typeof e.ruleId=="string"&&e.ruleId.length>0&&typeof e.sourceTextHint=="string"&&e.sourceTextHint.length>0}function Cl(e,t){if(e===null||typeof e!="object")return!1;const n=e;return bl(n.type)&&typeof n.value=="string"&&n.value.length>0&&typeof n.anchorId=="string"&&n.anchorId.length>0?t>=Er?Sl(n):!0:!1}function Al(e){if(e===null||typeof e!="object")return!1;const t=e,n=t.schemaVersion;return n!==1&&n!==Er||typeof t.pageUrl!="string"||typeof t.scannedAt!="number"||!Number.isFinite(t.scannedAt)||!Array.isArray(t.entries)?!1:t.entries.every(r=>Cl(r,n))}const ce={TAB_SCAN_SNAPSHOT:"TAB_SCAN_SNAPSHOT",GET_TAB_SCAN_SUMMARY:"GET_TAB_SCAN_SUMMARY",OPEN_OPTIONS_PAGE:"OPEN_OPTIONS_PAGE",OPEN_SITE_PERMISSIONS:"OPEN_SITE_PERMISSIONS",LIST_IOC_COLLECTIONS:"LIST_IOC_COLLECTIONS",CREATE_IOC_COLLECTION:"CREATE_IOC_COLLECTION",ADD_IOC_TO_COLLECTION:"ADD_IOC_TO_COLLECTION",ADD_IOCS_TO_COLLECTION:"ADD_IOCS_TO_COLLECTION"};function Il(e){return{type:ce.TAB_SCAN_SNAPSHOT,snapshot:e}}function Ka(){return{type:ce.OPEN_OPTIONS_PAGE}}function Tl(){return{type:ce.OPEN_SITE_PERMISSIONS}}function _l(){return{type:ce.LIST_IOC_COLLECTIONS}}function xl(e){return{type:ce.CREATE_IOC_COLLECTION,name:e.name,...e.description?{description:e.description}:{}}}function Nl(e){return{type:ce.ADD_IOC_TO_COLLECTION,collectionId:e.collectionId,iocType:e.iocType,value:e.value}}function wl(e){return{type:ce.ADD_IOCS_TO_COLLECTION,collectionId:e.collectionId,members:e.members}}function Rl(e){return{type:ce.GET_TAB_SCAN_SUMMARY}}const Ol=["Extension context invalidated","Receiving end does not exist","The message port closed before a response was received"],Ll=["Access to storage is not allowed from this context"];function L(){if(typeof chrome>"u"||!chrome.runtime)return!1;try{return chrome.runtime.id,!1}catch{return!0}}function Ya(){return typeof chrome>"u"||!chrome.runtime?!1:!L()}function kl(e){const t=e instanceof Error?e.message:typeof e=="string"?e:"";return t.length===0?!1:Ol.some(n=>t.includes(n))}function Dl(e){const t=e instanceof Error?e.message:typeof e=="string"?e:"";return t.length===0?!1:Ll.some(n=>t.includes(n))}function Te(e){return kl(e)||Dl(e)}const Rt=160;function Pl(e){if(e instanceof Error){const t=e.name.trim()||"Error";let n=e.message.trim();return n.length>Rt&&(n=`${n.slice(0,Rt)}…`),n.length>0?`${t}: ${n}`:t}if(typeof e=="string"){const t=e.trim();return t.length===0?"Vera5 extension error":t.length>Rt?`${t.slice(0,Rt)}…`:t}return"Vera5 extension error"}function C(e){Te(e)||console.error(Pl(e))}function w(e){if(!Te(e))throw e}async function k(e){if(typeof chrome>"u"||!chrome.storage?.local)return{};if(L())return{};try{return await chrome.storage.local.get(e)}catch(t){if(Te(t))return{};throw t}}async function Ml(e){if(typeof chrome>"u"||!chrome.storage?.session)return{};if(L())return{};try{return await chrome.storage.session.get(e)}catch(t){if(Te(t))return{};throw t}}async function Hl(e){if(typeof chrome>"u"||!chrome.storage?.session||L())return!1;try{return await chrome.storage.session.set(e),!0}catch(t){if(Te(t))return!1;throw t}}async function yr(e){if(typeof chrome>"u"||!chrome.storage?.local||L())return!1;try{return await chrome.storage.local.set(e),!0}catch(t){if(Te(t))return!1;throw t}}async function br(e){if(typeof chrome>"u"||!chrome.storage?.local||L())return!1;try{return await chrome.storage.local.remove(e),!0}catch(t){if(Te(t))return!1;throw t}}async function z(e){if(!Ya())return null;try{return await chrome.runtime.sendMessage(e)}catch(t){return w(t),null}}function Wa(){if(Ya()){if(typeof chrome.runtime.openOptionsPage=="function")try{chrome.runtime.openOptionsPage();return}catch(e){w(e)}z(Ka())}}function on(e){if(!L())try{e()}catch(t){w(t)}}async function Dn(e){if(!L())try{await e()}catch(t){w(t)}}const ja="allow_by_default",Un="deny_by_default";function Sr(e){return e.trim().toLowerCase()}function Re(e){if(!Array.isArray(e))return[];const t=[],n=new Set;for(const r of e){if(typeof r!="string")continue;const o=Sr(r);!o||n.has(o)||(n.add(o),t.push(o))}return t}function qa(e){return e===Un?Un:ja}const Xa=["mail.*","webmail.*","outlook.office.com","outlook.live.com","mail.google.com","mail.yahoo.com"];function Fn(){return{mode:ja,allowlist:[],denylist:[...Xa]}}function Vl(e){return{mode:qa(e.mode),allowlist:Re(e.allowlist),denylist:Re(e.denylist)}}function Ja(e,t){const n=e.trim().toLowerCase(),r=Sr(t);if(!n||!r)return!1;if(r.startsWith("*.")){const o=r.slice(2);return o?n===o||n.endsWith(`.${o}`):!1}if(r.endsWith(".*")){const o=r.slice(0,-2);return o?n===o||n.startsWith(`${o}.`):!1}return n===r}function $n(e,t){return t.some(n=>Ja(e,n))}function Ul(e,t){return $n(e,t.denylist)?!1:t.mode===Un?$n(e,t.allowlist):!0}let Pt=null;function Fl(){return new Promise(e=>{Pt=e})}function Bn(e){Pt&&(Pt(e),Pt=null)}function Qa(){Bn({proceed:!1,rememberDismiss:!1})}function $l(e){return`Vera5 will query ${Bl(e.sourceLabels)} with this ${e.typeLabel}: ${e.value}`}function Bl(e){if(e.length===0)return"your enabled vendors";if(e.length===1)return e[0];if(e.length===2)return`${e[0]} and ${e[1]}`;const t=e.slice(0,-1).join(", "),n=e[e.length-1];return`${t}, and ${n}`}async function j(e){if(e.length===0)return!1;if(typeof navigator<"u"&&navigator.clipboard?.writeText)try{return await navigator.clipboard.writeText(e),!0}catch{return Ho(e)}return Ho(e)}function Ho(e){if(typeof document>"u")return!1;const t=document.createElement("textarea");t.value=e,t.setAttribute("readonly",""),t.style.position="fixed",t.style.left="-9999px",document.body.appendChild(t),t.select();let n=!1;try{n=document.execCommand("copy")}catch{n=!1}return t.remove(),n}const it="analystNotes";function Za(){return typeof chrome<"u"&&chrome.storage?.local!==void 0&&!L()}function Gn(e){if(e===null||typeof e!="object"||Array.isArray(e))return{};const t={};for(const[n,r]of Object.entries(e)){if(typeof n!="string"||typeof r!="string")continue;const o=n.trim(),a=r.trim();o.length===0||a.length===0||(t[o]=r)}return t}function F(e){return e.trim()}async function Cr(){if(!Za())return{};const e=await k(it);return Gn(e[it])}async function Gl(e){const t=F(e);return t.length===0?"":(await Cr())[t]??""}async function zl(e,t){if(!Za())return;const n=F(e);if(n.length===0)return;const r=await Cr();if(t.trim().length===0?delete r[n]:r[n]=t,Object.keys(r).length===0){await br(it);return}await yr({[it]:r})}const st=new Map,Pn=new Map,Kl=400;let ei=!1;function Ar(){return typeof chrome<"u"&&chrome.storage?.local!==void 0&&!L()}function Mt(){ei=!0}function Ir(e){return F(e)}function ti(e,t){const n=Ir(e);if(t.trim().length===0){st.delete(n);return}st.set(n,t)}function Yl(e,t){if(!Ar())return;const n=Ir(e),r=Pn.get(n);r&&clearTimeout(r),Pn.set(n,setTimeout(()=>{Pn.delete(n),zl(e,t).catch(w)},Kl))}function ct(e){return st.get(Ir(e))??""}function Wl(e,t){ti(e,t),Yl(e,t)}function ni(e,t){ti(e,t)}async function jl(){if(!Ar()){Mt();return}try{const e=await Cr();for(const[t,n]of Object.entries(e))st.has(t)||st.set(t,n);Mt()}catch(e){w(e),Mt()}}function ql(e,t){const n=ct(e);if(n.length>0){t(n);return}if(!ei){if(!Ar()){Mt();return}Gl(e).then(r=>{r.length!==0&&(ct(e).length>0||(ni(e,r),t(r)))}).catch(w)}}function an(e,t){const n=ct(e);return n.length>0?n:t??""}const g={ABUSEIPDB:"abuseipdb",OTX:"otx",URLSCAN:"urlscan",VIRUSTOTAL:"virustotal",GREYNOISE:"greynoise",SHODAN:"shodan",GOOGLE_SAFE_BROWSING:"google_safe_browsing",PULSEDIVE:"pulsedive",MALWAREBAZAAR:"malwarebazaar",CENSYS:"censys",THREATFOX:"threatfox",URLHAUS:"urlhaus"},I=[g.ABUSEIPDB,g.OTX,g.VIRUSTOTAL,g.URLSCAN,g.GREYNOISE,g.SHODAN,g.GOOGLE_SAFE_BROWSING,g.PULSEDIVE,g.MALWAREBAZAAR,g.CENSYS,g.THREATFOX,g.URLHAUS],Xl=new Set(I),Tr="censys_secret",Jl=[...I,Tr],Mn=[p.IPV4,p.DOMAIN,p.URL,p.MD5,p.SHA1,p.SHA256,p.CVE],Ht=[p.MD5,p.SHA1,p.SHA256],Ql=[p.IPV4,p.DOMAIN,p.URL];function G(e){return encodeURIComponent(e.trim())}function ze(e){return e.replace(/^hxxps?:\/\//i,t=>t.toLowerCase().startsWith("hxxps")?"https://":"http://")}function Zl(e,t){const n=t.trim();switch(e){case p.IPV4:return`https://www.virustotal.com/gui/ip-address/${n}`;case p.DOMAIN:return`https://www.virustotal.com/gui/domain/${G(n)}`;case p.URL:return`https://www.virustotal.com/gui/search/${G(ze(n))}`;case p.MD5:case p.SHA1:case p.SHA256:return`https://www.virustotal.com/gui/file/${n.toLowerCase()}`;case p.CVE:return`https://www.virustotal.com/gui/search/${G(n)}`;default:return null}}function eu(e,t){const n=t.trim();switch(e){case p.IPV4:return`https://otx.alienvault.com/indicator/ip/${n}`;case p.DOMAIN:return`https://otx.alienvault.com/indicator/domain/${G(n)}`;case p.URL:return`https://otx.alienvault.com/indicator/url/${G(ze(n))}`;case p.MD5:case p.SHA1:case p.SHA256:return`https://otx.alienvault.com/indicator/file/${n.toLowerCase()}`;case p.CVE:return`https://otx.alienvault.com/indicator/cve/${G(n)}`;default:return null}}function tu(e,t){return e!==p.IPV4?null:`https://www.abuseipdb.com/check/${G(t.trim())}`}function nu(e,t){const n=t.trim();switch(e){case p.IPV4:return`https://urlscan.io/search/#ip:${encodeURIComponent(n)}`;case p.DOMAIN:return`https://urlscan.io/search/#domain:${encodeURIComponent(n)}`;case p.URL:return`https://urlscan.io/search/#page.url:"${encodeURIComponent(ze(n))}"`;case p.MD5:case p.SHA1:case p.SHA256:return`https://urlscan.io/search/#hash:${encodeURIComponent(n.toLowerCase())}`;default:return null}}function ru(e,t){return e!==p.IPV4?null:`https://viz.greynoise.io/ip/${G(t.trim())}`}function ou(e,t){const n=t.trim();switch(e){case p.IPV4:return`https://www.shodan.io/host/${G(n)}`;case p.DOMAIN:return`https://www.shodan.io/search?query=${encodeURIComponent(n)}`;default:return null}}function au(e,t){const n=t.trim();return e===p.URL?`https://pulsedive.com/explore?q=${encodeURIComponent(ze(n))}`:`https://pulsedive.com/explore?q=${encodeURIComponent(n)}`}function iu(e,t){return Ht.includes(e)?`https://bazaar.abuse.ch/browse.php?search=sha256:${encodeURIComponent(t.trim().toLowerCase())}`:null}function su(e,t){const n=t.trim();switch(e){case p.IPV4:return`https://search.censys.io/hosts/${G(n)}`;case p.DOMAIN:return`https://search.censys.io/domains/${G(n)}`;default:return null}}function cu(e,t){const n=t.trim();return e===p.URL?`https://threatfox.abuse.ch/browse.php?search=ioc:${encodeURIComponent(ze(n))}`:`https://threatfox.abuse.ch/browse.php?search=ioc:${encodeURIComponent(n)}`}function lu(e,t){if(e!==p.URL&&e!==p.DOMAIN)return null;const n=e===p.URL?ze(t.trim()):t.trim();return`https://urlhaus.abuse.ch/browse.php?search=${encodeURIComponent(n)}`}const Ke={[g.ABUSEIPDB]:{id:g.ABUSEIPDB,displayName:"AbuseIPDB",description:"IP reputation and abuse confidence scoring.",supportedIndicatorTypes:[p.IPV4],requiresApiKey:!0,settingsKeyName:"ABUSEIPDB_API_KEY",cacheKeyNamespace:"abuseipdb",enabledDefault:!1,liveConnector:!0,buildPivotUrl:tu},[g.OTX]:{id:g.OTX,displayName:"OTX",description:"AlienVault Open Threat Exchange pulses.",supportedIndicatorTypes:Mn,requiresApiKey:!0,settingsKeyName:"OTX_API_KEY",cacheKeyNamespace:"otx",enabledDefault:!1,liveConnector:!0,buildPivotUrl:eu},[g.VIRUSTOTAL]:{id:g.VIRUSTOTAL,displayName:"VirusTotal",description:"Multi-vendor file, URL, domain, and IP reputation.",supportedIndicatorTypes:Mn,requiresApiKey:!0,settingsKeyName:"VT_API_KEY",cacheKeyNamespace:"virustotal",enabledDefault:!1,liveConnector:!1,buildPivotUrl:Zl},[g.URLSCAN]:{id:g.URLSCAN,displayName:"URLScan.io",description:"URL and domain scan intelligence.",supportedIndicatorTypes:[p.IPV4,p.DOMAIN,p.URL,...Ht],requiresApiKey:!0,settingsKeyName:"URLSCAN_API_KEY",cacheKeyNamespace:"urlscan",enabledDefault:!1,liveConnector:!1,buildPivotUrl:nu},[g.GREYNOISE]:{id:g.GREYNOISE,displayName:"GreyNoise",description:"Internet background-noise context for IP addresses.",supportedIndicatorTypes:[p.IPV4],requiresApiKey:!0,settingsKeyName:"GREYNOISE_API_KEY",cacheKeyNamespace:"greynoise",enabledDefault:!1,liveConnector:!1,buildPivotUrl:ru},[g.SHODAN]:{id:g.SHODAN,displayName:"Shodan",description:"Internet-wide exposure and service intelligence.",supportedIndicatorTypes:[p.IPV4,p.DOMAIN],requiresApiKey:!0,settingsKeyName:"SHODAN_API_KEY",cacheKeyNamespace:"shodan",enabledDefault:!1,liveConnector:!1,buildPivotUrl:ou},[g.GOOGLE_SAFE_BROWSING]:{id:g.GOOGLE_SAFE_BROWSING,displayName:"Google Safe Browsing",description:"Google threat lists for malicious URLs and domains.",supportedIndicatorTypes:[p.URL,p.DOMAIN],requiresApiKey:!0,settingsKeyName:"GOOGLE_SAFE_BROWSING_API_KEY",cacheKeyNamespace:"google_safe_browsing",enabledDefault:!1,liveConnector:!1},[g.PULSEDIVE]:{id:g.PULSEDIVE,displayName:"Pulsedive",description:"Threat intelligence context for IOCs and assets.",supportedIndicatorTypes:Mn,requiresApiKey:!0,settingsKeyName:"PULSEDIVE_API_KEY",cacheKeyNamespace:"pulsedive",enabledDefault:!1,liveConnector:!1,buildPivotUrl:au},[g.MALWAREBAZAAR]:{id:g.MALWAREBAZAAR,displayName:"MalwareBazaar",description:"Abuse.ch malware sample hash intelligence.",supportedIndicatorTypes:Ht,requiresApiKey:!0,settingsKeyName:"MALWAREBAZAAR_API_KEY",cacheKeyNamespace:"malwarebazaar",enabledDefault:!1,liveConnector:!1,buildPivotUrl:iu},[g.CENSYS]:{id:g.CENSYS,displayName:"Censys",description:"Internet asset and certificate search.",supportedIndicatorTypes:[p.IPV4,p.DOMAIN],requiresApiKey:!0,secondaryApiKeySlot:Tr,settingsKeyName:"CENSYS_API_KEY",secondarySettingsKeyName:"CENSYS_SECRET",cacheKeyNamespace:"censys",enabledDefault:!1,liveConnector:!1,buildPivotUrl:su},[g.THREATFOX]:{id:g.THREATFOX,displayName:"ThreatFox",description:"Abuse.ch IOC sharing for malware campaigns.",supportedIndicatorTypes:[...Ql,...Ht],requiresApiKey:!0,settingsKeyName:"THREATFOX_API_KEY",cacheKeyNamespace:"threatfox",enabledDefault:!1,liveConnector:!1,buildPivotUrl:cu},[g.URLHAUS]:{id:g.URLHAUS,displayName:"URLHaus",description:"Abuse.ch malicious URL distribution tracking.",supportedIndicatorTypes:[p.URL,p.DOMAIN],requiresApiKey:!0,settingsKeyName:"URLHAUS_API_KEY",cacheKeyNamespace:"urlhaus",enabledDefault:!1,liveConnector:!1,buildPivotUrl:lu}},Ye=Object.fromEntries(I.map(e=>[e,Ke[e].displayName]));Object.fromEntries(I.map(e=>[e,Ke[e].description]));I.filter(e=>Ke[e].liveConnector);I.filter(e=>Ke[e].requiresApiKey);function uu(e){return Xl.has(e)}function du(e){return uu(e)||e===Tr}function pu(e,t){return Ke[e].supportedIndicatorTypes.includes(t)}function fu(e){return`${e} is disabled. Enable it in extension settings to load enrichment.`}function mu(e,t,n){const r=Ke[e].buildPivotUrl;return r?r(t,n):null}const zn="Threat intelligence summary is not available yet.",hu="Loading threat intelligence…",_r="Threat intelligence could not be loaded.";function ri(e,t){return t==="error"?`Source: ${e.sourceLabel}`:e.fromCache?`Source: ${e.sourceLabel} · cached`:`Source: ${e.sourceLabel} · live`}function gu(e,t,n){return bt(n)||!t?.sourceLabel.trim()?!1:e==="ready"||e==="error"}const vu="Open settings",Eu="Raw response",yu="Analyst notes",bu="Add local notes for this indicator…",Su="Analyst notes",xr="vera5-analyst-notes-input",Cu="Label",Au="Indicator label",oi="vera5-ioc-label-select",et="",Iu="Session timeline",Tu="Session timeline for this indicator",_u="No session timeline for this indicator yet.",xu="Pin",Nu="Pinned",wu="Pin indicator for triage priority",ai="Enrichment uses your API keys and sends only the selected indicator value to vendors you enable—not the full page.",ii="The risk label is computed locally from available source signals. It is advisory only; review each source before acting.";function Nr(e={}){const t=[],n=e.enrichmentState??"empty";return(n==="ready"||n==="loading"||n==="error")&&t.push(ai),e.includeRiskScoreDisclaimer&&t.push(ii),t}const Ru="Enrichment and risk score notice",Vo="Enrichment notice";function Ou(e={}){const t=Nr(e),n=t.includes(ii),r=t.includes(ai);return n&&r?Ru:r?Vo:n?"Risk score notice":Vo}function si(e,t){if(e?.sourceLabel.trim())return e;if(t.length!==1)return;const n=t[0];if(n?.label.trim())return{sourceLabel:n.label,fromCache:n.fromCache}}function Lu(e,t,n){return bt(n)?!1:e==="error"&&t==="missing_key"}function ku(e,t,n){return bt(n)?!1:e==="error"&&!!t?.trim()}function wr(e){return I.filter(n=>e.includes(n)).map(n=>{const r=Ye[n];return{sourceId:n,label:r,message:fu(r)}})}function Du(e){const t=e.trim();if(!t)return;const n=new Date(t);if(!Number.isNaN(n.getTime()))return new Intl.DateTimeFormat(void 0,{dateStyle:"medium",timeStyle:"short"}).format(n)}function Pu(e){const t=e?Du(e):void 0;if(t)return`Last updated: ${t}`}function ci(e,t){return e==="ok"?t===!0?"Cached":"Live":e==="error"?"Error":"Skipped"}function Mu(e,t){return e==="ok"&&t===!0?"vera5-hover-card-source-badge vera5-hover-card-source-badge--cached":`vera5-hover-card-source-badge vera5-hover-card-source-badge--${e}`}function Hu(e){if(!bt(e))return e?.[0]?.lastUpdatedLine}function Vu(e){return I.includes(e)}function Uu(e){return e.status==="ok"?e.summary?.trim()||zn:e.errorMessage?.trim()||(e.status==="skipped"?"Enrichment was not available for this source.":_r)}function Fu(e){if(!Vu(e.sourceId))return null;const t=e.status==="ok"&&e.fromCache===!0,n={sourceId:e.sourceId,label:e.sourceLabel.trim()||Ye[e.sourceId],status:e.status,fromCache:t,badgeText:ci(e.status,t),detail:Uu(e)},r=Pu(e.fetchedAt);r&&(n.lastUpdatedLine=r);const o=e.tags?.map(i=>i.trim()).filter(i=>i.length>0);o&&o.length>0&&(n.tags=o),e.errorCode&&(n.errorCode=e.errorCode),e.retryHint&&(n.retryHint=e.retryHint);const a=e.rawVendorJson?.trim();return a&&e.status==="ok"&&(n.rawVendorJson=a),n}function $u(e){const t=e??[];return t.length===1&&!!t[0]?.rawVendorJson?.trim()}function li(e){const t=new Map;for(const n of e){const r=Fu(n);r&&t.set(r.sourceId,r)}return I.flatMap(n=>{const r=t.get(n);return r?[r]:[]})}function bt(e){return(e?.length??0)>1}function Rr(e){return I.every(t=>e.includes(t))}function Bu(e,t){return Rr(e??[])?!1:(t?.length??0)>0}function Gu(e,t){return Rr(e??[])?!0:(t?.length??0)>0}function zu(e,t){return Bu(e,t)}function Ku(e={}){return Nr(e).length>0}function ui(e){const t=li(e);if(t.length===0)return{enrichmentState:"error",errorMessage:_r,sourceResults:[]};const n=t.filter(o=>o.status==="ok");if(n.length>0){const o=n[0];return{enrichmentState:"ready",summary:o.detail,tags:o.tags,sourceAttribution:t.length===1?{sourceLabel:o.label,fromCache:o.fromCache}:void 0,sourceResults:t}}const r=t[0];return{enrichmentState:"error",summary:r.detail,errorMessage:r.detail,errorCode:r.errorCode,retryHint:r.retryHint,sourceAttribution:{sourceLabel:r.label},sourceResults:t}}function Yu(e){const t=e.enrichmentState??"empty";return t==="loading"?{text:hu,variant:"loading"}:t==="error"?{text:e.errorMessage?.trim()||_r,variant:"error"}:t==="ready"?{text:e.summary?.trim()||zn,variant:"ready"}:{text:e.summary?.trim()||zn,variant:"empty"}}function Wu(e){const t=e.sourceResults??[],n=e.disabledSources??[],r=Yu({enrichmentState:e.enrichmentState,summary:e.summary,errorMessage:e.errorMessage}),o=wr(n),a=(e.tags??[]).map(Y=>Y.trim()).filter(Y=>Y.length>0),i=r.variant==="ready"&&a.length>0,s=bt(t),l=$u(t),u=l?t[0]?.rawVendorJson:void 0,d=gu(r.variant,si(e.sourceAttribution,t),t),f=Lu(r.variant,e.errorCode,t),h=ku(r.variant,e.retryHint,t),E=Hu(t),x=Gu(n,t),P=zu(n,t),Z={enrichmentState:r.variant,includeRiskScoreDisclaimer:P},m=Nr(Z),$=Ku(Z),K=(e.pivotLinkCount??0)>0,S=K||o.length>0||s;return{enrichment:r,enrichmentTags:a,showTags:i,showMultiSourceResults:s,showSingleSourceRawJson:l,singleSourceRawJson:u,showAttribution:d,showMissingKeyAction:f,showRateLimitRetryHint:h,singleSourceLastUpdatedLine:E,showRiskScore:x,includeRiskScoreDisclaimer:P,disclaimerLines:m,showDisclaimer:$,showFooter:S,showBelowSummary:S||i||!!(l&&u)||d||f||h||!!E||x||$,disabledSourcePlaceholders:o,hasPivotLinks:K}}const di="Why detected?",ju="Why detected?",qu={[p.IPV4]:"IPv4 address",[p.DOMAIN]:"Domain",[p.URL]:"URL",[p.MD5]:"MD5 hash",[p.SHA1]:"SHA1 hash",[p.SHA256]:"SHA256 hash",[p.CVE]:"CVE ID"};function Uo(e){return qu[e]}function pi(e){return!e.ruleId||!e.sourceTextHint?null:{typeLabel:Uo(e.type),reason:Do(e.ruleId),sourceTextHint:e.sourceTextHint,ignoredOverlaps:(e.ignoredOverlaps??[]).map(t=>({typeLabel:Uo(t.type),value:t.value,reason:Do(t.ruleId)}))}}const Xu="On page:",fi="Refanged:",Ju="Copy Indicator",Qu="Copy defanged",Zu="Copy refanged",ed="Copied",Fo="Open live URL",td="This opens the live URL in a new browser tab. The destination may be malicious or unreachable. Continue?",nd="Pre-query notice",rd="Before querying vendors",$o="Send query",Bo="Cancel",Go="Don't show this notice again";function Or(e){const t=e.value,n=e.displayValue??e.value;return{onPageValue:n,refangedValue:t,showRefangedPair:n!==t}}function od(e){return e.showRefangedPair?[{copyValue:e.onPageValue,label:Qu,ariaLabel:`Copy defanged indicator ${e.onPageValue}`},{copyValue:e.refangedValue,label:Zu,ariaLabel:`Copy refanged indicator ${e.refangedValue}`}]:[{copyValue:e.refangedValue,label:Ju,ariaLabel:`Copy indicator ${e.refangedValue}`}]}function ad(e){return e===p.URL}function id(e=window){return e.confirm(td)}function sd(e,t=window){t.open(e,"_blank","noopener,noreferrer")}const y={ABUSEIPDB:g.ABUSEIPDB,OTX:g.OTX,VIRUSTOTAL:g.VIRUSTOTAL,URLSCAN:g.URLSCAN,GREYNOISE:g.GREYNOISE,SHODAN:g.SHODAN,PULSEDIVE:g.PULSEDIVE,MALWAREBAZAAR:g.MALWAREBAZAAR,CENSYS:g.CENSYS,THREATFOX:g.THREATFOX,URLHAUS:g.URLHAUS},cd=I.filter(e=>e!==g.GOOGLE_SAFE_BROWSING);function mi(e,t){return!t?.enabledSourceIds||t.showDisabledSources===!0?!0:t.enabledSourceIds.includes(e)}function hi(e,t,n){return mu(e,t,n)}function ld(e,t,n){const r=[];for(const o of cd){if(!mi(o,n))continue;const a=hi(o,e,t);a&&r.push({provider:o,label:Ye[o],href:a})}return r}function ud(e,t){if(!t||t.length===0)return[...e];const n=new Map(t.map((r,o)=>[r,o]));return[...e].sort((r,o)=>{const a=n.get(r.provider)??Number.MAX_SAFE_INTEGER,i=n.get(o.provider)??Number.MAX_SAFE_INTEGER;return a!==i?a-i:0})}const Hn=[{provider:y.VIRUSTOTAL,guidance:"Compare file detections and sandbox behavior."},{provider:y.OTX,guidance:"Review pulses and related indicators for the hash."},{provider:y.MALWAREBAZAAR,guidance:"Look up sample metadata and delivery context."},{provider:y.URLSCAN,guidance:"Find pages or downloads referencing the hash."},{provider:y.THREATFOX,guidance:"Review shared campaign IOC context."}],dd={[p.IPV4]:[{provider:y.ABUSEIPDB,guidance:"Check abuse confidence and network ownership."},{provider:y.OTX,guidance:"Review community pulses and related indicators."},{provider:y.VIRUSTOTAL,guidance:"Compare detections across vendors."},{provider:y.GREYNOISE,guidance:"Check whether traffic is internet background noise."},{provider:y.SHODAN,guidance:"Review exposed services and host metadata."},{provider:y.URLSCAN,guidance:"Search related scans and hosting context."},{provider:y.CENSYS,guidance:"Inspect certificates and host exposure."},{provider:y.PULSEDIVE,guidance:"Explore related threat context for the IP."},{provider:y.THREATFOX,guidance:"Review shared campaign IOC context."}],[p.DOMAIN]:[{provider:y.VIRUSTOTAL,guidance:"Review domain reputation and DNS records."},{provider:y.OTX,guidance:"Check passive DNS and threat pulses."},{provider:y.URLSCAN,guidance:"Find pages and certificates tied to the domain."},{provider:y.SHODAN,guidance:"Search related hosts and DNS records."},{provider:y.PULSEDIVE,guidance:"Explore domain threat context and risk."},{provider:y.CENSYS,guidance:"Review certificates and DNS history."},{provider:y.URLHAUS,guidance:"Check known malicious URL distribution."}],[p.URL]:[{provider:y.URLSCAN,guidance:"Inspect page content, redirects, and resources."},{provider:y.VIRUSTOTAL,guidance:"Review URL reputation and related files."},{provider:y.OTX,guidance:"Check pulses and related indicators for the URL."},{provider:y.PULSEDIVE,guidance:"Explore URL threat context and risk."},{provider:y.URLHAUS,guidance:"Check known malicious URL distribution."},{provider:y.THREATFOX,guidance:"Review shared campaign IOC context."}],[p.MD5]:Hn,[p.SHA1]:Hn,[p.SHA256]:Hn,[p.CVE]:[{provider:y.VIRUSTOTAL,guidance:"Search vendor coverage and related indicators."},{provider:y.OTX,guidance:"Review pulses and advisories for the CVE."},{provider:y.PULSEDIVE,guidance:"Explore CVE threat context and related IOCs."}]};function gi(e,t,n){const r=dd[e]??[],o=[];for(const a of r){if(!mi(a.provider,n))continue;const i=hi(a.provider,e,t);if(!i)continue;const s=Ye[a.provider];o.push({provider:a.provider,sourceLabel:s,label:s,href:i,guidance:a.guidance})}return ud(o,n?.emphasisProviders)}const sn={OK:"ok",ERROR:"error",SKIPPED:"skipped"},cn={MISSING_KEY:"missing_key",UNAUTHORIZED:"unauthorized",RATE_LIMITED:"rate_limited",TIMEOUT:"timeout",UNSUPPORTED_TYPE:"unsupported_type",NETWORK:"network_error",DISABLED:"disabled",DOMAIN_POLICY:"domain_policy",INTERNAL_ASSET:"internal_asset",VENDOR:"vendor_error"},pd={OK:"ok",ERROR:"error"};new Set(Object.values(pd));const fd=new Set(Object.values(sn)),md=new Set(Object.values(cn));new Set(Object.values(p));function hd(e){return typeof e!="string"||e.trim().length===0?!1:!Number.isNaN(Date.parse(e))}function vi(e){if(!Array.isArray(e))return;const t=e.filter(n=>typeof n=="string").map(n=>n.trim()).filter(n=>n.length>0);return t.length>0?t:void 0}function gd(e){return typeof e=="string"&&fd.has(e)}function vd(e){return typeof e=="string"&&md.has(e)}function Ed(e){if(typeof e!="object"||e===null)return!1;const t=e;return!(typeof t.sourceId!="string"||typeof t.sourceLabel!="string"||!gd(t.status)||t.summary!==void 0&&typeof t.summary!="string"||t.tags!==void 0&&vi(t.tags)===void 0||t.errorCode!==void 0&&!vd(t.errorCode)||t.errorMessage!==void 0&&typeof t.errorMessage!="string"||t.retryHint!==void 0&&typeof t.retryHint!="string"||t.fetchedAt!==void 0&&!hd(t.fetchedAt)||t.fromCache!==void 0&&typeof t.fromCache!="boolean"||t.rawVendorJson!==void 0&&typeof t.rawVendorJson!="string")}function yd(e){if(!Ed(e))return null;const t=e,n={sourceId:t.sourceId,sourceLabel:t.sourceLabel.trim(),status:t.status},r=t.summary?.trim();r&&(n.summary=r);const o=vi(t.tags);o&&(n.tags=o),t.errorCode&&(n.errorCode=t.errorCode);const a=t.errorMessage?.trim();a&&(n.errorMessage=a);const i=t.retryHint?.trim();i&&(n.retryHint=i),t.fetchedAt&&(n.fetchedAt=t.fetchedAt),t.fromCache===!0&&(n.fromCache=!0);const s=t.rawVendorJson?.trim();return s&&(n.rawVendorJson=s),n}const V={UNKNOWN:"unknown",LOW:"low",SUSPICIOUS:"suspicious",HIGH:"high",CRITICAL:"critical"},Ei="Sources disagree: compare per-source details before deciding.";function yi(e){return e===V.UNKNOWN?"Unknown":e===V.LOW?"Low":e===V.SUSPICIOUS?"Suspicious":e===V.HIGH?"High":"Critical"}function bd(e){if(e.signalStrength===null||e.bandLabel===null)return`${e.sourceLabel}: no weighted signal (${e.status}).`;const t=Math.round(e.signalStrength),n=yi(e.bandLabel);return`${e.sourceLabel}: ${n} (${t}/100, weight ${e.weight.toFixed(2)}).`}function Sd(e){const t=yi(e.label);return e.compositeSignal===null?`${t} risk`:`${t} risk (${Math.round(e.compositeSignal)}/100)`}function Cd(e){return{sourceLines:e.sources.map(bd),showDisagreement:e.disagreement,disagreementLine:Ei}}const Lr="How this score was computed",Ad=Lr,Id="vera5-hover-card-risk-reasoning",Td="vera5-hover-card-risk-reasoning-heading",_d="vera5-hover-card-risk-reasoning-chain",xd="vera5-hover-card-risk-reasoning-step",Nd="vera5-hover-card-risk-reasoning-empty",wd="Blended score steps are not available until at least two sources return parseable evidence.",Rd="No per-source scoring signals are available to show a reasoning chain.";function bi(e,t){return t?{mode:"empty",detail:wd}:e.score.sources.filter(r=>r.signalStrength!==null).length===0?{mode:"empty",detail:Rd}:{mode:"chain",chain:e.chain,sourceIds:e.score.sources.map(r=>r.sourceId)}}function Od(e,t){const n=t.createElement("section");n.className=Id,n.setAttribute("aria-label",Ad);const r=t.createElement("p");if(r.className=Td,r.textContent=Lr,n.appendChild(r),e.mode==="empty"){const a=t.createElement("p");return a.className=Nd,a.setAttribute("role","note"),a.textContent=e.detail,n.appendChild(a),n}const o=t.createElement("ol");o.className=_d;for(const a of e.chain.sourceLines){const i=t.createElement("li");i.className=xd,i.textContent=a,o.appendChild(i)}return n.appendChild(o),n}function Ld(e){return e.map(t=>({sourceId:t.sourceId,sourceLabel:t.label,status:t.status,summary:t.status==="ok"?t.detail:void 0}))}function kd(e,t={}){return qd(Ld(e),t)}function Dd(e,t={}){const n=kd(e,t);return{score:n,summaryText:Sd(n),chain:Cd(n)}}const ln="Risk score unavailable",Pd="Enable at least one enrichment source in settings to compute a local advisory score.",Md="At least two enabled sources must return parseable evidence for a blended composite score. Review per-source details below.";function Hd(e){return e.compositeSignal!==null}function Si(e,t,n={}){if(Rr(e))return{mode:"unavailable",headline:ln,detail:Pd};if(t.length===0)return null;const r=Dd(t,n);return{mode:"score",view:r,insufficientCompositeNotice:Hd(r.score)?null:Md}}const Vd=/^(\d+)\s+abuse\s+confidence$/,Ud=/^(\d+)\s+reports$/,Fd=/^1\s+threat\s+pulse$/,$d=/^(\d+)\s+threat\s+pulses$/,Bd=Object.fromEntries(I.map(e=>[e,e===g.OTX?.85:1])),Gd=2;function Ne(e){return Number.isFinite(e)?Math.min(100,Math.max(0,e)):0}function zd(e){if(!e)return null;const t=e.trim();let n=Vd.exec(t);if(n)return Ne(Number(n[1]));if(n=Ud.exec(t),n){const r=Number(n[1]);return Ne(Kd(r))}if(Fd.test(t))return Ne(zo(1));if(n=$d.exec(t),n){const r=Number(n[1]);return Ne(zo(r))}return null}function Kd(e){return e<=0?0:e===1?22:e<=3?38:e<=8?54:e<=20?68:e<=45?82:Math.min(100,88+Math.floor((e-45)/30))}function zo(e){return e<=0?0:e===1?26:e<=4?42:e<=12?56:e<=35?71:Math.min(100,78+Math.min(22,Math.floor((e-35)/8)))}function Ko(e){if(e===null||!Number.isFinite(e))return null;const t=Ne(e);return t<=24?V.LOW:t<=49?V.SUSPICIOUS:t<=74?V.HIGH:V.CRITICAL}function Yd(e,t){const n=t?.[e];return typeof n=="number"&&Number.isFinite(n)?Math.max(0,n):Bd[e]}function Wd(e,t){if(t.length<2)return!1;if(Math.max(...t)-Math.min(...t)>=35)return!0;const n=e.map(o=>o.bandLabel).filter(o=>o!==null);if(n.length<2)return!1;const r=n.map(jd);return Math.max(...r)-Math.min(...r)>=2}function jd(e){switch(e){case V.LOW:return 0;case V.SUSPICIOUS:return 1;case V.HIGH:return 2;case V.CRITICAL:return 3;default:return 0}}function qd(e,t={}){const n=t.weights??{},r=[];let o=0,a=0;const i=[];for(const h of e){const E=Yd(h.sourceId,n);let x=null,P=null;E>0&&h.status===sn.OK&&h.summary&&(x=zd(h.summary),P=x===null?null:Ko(x),x!==null&&(o+=x*E,a+=E,i.push(x))),r.push({sourceId:h.sourceId,sourceLabel:h.sourceLabel,status:h.status,weight:E,signalStrength:x,bandLabel:P})}const s=i.length>=Gd;let l=null;a>0&&s&&(l=Ne(o/a));const u=l!==null&&a>0?Ko(l):null,d=l===null||a===0||u===null?V.UNKNOWN:u,f=s&&l!==null&&Wd(r,i);return{label:d,compositeSignal:l,disagreement:f,sources:r}}const Xd="Vera5 IOC Summary",Ci="Source Summary",Ai="Analyst notes",Jd=1,kr="No enrichment source results are available to compute a local advisory score.",Qd={ipv4:"IPv4 address",domain:"Domain",url:"URL",md5:"MD5 hash",sha1:"SHA1 hash",sha256:"SHA256 hash",cve:"CVE ID"};function Zd(e){return Qd[e]}function ep(e,t){const n=t?.trim();if(n)return n;const r=ct(e).trim();return r.length>0?r:void 0}function tp(e){return e.map(t=>({sourceId:t.sourceId,name:t.label,status:t.status,summary:t.detail,tags:(t.tags??[]).map(n=>n.trim()).filter(n=>n.length>0),fromCache:t.fromCache,lastUpdatedLine:t.lastUpdatedLine,badgeText:t.badgeText}))}function np(e,t){const n=Si(e,t);if(!n)return null;if(n.mode==="unavailable")return{mode:"unavailable",headline:n.headline,detail:n.detail,disagreement:!1,reasoningLines:[]};const r=bi(n.view,n.insufficientCompositeNotice),o=r.mode==="chain"?r.chain.sourceLines:[],a=r.mode==="empty"?r.detail:void 0,i=n.view.score.disagreement,s=i?Ei:void 0,l={label:n.view.score.label,summaryText:n.view.summaryText,compositeSignal:n.view.score.compositeSignal,disagreement:i,disagreementNotice:s,reasoningLines:o,reasoningEmptyDetail:a};return n.insufficientCompositeNotice?{mode:"insufficient",...l,insufficientDetail:n.insufficientCompositeNotice}:{mode:"available",...l}}function Ii(e){const t=e.sourceResults??[],n=e.disabledSources??[],r=ui(t.map(s=>({sourceId:s.sourceId,sourceLabel:s.label,status:s.status,summary:s.status==="ok"?s.detail:void 0,tags:s.tags,fromCache:s.fromCache,errorCode:s.errorCode,errorMessage:s.status==="error"?s.detail:void 0,retryHint:s.retryHint,rawVendorJson:s.rawVendorJson}))),o=e.enrichmentState??r.enrichmentState,a=e.summary?.trim()||r.summary?.trim(),i=(e.tags??r.tags??[]).map(s=>s.trim()).filter(s=>s.length>0);return{ioc:e.value.trim(),iocType:e.iocType,iocTypeLabel:Zd(e.iocType),enrichmentState:o,summary:a||void 0,tags:i,sources:tp(t),disabledSources:[...n],riskScore:np(n,t),analystNotes:ep(e.value,e.analystNotes),pivots:ld(e.iocType,e.value),exportedAt:e.exportedAt??new Date().toISOString()}}function St(e){return e?.mode==="available"||e?.mode==="insufficient"}function rp(e){return e.riskScore?.mode==="unavailable"?["",e.riskScore.headline,"",e.riskScore.detail]:e.riskScore===null?["",ln,"",kr]:[]}function op(e){const{riskScore:t}=e;if(!St(t))return[];const n=["",`Risk score: ${t.summaryText}`];if(t.mode==="insufficient"&&n.push("",t.insufficientDetail),n.push("",`### ${Lr}`,""),t.reasoningLines.length>0)for(let r=0;r<t.reasoningLines.length;r+=1)n.push(`${r+1}. ${t.reasoningLines[r]}`);else t.reasoningEmptyDetail&&n.push(t.reasoningEmptyDetail);return t.disagreement&&t.disagreementNotice&&n.push("",t.disagreementNotice),n}function Ti(e){const t=op(e);return t.length>0?t:rp(e)}function _i(e){let t=`- ${e.name} (${e.badgeText}): ${e.summary}`;return e.tags.length>0&&(t+=` [${e.tags.join(", ")}]`),e.lastUpdatedLine&&(t+=` — ${e.lastUpdatedLine}`),t}function ap(e){const t=[];if(e.sources.length===1){const n=e.sources[0];t.push(ri({sourceLabel:n.name,fromCache:n.fromCache},e.enrichmentState)),n.summary&&t.push(n.summary),n.tags.length>0&&t.push(`Tags: ${n.tags.join(", ")}`),n.lastUpdatedLine&&t.push(n.lastUpdatedLine)}else if(e.sources.length>1)for(const n of e.sources)t.push(_i(n));for(const n of wr(e.disabledSources))t.push(`- ${n.label}: ${n.message}`);return t.length===0?[]:["",`### ${Ci}`,"",...t]}function ip(e){return e.analystNotes?["",`### ${Ai}`,"",e.analystNotes]:[]}function Ct(e){const t=[`## ${Xd}`,"",`IOC: ${e.ioc}`,`Type: ${e.iocTypeLabel}`];return e.summary&&t.push("",`Summary: ${e.summary}`),e.tags.length>0&&t.push("",`Tags: ${e.tags.join(", ")}`),t.push(...Ti(e)),t.push(...ap(e)),t.push(...ip(e)),t.push(""),t.join(`
`)}function sp(e){return e.sources.map(t=>({sourceId:t.sourceId,name:t.name,status:t.status,summary:t.summary,tags:[...t.tags],fromCache:t.fromCache,lastUpdatedLine:t.lastUpdatedLine,badgeText:t.badgeText}))}function cp(e){const{riskScore:t}=e;return t?t.mode==="unavailable"?{mode:"unavailable",headline:t.headline,detail:t.detail}:t.mode==="insufficient"?{mode:"insufficient",label:t.label,summaryText:t.summaryText,compositeSignal:t.compositeSignal,reasoningLines:[...t.reasoningLines],reasoningEmptyDetail:t.reasoningEmptyDetail,insufficientDetail:t.insufficientDetail}:{mode:"available",label:t.label,summaryText:t.summaryText,compositeSignal:t.compositeSignal,reasoningLines:[...t.reasoningLines],reasoningEmptyDetail:t.reasoningEmptyDetail}:{mode:"none",headline:ln,detail:kr}}function lp(e){return St(e.riskScore)?{disagreement:e.riskScore.disagreement,disagreementNotice:e.riskScore.disagreementNotice}:{disagreement:!1}}function xi(e){const t=lp(e),n={schemaVersion:Jd,exportedAt:e.exportedAt,ioc:e.ioc,iocType:e.iocType,iocTypeLabel:e.iocTypeLabel,enrichmentState:e.enrichmentState,summary:e.summary,tags:[...e.tags],sources:sp(e),disabledSources:[...e.disabledSources],score:cp(e),disagreement:t.disagreement,disagreementNotice:t.disagreementNotice,pivots:e.pivots};return e.analystNotes&&(n.analystNotes=e.analystNotes),n}function Ni(e,t=!0){return JSON.stringify(xi(e),null,t?2:void 0)}async function up(e){return j(Ni(e))}async function dp(e){return j(Ct(e))}function wi(e){return Ct(e).replace(/^## /gm,"").replace(/^### /gm,"")}async function pp(e){return j(wi(e))}const fp=`

---

`;function mp(e){return e.map(t=>Ct(t)).join(fp)}function Ri(e,t=!0){return JSON.stringify(e.map(n=>xi(n)),null,t?2:void 0)}async function hp(e){return e.length===0?!1:j(Ri(e))}function gp(e,t,n){const r=e==="markdown"?"md":"json",o=n.replace(/[:.]/g,"-");return`vera5-tray-export-${t}-iocs-${o}.${r}`}function vp(e,t,n=document){if(e.length===0)return;const r=e[0]?.exportedAt??new Date().toISOString(),o=t==="markdown"?mp(e):Ri(e),a=t==="markdown"?"text/markdown":"application/json",i=new Blob([o],{type:a}),s=URL.createObjectURL(i),l=n.createElement("a");l.href=s,l.download=gp(t,e.length,r),l.click(),URL.revokeObjectURL(s)}function Ep(e){const t=e.replace(/[^a-zA-Z0-9._-]+/g,"_").replace(/^_+|_+$/g,"");return t.length>0?t.slice(0,80):"ioc"}function yp(e,t){const n=t==="markdown"?"md":t==="json"?"json":"txt",r=e.exportedAt.replace(/[:.]/g,"-");return`vera5-${Ep(e.ioc)}-${r}.${n}`}function bp(e,t){return t==="json"?{content:Ni(e),mimeType:"application/json"}:t==="markdown"?{content:Ct(e),mimeType:"text/markdown"}:{content:wi(e),mimeType:"text/plain"}}function Sp(e,t,n=document){const{content:r,mimeType:o}=bp(e,t),a=new Blob([r],{type:o}),i=URL.createObjectURL(a),s=n.createElement("a");s.href=i,s.download=yp(e,t),s.click(),URL.revokeObjectURL(i)}const Oi=["jira-comment","thehive-case-note","analyst-update","obsidian-note","markdown-report","csv-row"],Cp={"jira-comment":"Jira comment","thehive-case-note":"TheHive case note","analyst-update":"Analyst update","obsidian-note":"Obsidian note","markdown-report":"Markdown report","csv-row":"CSV rows"},Ap=`

---

`;function Ip(){return[...Oi]}function lt(e){return Cp[e]}function Kn(e){return typeof e=="string"&&Oi.includes(e)}function Tp(e){return St(e.riskScore)?e.riskScore.summaryText:e.riskScore?.mode==="unavailable"?e.riskScore.headline:ln}function _p(e){return St(e.riskScore)?e.riskScore.reasoningLines.join(`
`):kr}function xp(e){const t=[];if(e.sources.length===1){const n=e.sources[0];t.push(`${n.name}: ${n.summary}`),n.tags.length>0&&t.push(`Tags: ${n.tags.join(", ")}`),n.lastUpdatedLine&&t.push(n.lastUpdatedLine)}else if(e.sources.length>1)for(const n of e.sources)t.push(_i(n));for(const n of wr(e.disabledSources))t.push(`${n.label}: ${n.message}`);return t.length===0?"No enrichment source results available.":t.join(`
`)}function Np(e){return St(e.riskScore)?e.riskScore.disagreementNotice??"":""}function Li(e){return{ioc:e.ioc,iocType:e.iocType,iocTypeLabel:e.iocTypeLabel,summary:e.summary??"",tags:e.tags.join(", "),scoreSummary:Tp(e),scoreReasoning:_p(e),sourcesBlock:xp(e),analystNotes:e.analystNotes??"",exportedAt:e.exportedAt,disagreementNotice:Np(e)}}function wp(e){const t=[`h3. Vera5 IOC triage — ${e.ioc}`,"",`*Type:* ${e.iocTypeLabel}`];return e.summary&&t.push(`*Summary:* ${e.summary}`),e.tags&&t.push(`*Tags:* ${e.tags}`),t.push(`*Risk score:* ${e.scoreSummary}`),e.disagreementNotice&&t.push(`*Sources disagree:* ${e.disagreementNotice}`),t.push("","h4. Source summary","",e.sourcesBlock),e.scoreReasoning&&t.push("","h4. Score reasoning","",e.scoreReasoning),e.analystNotes&&t.push("","h4. Analyst notes","",e.analystNotes),t.push("",`_Exported ${e.exportedAt} via Vera5._`),t.join(`
`)}function Rp(e){const t=[`[Vera5] ${e.ioc} (${e.iocTypeLabel})`,"",`Summary: ${e.summary||"No enrichment summary available."}`,`Risk score: ${e.scoreSummary}`];return e.disagreementNotice&&t.push(`Sources disagree: ${e.disagreementNotice}`),t.push("","Sources:",e.sourcesBlock),e.analystNotes&&t.push("","Analyst notes:",e.analystNotes),t.push("",`Exported ${e.exportedAt} via Vera5.`),t.join(`
`)}function Yo(e){const t=e.summary?`Summary: ${e.summary}. `:"",n=e.tags?`Tags: ${e.tags}. `:"",r=e.disagreementNotice?`Sources disagree: ${e.disagreementNotice}. `:"";let o=`Vera5 triage for ${e.ioc} (${e.iocTypeLabel}). ${t}${n}Risk score: ${e.scoreSummary}. ${r}`.trim();return e.analystNotes&&(o+=` Analyst notes: ${e.analystNotes}`),o}function Op(e,t){const n=["---",`ioc: ${t.ioc}`,`ioc_type: ${t.iocType}`,`exported_at: ${t.exportedAt}`,"source: Vera5","---","",`# Vera5 IOC — ${t.ioc}`,"",`- Type: ${t.iocTypeLabel}`];return t.summary&&n.push(`- Summary: ${t.summary}`),t.tags&&n.push(`- Tags: ${t.tags}`),n.push(`- Risk score: ${t.scoreSummary}`),t.disagreementNotice&&n.push(`- Sources disagree: ${t.disagreementNotice}`),n.push("",`## ${Ci}`,"",t.sourcesBlock),n.push(...Ti(e)),t.analystNotes&&n.push("",`## ${Ai}`,"",t.analystNotes),n.join(`
`)}function ae(e){return/[",\n\r]/.test(e)?`"${e.replace(/"/g,'""')}"`:e}function ki(e){const t=Li(e);return[ae(t.ioc),ae(t.iocType),ae(t.summary),ae(t.scoreSummary),ae(t.tags),ae(t.sourcesBlock.replace(/\n/g," | ")),ae(t.analystNotes),ae(t.exportedAt)].join(",")}const Lp="ioc,ioc_type,summary,risk_score,tags,sources,analyst_notes,exported_at";function kp(e,t){if(e==="markdown-report")return Ct(t);if(e==="csv-row")return ki(t);const n=Li(t);switch(e){case"jira-comment":return wp(n);case"thehive-case-note":return Rp(n);case"analyst-update":return Yo(n);case"obsidian-note":return Op(t,n);default:return Yo(n)}}function Di(e,t){return t.length===0?"":e==="csv-row"?[Lp,...t.map(n=>ki(n))].join(`
`):t.map(n=>kp(e,n)).join(Ap)}function Dp(e){return e==="csv-row"?"text/csv":e==="obsidian-note"||e==="markdown-report"||e==="jira-comment"?"text/markdown":"text/plain"}function Pp(e){return e==="csv-row"?"csv":e==="obsidian-note"||e==="markdown-report"||e==="jira-comment"?"md":"txt"}function Mp(e,t,n){const r=n.replace(/[:.]/g,"-"),o=Pp(e);return`vera5-tray-${e}-${t}-iocs-${r}.${o}`}function Dr(e,t,n=document){if(t.length===0)return;const r=t[0]?.exportedAt??new Date().toISOString(),o=Di(e,t),a=new Blob([o],{type:Dp(e)}),i=URL.createObjectURL(a),s=n.createElement("a");s.href=i,s.download=Mp(e,t.length,r),n.body.appendChild(s),s.click(),s.remove(),URL.revokeObjectURL(i)}async function Pr(e,t){return t.length===0?!1:j(Di(e,t))}const Hp="soc",Vp="cti",Up="dfir",Fp=[Hp,Vp,Up];function $p(e){return typeof e=="string"&&Fp.includes(e)}function Bp(e){if(typeof e!="string")return"";const t=e.trim().toLowerCase();return $p(t)?t:""}function Pi(e){return Kn(e)?e:"analyst-update"}function Mi(e){if(!Array.isArray(e))return[];const t=[],n=new Set;for(const r of e){if(typeof r!="string"||n.has(r)||!Object.values(y).includes(r))continue;const o=r;n.add(o),t.push(o)}return t}function Gp(){return{domains:[],cidrRanges:[],vendorLabels:[]}}function zp(e){if(e===null||typeof e!="object"||Array.isArray(e))return null;const t=e;if(typeof t.label!="string"||typeof t.pattern!="string")return null;const n=t.label.trim(),r=Sr(t.pattern);return!n||!r?null:{label:n,pattern:r}}function Hi(e){if(!Array.isArray(e))return[];const t=[],n=new Set;for(const r of e){const o=zp(r);if(!o)continue;const a=`${o.label.toLowerCase()}::${o.pattern}`;n.has(a)||(n.add(a),t.push(o))}return t}function Ut(e){const t=e.split(".");if(t.length!==4)return null;let n=0;for(const r of t){if(!/^\d+$/.test(r))return null;const o=Number(r);if(!Number.isInteger(o)||o<0||o>255)return null;n=(n<<8)+o}return n>>>0}function Kp(e){const t=e.trim();if(!t)return null;const n=t.indexOf("/");if(n===-1)return Ut(t)===null?null:`${t}/32`;const r=t.slice(0,n).trim(),o=t.slice(n+1).trim(),a=Number(o);return Ut(r)===null||!Number.isInteger(a)||a<0||a>32?null:`${r}/${a}`}function Vi(e){if(!Array.isArray(e))return[];const t=[],n=new Set;for(const r of e){if(typeof r!="string")continue;const o=Kp(r);!o||n.has(o)||(n.add(o),t.push(o))}return t}function Yp(e){return{domains:Re(e.domains),cidrRanges:Vi(e.cidrRanges),vendorLabels:Hi(e.vendorLabels)}}function Wp(e,t){const n=Ut(e.trim());if(n===null)return!1;const r=t.indexOf("/");if(r===-1)return!1;const o=Ut(t.slice(0,r).trim()),a=Number(t.slice(r+1));if(o===null||!Number.isInteger(a)||a<0||a>32)return!1;if(a===0)return!0;const i=a===32?4294967295:-1<<32-a>>>0;return(n&i)===(o&i)}function jp(e){try{return new URL(e).hostname.trim().toLowerCase()||null}catch{return null}}function Wo(e,t){return $n(e,t.domains)?!0:t.vendorLabels.some(n=>Ja(e,n.pattern))}function qp(e,t,n){if(t===p.IPV4)return n.cidrRanges.some(r=>Wp(e,r));if(t===p.DOMAIN)return Wo(e,n);if(t===p.URL){const r=jp(e);return r?Wo(r,n):!1}return!1}function Xp(e){return e.domains.length>0||e.cidrRanges.length>0||e.vendorLabels.length>0}const Pe=2,Jp=3600,un="extensionEnabled",dn="highlightEnabled",se="settingsSchemaVersion",Mr="autoScanEnabled",Hr="manualOnlyMode",Vr="includePrivateIpv4",ut="apiKeys",dt="enrichmentSourceEnabled",Me="iocTypeEnabled",Ur="enrichmentCacheTtlSeconds",Fr="enrichmentSourceCacheTtlSeconds",$r="showDisabledSourcesInWorkspace",Ee="showPreQueryNotices",pn="preQueryNoticePreferenceConfigured",Br="installQuickStartCompleted",ye="domainPolicyMode",be="domainAllowlist",X="domainDenylist",Se="domainPolicyEnrichGateEnabled",Oe="internalAssetEnrichGateEnabled",Le="internalAssetDomains",ke="internalAssetCidrRanges",De="internalAssetVendorLabels",Gr="analystModePresetId",He="defaultExportTemplateId",Ve="pivotEmphasisProviders",Ui=[un,dn,se,Mr,Hr,Vr,ut,dt,Me,Ur,$r,Ee,pn,Br,ye,be,X,Se,Oe,Le,ke,De,Gr,He,Ve],Qp=[...Ui,Fr],zr=Jl,Kr=["ipv4","domain","url","md5","sha1","sha256","cve"],Zp=new Set(Kr);function Fi(e){return e===null||typeof e!="object"||Array.isArray(e)?!1:Object.entries(e).every(([t,n])=>du(t)&&typeof n=="string")}function $i(e){return e===null||typeof e!="object"||Array.isArray(e)?!1:Object.entries(e).every(([t,n])=>I.includes(t)&&typeof n=="boolean")}function ef(e){return e===null||typeof e!="object"||Array.isArray(e)?!1:Object.entries(e).every(([t,n])=>I.includes(t)&&typeof n=="number"&&Number.isFinite(n)&&n>=0)}function Bi(e){return e===null||typeof e!="object"||Array.isArray(e)?!1:Object.entries(e).every(([t,n])=>Zp.has(t)&&typeof n=="boolean")}function Gi(){return{}}function zi(){const e={};for(const t of I)e[t]=!1;return e}function Ki(){return{}}function Yi(){const e={};for(const t of Kr)e[t]=!0;return e}function tf(){return{extensionEnabled:!0,highlightEnabled:!0,settingsSchemaVersion:Pe,autoScanEnabled:!1,manualOnlyMode:!0,includePrivateIpv4:!1,apiKeys:Gi(),enrichmentSourceEnabled:zi(),iocTypeEnabled:Yi(),enrichmentCacheTtlSeconds:Jp,enrichmentSourceCacheTtlSeconds:Ki(),showDisabledSourcesInWorkspace:!1,showPreQueryNotices:!0,preQueryNoticePreferenceConfigured:!1,installQuickStartCompleted:!1,domainPolicyMode:Fn().mode,domainAllowlist:[],domainDenylist:[...Fn().denylist],domainPolicyEnrichGateEnabled:!0,internalAssetEnrichGateEnabled:!0,internalAssetDomains:[],internalAssetCidrRanges:[],internalAssetVendorLabels:[],analystModePresetId:"",defaultExportTemplateId:"analyst-update",pivotEmphasisProviders:[]}}function nf(e){if(!ef(e))return Ki();const t={};for(const[n,r]of Object.entries(e))I.includes(n)&&(t[n]=Math.floor(r));return t}function B(e,t){return e===void 0?t:!!e}function Ft(e,t){return typeof e!="number"||!Number.isFinite(e)||e<0?t:Math.floor(e)}function rf(e,t){if(typeof e=="number"&&Number.isFinite(e)&&e>=0)return Math.floor(e);if(typeof e=="string"&&e.trim()!==""){const n=Number.parseInt(e,10);if(Number.isFinite(n)&&n>=0)return n}return t}function of(e){if(!Fi(e))return Gi();const t={};for(const n of zr){const r=e[n];typeof r=="string"&&r.length>0&&(t[n]=r)}return t}function af(e){const t=zi();if(!$i(e))return t;const n={...t};for(const r of I){const o=e[r];typeof o=="boolean"&&(n[r]=o)}return n}function Wi(e){const t=Yi();if(!Bi(e))return t;const n={...t};for(const r of Kr){const o=e[r];typeof o=="boolean"&&(n[r]=o)}return n}function sf(e){const t=tf();return{extensionEnabled:B(e[un],t.extensionEnabled),highlightEnabled:B(e[dn],t.highlightEnabled),settingsSchemaVersion:Ft(e[se],t.settingsSchemaVersion),autoScanEnabled:B(e[Mr],t.autoScanEnabled),manualOnlyMode:B(e[Hr],t.manualOnlyMode),includePrivateIpv4:B(e[Vr],t.includePrivateIpv4),apiKeys:of(e[ut]),enrichmentSourceEnabled:af(e[dt]),iocTypeEnabled:Wi(e[Me]),enrichmentCacheTtlSeconds:rf(e[Ur],t.enrichmentCacheTtlSeconds),enrichmentSourceCacheTtlSeconds:nf(e[Fr]),showDisabledSourcesInWorkspace:B(e[$r],t.showDisabledSourcesInWorkspace),showPreQueryNotices:B(e[Ee],t.showPreQueryNotices),preQueryNoticePreferenceConfigured:B(e[pn],t.preQueryNoticePreferenceConfigured),installQuickStartCompleted:B(e[Br],t.installQuickStartCompleted),domainPolicyMode:qa(e[ye]),domainAllowlist:Re(e[be]),domainDenylist:e[X]===void 0?[...t.domainDenylist]:Re(e[X]),domainPolicyEnrichGateEnabled:B(e[Se],t.domainPolicyEnrichGateEnabled),internalAssetEnrichGateEnabled:B(e[Oe],t.internalAssetEnrichGateEnabled),internalAssetDomains:Re(e[Le]),internalAssetCidrRanges:Vi(e[ke]),internalAssetVendorLabels:Hi(e[De]),analystModePresetId:Bp(e[Gr]),defaultExportTemplateId:Pi(e[He]),pivotEmphasisProviders:Mi(e[Ve])}}function cf(e){const t=Ft(e[se],0),n={...e};if(t<2){const r=n[X];(r===void 0||Array.isArray(r)&&r.length===0)&&(n[X]=[...Xa]),n[se]=2}return Ft(n[se],0)>=Pe?n:{...n,[se]:Pe}}function lf(e){return{[un]:e.extensionEnabled,[dn]:e.highlightEnabled,[se]:e.settingsSchemaVersion,[Mr]:e.autoScanEnabled,[Hr]:e.manualOnlyMode,[Vr]:e.includePrivateIpv4,[ut]:e.apiKeys,[dt]:e.enrichmentSourceEnabled,[Me]:e.iocTypeEnabled,[Ur]:e.enrichmentCacheTtlSeconds,[Fr]:e.enrichmentSourceCacheTtlSeconds,[$r]:e.showDisabledSourcesInWorkspace,[Ee]:e.showPreQueryNotices,[pn]:e.preQueryNoticePreferenceConfigured,[Br]:e.installQuickStartCompleted,[ye]:e.domainPolicyMode,[be]:e.domainAllowlist,[X]:e.domainDenylist,[Se]:e.domainPolicyEnrichGateEnabled,[Oe]:e.internalAssetEnrichGateEnabled,[Le]:e.internalAssetDomains,[ke]:e.internalAssetCidrRanges,[De]:e.internalAssetVendorLabels,[Gr]:e.analystModePresetId,[He]:e.defaultExportTemplateId,[Ve]:e.pivotEmphasisProviders}}function uf(e){if(Ft(e[se],0)!==Pe||e[ut]!==void 0&&!Fi(e[ut])||e[dt]!==void 0&&!$i(e[dt])||e[Me]!==void 0&&!Bi(e[Me]))return!0;for(const t of Ui)if(e[t]===void 0)return!0;return!1}async function fn(){const e=await chrome.storage.local.get(Qp),t=cf(e),n=sf(t);if(uf(e)){const r=lf({...n,settingsSchemaVersion:Pe});await chrome.storage.local.set(r)}return{...n,settingsSchemaVersion:Pe}}async function df(){return(await fn()).extensionEnabled}async function pf(e){await chrome.storage.local.set({[un]:e})}async function ff(){return(await fn()).highlightEnabled}async function mf(e){await chrome.storage.local.set({[dn]:e})}function hf(e){return I.filter(t=>e[t]!==!0)}async function gf(e){await chrome.storage.local.set({[Ee]:e,[pn]:!0})}const Yn="autoScanEnabled";async function vf(){const t=(await k(Yn))[Yn];return t===void 0?!1:!!t}async function Ef(){const e=await k([ye,be,X]),t=Fn();return e[ye]===void 0&&e[be]===void 0&&e[X]===void 0?t:Vl({mode:e[ye]??t.mode,allowlist:e[be]??t.allowlist,denylist:e[X]??t.denylist})}async function yf(){const e=await k(Se);return e[Se]===void 0?!0:e[Se]===!0}function bf(e=document){return e.location.hostname.trim().toLowerCase()}async function Yr(e=document){const t=await Ef();return Ul(bf(e),t)}async function Sf(e=document){const t=await yf();return t?Yr(e):!0}async function Cf(e=document){return await vf()?Yr(e):!1}const Af=[ye,be,X,Se,Yn],Wn="highlightEnabled";async function If(){const t=(await k(Wn))[Wn];return t===void 0?!0:!!t}const jo="includePrivateIpv4";async function Tf(){const t=(await k(jo))[jo];return t===void 0?!1:!!t}const qo=Me;async function _f(){const e=await k(qo);return Wi(e[qo])}const le={CONTENT_REGISTER:"CONTENT_REGISTER",SCAN_PAGE:"SCAN_PAGE",SCAN_SELECTION:"SCAN_SELECTION",ENRICH_SELECTION:"ENRICH_SELECTION",NAVIGATE_TO_IOC_ANCHOR:"NAVIGATE_TO_IOC_ANCHOR",TOGGLE_WORKSPACE:"TOGGLE_WORKSPACE",OPEN_WORKSPACE:"OPEN_WORKSPACE",TOGGLE_COMMAND_PALETTE:"TOGGLE_COMMAND_PALETTE"};const Xo=2500,Vn={skipScript:!0,skipStyle:!0,skipTextarea:!0},xf=new Set(["head","link","meta","noscript","template","title"]);function mn(e={}){return{skipScript:e.skipScript??Vn.skipScript,skipStyle:e.skipStyle??Vn.skipStyle,skipTextarea:e.skipTextarea??Vn.skipTextarea}}function Nf(e,t={}){const n=mn(t),r=e.tagName.toLowerCase();return!!(n.skipScript&&r==="script"||n.skipStyle&&r==="style"||n.skipTextarea&&r==="textarea"||xf.has(r))}function ji(e,t,n={}){const r=mn(n);let o=e;for(;o&&o!==t;){if(o.nodeType===Node.ELEMENT_NODE&&Nf(o,r))return!0;o=o.parentNode}return!1}function jn(e,t,n={}){return(e.textContent??"").trim().length===0?!1:!ji(e,t,n)}function wf(e={}){const t=e.maxTextNodes??Xo;return!Number.isFinite(t)||t<1?Xo:Math.floor(t)}function Rf(e,t={}){const n=mn(t),r=wf(t),a=(e.ownerDocument??document).createTreeWalker(e,NodeFilter.SHOW_TEXT),i=[];let s=!1,l=a.nextNode();for(;l;){if(jn(l,e,n)&&(i.push(l),i.length>=r)){let u=a.nextNode();for(;u;){if(jn(u,e,n)){s=!0;break}u=a.nextNode()}break}l=a.nextNode()}return{nodes:i,textNodesScanned:i.length,textNodeCap:r,capReached:s}}function Of(e,t){if(!e.isConnected)return!1;const r=(e.ownerDocument??document).createRange();try{r.selectNodeContents(e)}catch{return!1}return t.compareBoundaryPoints(Range.END_TO_START,r)<0&&t.compareBoundaryPoints(Range.START_TO_END,r)>0}function qi(e,t={}){const n=Rf(e,t);let r=0;return{blocks:n.nodes.map(a=>{const i=a.textContent??"",s={node:a,text:i,blockStart:r};return r+=i.length,s}),textNodesScanned:n.textNodesScanned,textNodeCap:n.textNodeCap,capReached:n.capReached}}function Lf(e,t){return t?t[e]!==!1:!0}const Jo={url:0,sha256:1,sha1:2,md5:3,cve:4,ipv4:5,domain:6};function kf(e,t){return e.start<t.end&&e.end>t.start}function Df(e,t,n){return n.some(r=>e<r.end&&t>r.start)}function Pf(e){return`${e.start}:${e.end}:${e.type}:${e.value}`}function Mf(e){const t=new Map;for(const o of e)t.set(Pf(o),o);const n=[...t.values()].sort((o,a)=>{const i=Jo[o.type]-Jo[a.type];return i!==0?i:o.start!==a.start?o.start-a.start:a.end-o.end}),r=[];for(const o of n){const a={start:o.start,end:o.end},i=r.findIndex(u=>kf(a,u));if(i===-1){r.push({...o,ignoredOverlaps:o.ignoredOverlaps?[...o.ignoredOverlaps]:[]});continue}const s=r[i],l=[...s.ignoredOverlaps??[]];l.push({type:o.type,value:o.value,ruleId:o.ruleId}),r[i]={...s,ignoredOverlaps:l}}return r.sort((o,a)=>o.start-a.start)}function Wr(e,t={}){const n=[],r=[],o=Ba(e);for(const i of o)n.push(i),r.push({start:i.start,end:i.end});for(const i of Ua(e,r))n.push(i),r.push({start:i.start,end:i.end});for(const i of Fa(e,r))n.push(i),r.push({start:i.start,end:i.end});for(const i of $a(e,t))Df(i.start,i.end,r)||(n.push(i),r.push({start:i.start,end:i.end}));for(const i of Ga(e,r))n.push(i),r.push({start:i.start,end:i.end});const a=Mf(n);return t.enabledTypes?a.filter(i=>Lf(i.type,t.enabledTypes)):a}function Hf(e=document.body,t={}){return Xi(e,t).matches}function Xi(e=document.body,t={}){const n=typeof performance<"u"?performance.now():0,r=t.ioc??{},o=t.walker??{},a=qi(e,o),i=[];for(const l of a.blocks){const u=Wr(l.text,r);for(const d of u)i.push({...d,textNode:l.node})}const s=typeof performance<"u"?performance.now():0;return{matches:i,profile:{textNodesScanned:a.textNodesScanned,textNodeCap:a.textNodeCap,capReached:a.capReached,durationMs:Math.max(0,s-n)}}}function Vf(e,t){let n=e.commonAncestorContainer;return n.nodeType===Node.TEXT_NODE&&(n=n.parentNode??t),n}function Uf(e,t=document.body,n={}){const r=typeof performance<"u"?performance.now():0,o=n.ioc??{},a=n.walker??{},i=mn(a),s=Vf(e,t),l=qi(s,a),u=[];let d=0;for(const h of l.blocks){if(!Of(h.node,e)||!jn(h.node,t,i)||ji(h.node,t,i))continue;d+=1;const E=Wr(h.text,o);for(const x of E)u.push({...x,textNode:h.node})}const f=typeof performance<"u"?performance.now():0;return{matches:u,profile:{textNodesScanned:d,textNodeCap:l.textNodeCap,capReached:!1,durationMs:Math.max(0,f-r)}}}const Qo="vera5-ui-styles",Ff={empty:"vera5-hover-card-enrichment--empty",loading:"vera5-hover-card-enrichment--loading",error:"vera5-hover-card-enrichment--error",ready:"vera5-hover-card-enrichment--ready"};function $f(e,t="vera5-hover-card-enrichment"){return`${t} ${Ff[e]}`}function Bf(){return`
.vera5-hover-card-panel {
  --vera5-surface: #12171e;
  --vera5-text: #f5f7fa;
  --vera5-border: #313a45;
  --vera5-accent: #ffb224;
  --vera5-accent-text: #f5f7fa;
  --vera5-muted: #a7b0ba;
  --vera5-muted-label: #a7b0ba;
  --vera5-error: #ff4d5a;
  --vera5-ready: #f5f7fa;
  --vera5-button-bg: #19202a;
  --vera5-copy-success-bg: color-mix(in srgb, #22c7a9 16%, #12171e);
  --vera5-shadow: 0 6px 18px rgba(0, 0, 0, 0.28);
  box-sizing: border-box;
  min-width: 220px;
  max-width: 320px;
  padding: 10px 12px;
  border-radius: 8px;
  border: 1px solid var(--vera5-border);
  background-color: var(--vera5-surface);
  color: var(--vera5-text);
  font-family: system-ui, sans-serif;
  font-size: 13px;
  line-height: 1.45;
  box-shadow: var(--vera5-shadow);
  pointer-events: auto;
  animation: vera5-panel-reveal 0.16s ease-out;
}
@keyframes vera5-panel-reveal {
  from {
    opacity: 0;
    transform: translateY(4px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}
.vera5-hover-card-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  margin-bottom: 8px;
}
.vera5-hover-card-header-actions {
  display: flex;
  align-items: center;
  gap: 6px;
  margin-left: auto;
}
  font-size: 11px;
  font-weight: 600;
  letter-spacing: 0.04em;
  text-transform: uppercase;
  color: var(--vera5-accent);
}
.vera5-hover-card-value {
  margin: 0 0 8px;
  font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
  font-size: 12px;
  word-break: break-all;
}
.vera5-hover-card-value-on-page {
  margin: 0 0 4px;
  font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
  font-size: 12px;
  word-break: break-all;
  color: var(--vera5-text);
}
.vera5-hover-card-refanged-value {
  margin: 0 0 8px;
  font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
  font-size: 11px;
  line-height: 1.45;
  word-break: break-all;
  color: var(--vera5-muted-label);
}
.vera5-hover-card-enrichment {
  margin: 0;
  font-size: 12px;
}
.vera5-hover-card-enrichment--empty,
.vera5-hover-card-enrichment--loading {
  color: var(--vera5-muted);
}
.vera5-hover-card-enrichment--loading {
  font-style: italic;
  animation: vera5-loading-pulse 1.4s ease-in-out infinite;
}
@keyframes vera5-loading-pulse {
  0%,
  100% {
    opacity: 1;
  }
  50% {
    opacity: 0.55;
  }
}
.vera5-hover-card-enrichment--error {
  color: var(--vera5-error);
}
.vera5-hover-card-enrichment--ready {
  color: var(--vera5-ready);
}
.vera5-hover-card-risk-score {
  margin: 8px 0;
}
.vera5-hover-card-risk-score-label {
  margin: 0 0 4px;
  font-size: 11px;
  color: var(--vera5-muted-label);
}
.vera5-hover-card-risk-score-unavailable {
  margin: 0 0 4px;
  font-size: 11px;
  font-weight: 600;
  color: var(--vera5-muted-label);
}
.vera5-hover-card-risk-score-insufficient {
  margin: 0 0 6px;
  font-size: 11px;
  line-height: 1.35;
  color: var(--vera5-muted-label);
}
.vera5-hover-card-risk-score-unavailable-detail {
  margin: 0;
  font-size: 11px;
  line-height: 1.35;
  color: var(--vera5-muted-label);
}
.vera5-hover-card-risk-disagreement {
  margin: 0 0 6px;
  font-size: 11px;
  line-height: 1.35;
  color: var(--vera5-error);
}
.vera5-hover-card-risk-reasoning {
  margin: 0 0 6px;
}
.vera5-hover-card-risk-reasoning-heading {
  margin: 0 0 4px;
  font-size: 10px;
  font-weight: 600;
  letter-spacing: 0.02em;
  text-transform: uppercase;
  color: var(--vera5-muted-label);
}
.vera5-hover-card-risk-reasoning-chain {
  margin: 0;
  padding-left: 18px;
  font-size: 11px;
  line-height: 1.4;
  color: var(--vera5-accent-text);
}
.vera5-hover-card-risk-reasoning-step {
  margin: 0 0 2px;
}
.vera5-hover-card-risk-reasoning-empty {
  margin: 0;
  font-size: 11px;
  line-height: 1.35;
  color: var(--vera5-muted-label);
}
.vera5-hover-card-risk-contributions {
  margin: 0;
  padding: 0;
  list-style: none;
  display: flex;
  flex-wrap: wrap;
  gap: 4px;
}
.vera5-hover-card-risk-contribution {
  margin: 0;
}
.vera5-hover-card-risk-contribution-chip {
  display: inline-flex;
  align-items: center;
  padding: 2px 6px;
  border-radius: 999px;
  border: 1px solid var(--vera5-border);
  background-color: var(--vera5-button-bg);
  color: var(--vera5-accent-text);
  font-size: 10px;
  font-weight: 600;
  line-height: 1.3;
}
.vera5-hover-card-tags {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
  margin-bottom: 8px;
}
.vera5-hover-card-tag {
  display: inline-flex;
  align-items: center;
  padding: 2px 8px;
  border-radius: 999px;
  border: 1px solid var(--vera5-border);
  background-color: var(--vera5-button-bg);
  color: var(--vera5-muted);
  font-size: 10px;
  font-weight: 600;
  line-height: 1.4;
  white-space: nowrap;
}
.vera5-hover-card-attribution {
  margin: 8px 0 0;
  padding-top: 8px;
  border-top: 1px solid var(--vera5-border);
  font-size: 11px;
  line-height: 1.4;
  color: var(--vera5-muted-label);
}
.vera5-hover-card-disclaimer {
  margin: 8px 0 0;
  padding-top: 8px;
  border-top: 1px solid var(--vera5-border);
  font-size: 10px;
  line-height: 1.35;
  color: var(--vera5-muted-label);
}
.vera5-hover-card-disclaimer p {
  margin: 0 0 4px;
}
.vera5-hover-card-disclaimer p:last-child {
  margin-bottom: 0;
}
.vera5-pre-query-disclosure {
  margin-bottom: 8px;
  padding: 8px;
  border: 1px solid var(--vera5-border);
  border-radius: 6px;
  background-color: var(--vera5-button-bg);
}
.vera5-pre-query-disclosure__message {
  margin: 0 0 8px;
  font-size: 11px;
  line-height: 1.45;
  color: var(--vera5-accent-text);
}
.vera5-pre-query-disclosure__remember {
  display: flex;
  align-items: center;
  gap: 6px;
  margin: 0 0 8px;
  font-size: 11px;
  line-height: 1.4;
  color: var(--vera5-muted-label);
  cursor: pointer;
}
.vera5-pre-query-disclosure__actions {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
}
  display: inline-block;
  font-size: 11px;
  font-weight: 600;
  padding: 4px 8px;
  border-radius: 4px;
  border: 1px solid var(--vera5-border);
  background-color: var(--vera5-button-bg);
  color: var(--vera5-accent-text);
  cursor: pointer;
  transition: background-color 0.15s ease, color 0.15s ease;
}
.vera5-hover-card-retry-hint {
  margin: 0;
  font-size: 11px;
  line-height: 1.4;
  color: var(--vera5-muted-label);
}
.vera5-hover-card-copy {
  font-size: 11px;
  font-weight: 600;
  padding: 4px 8px;
  border-radius: 4px;
  border: 1px solid var(--vera5-border);
  background-color: var(--vera5-button-bg);
  color: var(--vera5-accent-text);
  cursor: pointer;
  transition: background-color 0.15s ease, color 0.15s ease;
}
.vera5-hover-card-copy--copied {
  background-color: var(--vera5-copy-success-bg);
}
.vera5-hover-card-pivots {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
}
.vera5-hover-card-pivot-recipes {
  margin-bottom: 8px;
}
.vera5-hover-card-pivot-recipes-list {
  margin: 0;
  padding: 0;
  list-style: none;
}
.vera5-hover-card-pivot-recipe {
  display: flex;
  flex-wrap: wrap;
  align-items: baseline;
  gap: 6px;
  margin-bottom: 6px;
}
.vera5-hover-card-pivot-recipe:last-child {
  margin-bottom: 0;
}
.vera5-hover-card-pivot-recipe-source {
  flex-shrink: 0;
  font-size: 10px;
  font-weight: 700;
  padding: 1px 6px;
  border-radius: 4px;
  background: color-mix(in srgb, var(--vera5-accent) 18%, var(--vera5-button-bg));
  color: var(--vera5-accent-text);
}
.vera5-hover-card-pivot-recipe-guidance {
  flex: 1 1 100%;
  font-size: 11px;
  line-height: 1.4;
  color: var(--vera5-muted);
}
.vera5-hover-card-pivot-link {
  font-size: 11px;
  font-weight: 600;
  padding: 4px 8px;
  border-radius: 4px;
  border: 1px solid var(--vera5-border);
  background-color: var(--vera5-button-bg);
  color: var(--vera5-accent-text);
  text-decoration: none;
  white-space: nowrap;
  transition: background-color 0.15s ease, color 0.15s ease, border-color 0.15s ease;
}
.vera5-hover-card-sources {
  margin-bottom: 8px;
}
.vera5-hover-card-sources-heading {
  margin: 0 0 4px;
  font-size: 10px;
  font-weight: 600;
  letter-spacing: 0.04em;
  text-transform: uppercase;
  color: var(--vera5-muted-label);
}
.vera5-hover-card-section-heading {
  margin: 12px 0 10px;
  font-size: 20px;
  font-weight: 700;
  letter-spacing: 0.04em;
  text-transform: uppercase;
  text-align: center;
  color: var(--vera5-muted-label);
  line-height: 1.05;
}
.vera5-hover-card-intel-summary {
  margin-bottom: 8px;
}
.vera5-hover-card-sources-list {
  margin: 0;
  padding: 0;
  list-style: none;
  display: flex;
  flex-direction: column;
  gap: 4px;
}
.vera5-hover-card-source-item {
  margin: 0;
  display: flex;
  flex-direction: column;
  gap: 2px;
  font-size: 11px;
  color: var(--vera5-muted-label);
  line-height: 1.4;
  padding-bottom: 8px;
  margin-bottom: 8px;
  border-bottom: 1px solid var(--vera5-accent);
}
.vera5-hover-card-source-item:last-child {
  padding-bottom: 0;
  margin-bottom: 0;
  border-bottom: none;
}
.vera5-hover-card-source-badge {
  align-self: flex-start;
  font-size: 10px;
  font-weight: 600;
  letter-spacing: 0.02em;
  padding: 2px 6px;
  border-radius: 4px;
  border: 1px solid var(--vera5-border);
  white-space: nowrap;
}
.vera5-hover-card-source-badge--ok {
  color: #22c7a9;
  background-color: color-mix(in srgb, #22c7a9 16%, #12171e);
  border-color: color-mix(in srgb, #22c7a9 35%, var(--vera5-border));
}
.vera5-hover-card-source-badge--cached {
  color: #a7b0ba;
  background-color: var(--vera5-button-bg);
  border-color: var(--vera5-border);
}
.vera5-hover-card-source-last-updated {
  display: block;
  font-size: 10px;
  color: var(--vera5-muted-label);
  line-height: 1.35;
}
.vera5-hover-card-source-badge--error {
  color: #ff4d5a;
  background-color: color-mix(in srgb, #ff4d5a 14%, #12171e);
  border-color: color-mix(in srgb, #ff4d5a 35%, var(--vera5-border));
}
.vera5-hover-card-source-badge--skipped {
  color: var(--vera5-muted-label);
  background-color: var(--vera5-button-bg);
}
.vera5-hover-card-source-detail {
  display: block;
  color: var(--vera5-text);
}
.vera5-hover-card-raw-json {
  margin-top: 4px;
}
.vera5-hover-card-raw-json summary {
  cursor: pointer;
  font-size: 10px;
  font-weight: 600;
  color: var(--vera5-accent-text);
  list-style-position: outside;
}
.vera5-hover-card-raw-json-body {
  margin: 4px 0 0;
  padding: 6px 8px;
  max-height: 160px;
  overflow: auto;
  border-radius: 4px;
  border: 1px solid var(--vera5-border);
  background-color: var(--vera5-button-bg);
  font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
  font-size: 10px;
  line-height: 1.35;
  white-space: pre-wrap;
  word-break: break-word;
  color: var(--vera5-text);
}
.vera5-why-detected {
  margin-top: 4px;
}
.vera5-why-detected-row {
  margin: 0 0 4px;
  font-size: 11px;
  line-height: 1.45;
  color: var(--vera5-muted-label);
}
.vera5-why-detected-context {
  word-break: break-word;
}
.vera5-why-detected-overlaps-heading {
  margin: 0 0 4px;
  font-size: 11px;
  font-weight: 600;
  color: var(--vera5-muted-label);
}
.vera5-why-detected-list {
  margin: 0;
  padding-left: 16px;
  font-size: 11px;
  line-height: 1.45;
  color: var(--vera5-muted-label);
}
.vera5-why-detected-item {
  margin-bottom: 2px;
  word-break: break-word;
}
.vera5-tray-why-detected {
  width: 100%;
  margin-top: 4px;
  font-size: 11px;
  line-height: 1.45;
  color: var(--vera5-muted-label);
}
.vera5-tray-why-detected summary {
  cursor: pointer;
  color: var(--vera5-accent-text);
  font-weight: 600;
  list-style-position: outside;
}
.vera5-tray-why-detected .vera5-why-detected {
  margin-top: 4px;
}
.vera5-tray-save-collection {
  margin-top: 4px;
}
.vera5-tray-save-collection-toggle {
  border: none;
  background: transparent;
  color: var(--vera5-accent);
  cursor: pointer;
  font-size: 12px;
  font-weight: 600;
  padding: 0;
}
.vera5-tray-save-collection-panel {
  margin-top: 6px;
  padding: 8px 10px;
  border-radius: 6px;
  border: 1px solid var(--vera5-border);
  background: var(--vera5-surface);
}
.vera5-tray-save-collection-heading {
  margin: 0 0 8px;
  font-size: 12px;
  font-weight: 700;
  color: var(--vera5-accent-text);
}
.vera5-tray-save-collection-list {
  display: flex;
  flex-direction: column;
  gap: 4px;
  margin-bottom: 8px;
}
.vera5-tray-save-collection-feedback {
  margin: 8px 0 0;
  font-size: 12px;
  color: var(--vera5-text-muted);
  line-height: 1.4;
}
.vera5-workspace-field-label {
  display: block;
  margin: 0 0 8px;
  font-size: 11px;
  font-weight: 600;
  color: var(--vera5-text-muted);
}
.vera5-workspace-field-label input {
  display: block;
  width: 100%;
  margin-top: 4px;
  box-sizing: border-box;
}
.vera5-hover-card-analyst-notes {
  margin-top: 8px;
}
.vera5-hover-card-analyst-notes-label {
  display: block;
  margin-bottom: 4px;
  font-size: 10px;
  font-weight: 600;
  letter-spacing: 0.04em;
  text-transform: uppercase;
  color: var(--vera5-muted-label);
}
.vera5-hover-card-analyst-notes-input {
  box-sizing: border-box;
  width: 100%;
  min-height: 56px;
  padding: 6px 8px;
  border-radius: 4px;
  border: 1px solid var(--vera5-border);
  background-color: #19202a;
  color: #f5f7fa;
  font-family: inherit;
  font-size: 12px;
  line-height: 1.4;
  resize: vertical;
}
.vera5-hover-card-analyst-notes-input::placeholder {
  color: #6b7480;
}
.vera5-hover-card-analyst-notes-input:focus {
  outline: 2px solid color-mix(in srgb, var(--vera5-accent) 35%, transparent);
  outline-offset: 1px;
}
.vera5-hover-card-ioc-label {
  margin-top: 8px;
}
.vera5-hover-card-ioc-label-label {
  display: block;
  margin-bottom: 4px;
  font-size: 10px;
  font-weight: 600;
  letter-spacing: 0.04em;
  text-transform: uppercase;
  color: var(--vera5-muted-label);
}
.vera5-hover-card-ioc-label-select {
  box-sizing: border-box;
  width: 100%;
  padding: 6px 8px;
  border-radius: 4px;
  border: 1px solid var(--vera5-border);
  background-color: #19202a;
  color: #f5f7fa;
  font-family: inherit;
  font-size: 12px;
  line-height: 1.4;
}
.vera5-hover-card-ioc-label-select:focus {
  outline: 2px solid color-mix(in srgb, var(--vera5-accent) 35%, transparent);
  outline-offset: 1px;
}
.vera5-hover-card-ioc-timeline {
  margin-top: 8px;
}
.vera5-hover-card-ioc-timeline-label {
  display: block;
  margin-bottom: 4px;
  font-size: 10px;
  font-weight: 600;
  letter-spacing: 0.04em;
  text-transform: uppercase;
  color: var(--vera5-muted-label);
}
.vera5-hover-card-ioc-timeline-list {
  margin: 0;
  padding-left: 16px;
  color: #a7b0ba;
  font-size: 12px;
  line-height: 1.5;
}
.vera5-hover-card-ioc-timeline-item {
  margin: 0;
}
.vera5-hover-card-ioc-pin {
  border: 1px solid var(--vera5-border);
  border-radius: 4px;
  background: #19202a;
  color: #f5f7fa;
  font-family: inherit;
  font-size: 11px;
  font-weight: 600;
  line-height: 1.2;
  padding: 4px 8px;
  cursor: pointer;
}
.vera5-hover-card-ioc-pin--pinned {
  border-color: color-mix(in srgb, var(--vera5-accent) 45%, var(--vera5-border));
  color: var(--vera5-accent-text);
  background: color-mix(in srgb, var(--vera5-accent) 8%, #12171e);
}
.vera5-hover-card-ioc-pin:focus {
  outline: 2px solid color-mix(in srgb, var(--vera5-accent) 35%, transparent);
  outline-offset: 1px;
}
.vera5-hover-card-save-collection {
  margin-top: 8px;
}
.vera5-hover-card-save-collection-toggle {
  border: none;
  background: transparent;
  color: var(--vera5-accent);
  cursor: pointer;
  font-size: 12px;
  font-weight: 600;
  padding: 0;
}
.vera5-hover-card-save-collection-panel {
  margin-top: 6px;
  padding: 8px 10px;
  border-radius: 6px;
  border: 1px solid var(--vera5-border);
  background: var(--vera5-surface);
}
.vera5-hover-card-save-collection-heading {
  margin: 0 0 8px;
  font-size: 12px;
  font-weight: 700;
  color: var(--vera5-accent-text);
}
.vera5-hover-card-save-collection-list {
  display: flex;
  flex-direction: column;
  gap: 4px;
  margin-bottom: 8px;
}
.vera5-hover-card-save-collection-field {
  display: block;
  margin: 0 0 8px;
  font-size: 11px;
  font-weight: 600;
  color: var(--vera5-text-muted);
}
.vera5-hover-card-save-collection-field input {
  display: block;
  width: 100%;
  margin-top: 4px;
  box-sizing: border-box;
}
.vera5-hover-card-save-collection-feedback {
  margin: 8px 0 0;
  font-size: 12px;
  color: var(--vera5-text-muted);
  line-height: 1.4;
}
.vera5-hover-card-export {
  margin-top: 8px;
}
.vera5-hover-card-export-footer {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 10px;
}
.vera5-hover-card-export-footer .vera5-hover-card-export-actions {
  justify-content: center;
}
.vera5-hover-card-export-footer .vera5-hover-card-scan-export-template-row {
  justify-content: center;
  margin-top: 0;
  width: 100%;
}
.vera5-hover-card-export-footer .vera5-hover-card-scan-export-status {
  text-align: center;
  width: 100%;
}
.vera5-hover-card-export-actions {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
}
.vera5-hover-card-export-actions + .vera5-hover-card-export-actions {
  margin-top: 8px;
}
.vera5-hover-card-scan-export {
  display: flex;
  flex-direction: column;
  gap: 0;
}
.vera5-hover-card-scan-export-template-row {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
  align-items: center;
  margin-top: 8px;
}
.vera5-hover-card-scan-export-template-label {
  font-size: 11px;
  font-weight: 600;
  color: var(--vera5-text-muted);
}
.vera5-hover-card-scan-export-template-select {
  flex: 1 1 140px;
  min-width: 140px;
  padding: 4px 8px;
  border-radius: 4px;
  border: 1px solid var(--vera5-border);
  background-color: var(--vera5-button-bg);
  color: var(--vera5-accent-text);
  font-size: 11px;
  font-family: inherit;
}
.vera5-hover-card-scan-export-status {
  margin: 8px 0 0;
  font-size: 11px;
  line-height: 1.4;
  color: var(--vera5-text-muted);
}
.vera5-hover-card-scan-export-status--success {
  color: var(--vera5-success-text);
}
.vera5-hover-card-scan-export-status--error {
  color: var(--vera5-danger-text);
}
.vera5-hover-card-export-button {
  font-size: 11px;
  font-weight: 600;
  padding: 4px 8px;
  border-radius: 4px;
  border: 1px solid var(--vera5-border);
  background-color: var(--vera5-button-bg);
  color: var(--vera5-accent-text);
  cursor: pointer;
  transition: background-color 0.15s ease, color 0.15s ease;
}
.vera5-hover-card-export-dropdown {
  position: relative;
}
.vera5-hover-card-export-dropdown-menu {
  position: absolute;
  left: 0;
  bottom: calc(100% + 4px);
  z-index: 1;
  min-width: 100%;
  margin: 0;
  padding: 4px 0;
  list-style: none;
  border-radius: 4px;
  border: 1px solid var(--vera5-border);
  background-color: var(--vera5-button-bg);
  box-shadow: var(--vera5-shadow);
}
.vera5-hover-card-export-dropdown-item {
  display: block;
  width: 100%;
  box-sizing: border-box;
  padding: 6px 10px;
  border: 0;
  background: transparent;
  color: var(--vera5-accent-text);
  font: inherit;
  font-size: 11px;
  font-weight: 600;
  text-align: left;
  cursor: pointer;
}
.vera5-hover-card-export-dropdown-item:hover,
.vera5-hover-card-export-dropdown-item:focus-visible {
  background-color: color-mix(in srgb, var(--vera5-accent) 12%, transparent);
  outline: none;
}
.vera5-ioc-highlight {
  --vera5-highlight-accent: #ffb224;
  --vera5-highlight-underline: color-mix(in srgb, #ffb224 85%, transparent);
  --vera5-highlight-bg: color-mix(in srgb, #ffb224 22%, transparent);
  --vera5-highlight-badge-text: #0b0e11;
  --vera5-highlight-badge-bg: color-mix(in srgb, #ffb224 70%, #0b0e11);
  --vera5-enrich-icon: #ffb224;
  display: inline;
  box-decoration-break: clone;
  -webkit-box-decoration-break: clone;
  font: inherit;
  line-height: inherit;
  letter-spacing: inherit;
  text-decoration: underline;
  text-decoration-thickness: 1px;
  text-underline-offset: 2px;
  text-decoration-color: var(--vera5-highlight-underline);
  background-color: var(--vera5-highlight-bg);
  border-radius: 2px;
  padding: 0 1px;
  margin: 0;
  vertical-align: baseline;
  white-space: inherit;
  cursor: pointer;
}
.vera5-ioc-highlight:focus-visible {
  outline: 2px solid var(--vera5-highlight-accent);
  outline-offset: 2px;
}
.vera5-ioc-badge {
  display: inline;
  font-size: 0.65em;
  font-weight: 600;
  line-height: 1;
  margin-left: 2px;
  padding: 0 3px;
  vertical-align: super;
  border-radius: 3px;
  color: var(--vera5-highlight-badge-text);
  background-color: var(--vera5-highlight-badge-bg);
  letter-spacing: 0.02em;
  white-space: nowrap;
}
.vera5-ioc-enrich-icon {
  display: inline;
  font-size: 0.6em;
  line-height: 1;
  margin-left: 2px;
  vertical-align: super;
  color: var(--vera5-enrich-icon);
  opacity: 0.9;
  white-space: nowrap;
}
@media (prefers-reduced-motion: reduce) {
  .vera5-hover-card-panel,
  .vera5-hover-card-copy,
  .vera5-hover-card-export-button,
  .vera5-hover-card-pivot-link,
  .vera5-hover-card-enrichment--loading,
  .vera5-ioc-highlight {
    animation: none !important;
    transition: none !important;
  }
  .vera5-hover-card-enrichment--loading {
    font-style: normal;
  }
}
@media (prefers-color-scheme: dark) {
  .vera5-hover-card-panel {
    --vera5-surface: #12171e;
    --vera5-text: #f5f7fa;
    --vera5-border: #313a45;
    --vera5-accent: #ffb224;
    --vera5-accent-text: #f5f7fa;
    --vera5-muted: #a7b0ba;
    --vera5-muted-label: #a7b0ba;
    --vera5-error: #ff4d5a;
    --vera5-ready: #f5f7fa;
    --vera5-button-bg: #19202a;
    --vera5-copy-success-bg: color-mix(in srgb, #22c7a9 16%, #12171e);
    --vera5-shadow: 0 6px 18px rgba(0, 0, 0, 0.28);
  }
  .vera5-hover-card-source-badge--ok {
    color: #22c7a9;
    background-color: color-mix(in srgb, #22c7a9 22%, #12171e);
    border-color: color-mix(in srgb, #22c7a9 40%, #313a45);
  }
  .vera5-hover-card-source-badge--error {
    color: #ff4d5a;
    background-color: color-mix(in srgb, #ff4d5a 20%, #12171e);
    border-color: color-mix(in srgb, #ff4d5a 40%, #313a45);
  }
}
.vera5-workspace-host {
  position: fixed;
  top: 0;
  right: 0;
  width: calc(var(--vera5-workspace-width, 380px) + var(--vera5-workspace-gutter, 8px));
  height: 100vh;
  z-index: 2147483645;
  pointer-events: auto;
  box-sizing: border-box;
  padding: 8px 8px 8px 0;
}
.vera5-workspace-host[hidden] {
  display: none !important;
}
html.vera5-workspace-open {
  margin-right: var(--vera5-workspace-width, 388px);
  transition: margin-right 0.2s ease;
}
.vera5-workspace-sidebar {
  display: flex;
  flex-direction: column;
  flex: 1 1 auto;
  min-width: 0;
  height: 100%;
  background: #12171e;
  color: #f5f7fa;
  border: 1px solid #313a45;
  border-radius: 12px;
  box-shadow: -8px 0 24px rgba(0, 0, 0, 0.35);
  font-family: system-ui, -apple-system, "Segoe UI", Roboto, sans-serif;
  box-sizing: border-box;
  overflow: hidden;
}
.vera5-workspace-shell {
  position: relative;
  display: flex;
  align-items: stretch;
  height: calc(100vh - 16px);
}
.vera5-workspace-edge-tab {
  position: absolute;
  left: -13px;
  top: 50%;
  transform: translateY(-50%);
  width: 22px;
  height: 52px;
  padding: 0;
  margin: 0;
  border: 1px solid #313a45;
  border-right: none;
  border-radius: 8px 0 0 8px;
  background: #222b36;
  color: #a7b0ba;
  font-size: 18px;
  font-weight: 700;
  line-height: 1;
  cursor: pointer;
  z-index: 2;
  box-shadow: -3px 0 10px rgba(0, 0, 0, 0.28);
}
.vera5-workspace-edge-tab:hover,
.vera5-workspace-edge-tab:focus-visible {
  background: #222b36;
  color: #ffc24d;
  outline: none;
  box-shadow: 0 0 0 3px rgba(255, 178, 36, 0.35);
}
.vera5-workspace-sidebar--collapsed .vera5-workspace-top,
.vera5-workspace-sidebar--collapsed .vera5-workspace-bottom,
.vera5-workspace-sidebar--collapsed .vera5-workspace-divider {
  display: none;
}
.vera5-workspace-sidebar--collapsed .vera5-workspace-title {
  display: none;
}
.vera5-workspace-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  padding: 12px 14px 10px;
  border-bottom: 1px solid #222b36;
  flex-shrink: 0;
}
.vera5-workspace-title {
  margin: 0;
  font-family: "Space Grotesk", "Inter", system-ui, sans-serif;
  font-size: 18px;
  font-weight: 700;
  letter-spacing: -0.03em;
  color: #f5f7fa;
  text-decoration: none;
}
.vera5-workspace-title-5 {
  color: #ffb224;
  text-shadow: 0 0 26px rgba(255, 178, 36, 0.22);
}
.vera5-workspace-title:hover,
.vera5-workspace-title:focus-visible {
  color: #f5f7fa;
  text-decoration: none;
  outline: none;
  box-shadow: 0 0 0 3px rgba(255, 178, 36, 0.45);
  border-radius: 4px;
}
.vera5-workspace-close {
  flex-shrink: 0;
  width: 28px;
  height: 28px;
  padding: 0;
  font-size: 18px;
  font-weight: 600;
  line-height: 1;
  border-radius: 6px;
  border: 1px solid #313a45;
  background: #222b36;
  color: #a7b0ba;
  cursor: pointer;
}
.vera5-workspace-top,
.vera5-workspace-bottom {
  flex: 1 1 0;
  min-height: 0;
  overflow: auto;
  padding: 12px 14px;
  scrollbar-color: #313a45 #12171e;
  scrollbar-width: thin;
}
.vera5-workspace-top::-webkit-scrollbar,
.vera5-workspace-bottom::-webkit-scrollbar {
  width: 10px;
  height: 10px;
}
.vera5-workspace-top::-webkit-scrollbar-track,
.vera5-workspace-bottom::-webkit-scrollbar-track {
  background: #12171e;
}
.vera5-workspace-top::-webkit-scrollbar-thumb,
.vera5-workspace-bottom::-webkit-scrollbar-thumb {
  background: #313a45;
  border-radius: 999px;
  border: 2px solid #12171e;
}
.vera5-workspace-top::-webkit-scrollbar-button,
.vera5-workspace-bottom::-webkit-scrollbar-button {
  background: #313a45;
}
.vera5-workspace-divider {
  flex-shrink: 0;
  height: 4px;
  background: #313a45;
  border: 0;
  margin: 0;
}
.vera5-workspace-empty {
  margin: 0;
  font-size: 12px;
  line-height: 1.5;
  color: #a7b0ba;
}
.vera5-workspace-toggle-row {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  margin-bottom: 10px;
}
.vera5-workspace-toggle {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  flex: 1 1 calc(50% - 4px);
  min-width: 0;
  padding: 6px 8px 6px 10px;
  border-radius: 999px;
  border: 1px solid #313a45;
  background: #222b36;
  color: #a7b0ba;
  font-size: 11px;
  font-weight: 600;
  cursor: pointer;
  text-align: left;
}
.vera5-workspace-toggle-label {
  flex: 1 1 auto;
  min-width: 0;
  line-height: 1.2;
}
.vera5-workspace-toggle-switch {
  position: relative;
  flex-shrink: 0;
  width: 30px;
  height: 16px;
  border-radius: 999px;
  background: #222b36;
  border: 1px solid #313a45;
  transition: background 0.15s ease, border-color 0.15s ease;
}
.vera5-workspace-toggle-knob {
  position: absolute;
  top: 1px;
  left: 1px;
  width: 12px;
  height: 12px;
  border-radius: 50%;
  background: #a7b0ba;
  transition: transform 0.15s ease, background 0.15s ease;
}
.vera5-workspace-toggle--on {
  border-color: #313a45;
  background: #222b36;
  color: #a7b0ba;
}
.vera5-workspace-toggle--on .vera5-workspace-toggle-switch {
  background: #ffb224;
  border-color: #ffb224;
}
.vera5-workspace-toggle--on .vera5-workspace-toggle-knob {
  transform: translateX(14px);
  background: #0b0e11;
}
.vera5-workspace-toggle:disabled {
  opacity: 0.65;
  cursor: not-allowed;
}
.vera5-workspace-button {
  display: block;
  width: 100%;
  box-sizing: border-box;
  margin-bottom: 8px;
  padding: 8px 12px;
  border-radius: 6px;
  border: 1px solid transparent;
  background: #ffb224;
  color: #0b0e11;
  font-size: 13px;
  font-weight: 600;
  cursor: pointer;
}
.vera5-workspace-button:hover:not(:disabled) {
  background: #ffc24d;
  border-color: #ffc24d;
}
.vera5-workspace-button:disabled {
  opacity: 0.65;
  cursor: not-allowed;
  border-color: #313a45;
  background: #222b36;
  color: #a7b0ba;
}
.vera5-workspace-tray-heading-row {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  margin: 14px 0 8px;
  padding-top: 12px;
  border-top: 1px solid #313a45;
}
.vera5-workspace-tray-heading {
  margin: 0;
  font-size: 13px;
  font-weight: 700;
  color: #a7b0ba;
}
.vera5-workspace-icon-button {
  flex-shrink: 0;
  width: 28px;
  height: 28px;
  padding: 0;
  border-radius: 6px;
  border: 1px solid #313a45;
  background: #222b36;
  color: #a7b0ba;
  font-size: 16px;
  line-height: 1;
  cursor: pointer;
}
.vera5-workspace-icon-button:disabled {
  opacity: 0.65;
  cursor: not-allowed;
}
.vera5-workspace-icon-button--spinning {
  animation: vera5-workspace-spin 0.8s linear infinite;
}
.vera5-hover-card-detail-clear {
  width: 28px;
  height: 28px;
  padding: 0;
  border-radius: 6px;
  border: 1px solid #313a45;
  background: #222b36;
  color: #a7b0ba;
  font-size: 16px;
  line-height: 1;
  cursor: pointer;
}
.vera5-hover-card-detail-clear:hover {
  background: #222b36;
  color: #ffc24d;
}
@keyframes vera5-workspace-spin {
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
}
.vera5-workspace-tray-summary {
  margin: 0 0 10px;
  font-size: 12px;
  color: #a7b0ba;
}
.vera5-workspace-filter-row {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
  margin-bottom: 10px;
}
.vera5-workspace-filter-chip {
  padding: 4px 8px;
  border-radius: 999px;
  border: 1px solid #313a45;
  background: #222b36;
  color: #a7b0ba;
  font-size: 11px;
  font-weight: 600;
  cursor: pointer;
}
.vera5-workspace-filter-chip[aria-pressed="true"] {
  border-color: #ffb224;
  background: #ffb224;
  color: #0b0e11;
}
.vera5-workspace-tray-list {
  list-style: none;
  margin: 0;
  padding: 0;
  display: flex;
  flex-direction: column;
  gap: 6px;
}
.vera5-workspace-tray-row {
  display: flex;
  flex-direction: column;
  align-items: stretch;
  gap: 4px;
  padding: 6px 8px;
  border-radius: 6px;
  border: 1px solid #313a45;
  background: #19202a;
  font-size: 12px;
  line-height: 1.4;
  cursor: pointer;
}
.vera5-workspace-tray-row-main {
  display: flex;
  align-items: flex-start;
  gap: 8px;
}
.vera5-workspace-tray-row--bulk-selected {
  border-color: color-mix(in srgb, #ffb224 45%, #313a45);
}
.vera5-workspace-tray-row--pinned {
  border-color: color-mix(in srgb, var(--vera5-accent) 35%, #313a45);
}
.vera5-workspace-tray-pin {
  flex-shrink: 0;
  margin-top: 1px;
  color: var(--vera5-accent-text);
  font-size: 12px;
  line-height: 1;
}
.vera5-workspace-tray-select {
  flex-shrink: 0;
  margin-top: 2px;
  cursor: pointer;
}
.vera5-workspace-tray-bulk-row {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  margin-top: 8px;
}
.vera5-workspace-tray-queue-status {
  margin: 8px 0 0;
  font-size: 12px;
  color: #a7b0ba;
  line-height: 1.5;
}
.vera5-tray-enrich-queue-warning-backdrop {
  position: fixed;
  inset: 0;
  z-index: 2147483646;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 16px;
  background: rgba(15, 23, 42, 0.72);
}
.vera5-tray-enrich-queue-warning-panel {
  width: min(420px, 100%);
  padding: 16px;
  border-radius: 8px;
  border: 1px solid #313a45;
  background: #12171e;
  color: #f5f7fa;
  box-shadow: 0 16px 40px rgba(15, 23, 42, 0.45);
}
.vera5-tray-enrich-queue-warning-heading {
  margin: 0 0 8px;
  font-size: 14px;
  font-weight: 700;
}
.vera5-tray-enrich-queue-warning-message {
  margin: 0 0 12px;
  white-space: pre-wrap;
  font-size: 12px;
  line-height: 1.5;
  color: #a7b0ba;
}
.vera5-tray-enrich-queue-warning-actions {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
}
.vera5-workspace-tray-row[aria-selected="true"] {
  border-color: #ffb224;
  background: color-mix(in srgb, #ffb224 12%, #19202a);
}
.vera5-workspace-tray-type {
  flex-shrink: 0;
  padding: 1px 6px;
  border-radius: 4px;
  background: #222b36;
  color: #a7b0ba;
  font-size: 10px;
  font-weight: 700;
}
.vera5-workspace-tray-value {
  flex: 1;
  min-width: 0;
  word-break: break-all;
  color: #f5f7fa;
  display: flex;
  flex-direction: column;
  gap: 2px;
}
.vera5-workspace-tray-value-on-page {
  display: block;
  word-break: break-all;
  color: #f5f7fa;
}
.vera5-workspace-tray-refanged-value {
  display: block;
  word-break: break-all;
  font-size: 11px;
  line-height: 1.45;
  color: #a7b0ba;
}
.vera5-workspace-tray-hint {
  flex-shrink: 0;
  font-size: 10px;
  font-weight: 600;
  padding: 1px 6px;
  border-radius: 4px;
  background: #222b36;
  color: #a7b0ba;
  pointer-events: none;
  user-select: none;
}
.vera5-workspace-tray-hint--live {
  color: #22c7a9;
}
.vera5-workspace-tray-hint--error {
  color: #ff4d5a;
}
.vera5-workspace-error {
  margin: 8px 0 0;
  font-size: 12px;
  color: #ff4d5a;
  line-height: 1.5;
}
.vera5-workspace-detail-panel {
  max-width: none !important;
  width: 100%;
  border: 0 !important;
  border-radius: 0 !important;
  box-shadow: none !important;
  animation: none !important;
  padding: 0 !important;
  --vera5-surface: #12171e;
  --vera5-text: #f5f7fa;
  --vera5-border: #313a45;
  --vera5-accent: #ffb224;
  --vera5-accent-text: #f5f7fa;
  --vera5-muted: #a7b0ba;
  --vera5-muted-label: #a7b0ba;
  --vera5-error: #ff4d5a;
  --vera5-ready: #f5f7fa;
  --vera5-button-bg: #19202a;
  --vera5-copy-success-bg: color-mix(in srgb, #22c7a9 16%, #12171e);
  --vera5-shadow: none;
}
.vera5-command-palette-backdrop {
  position: fixed;
  inset: 0;
  z-index: 2147483646;
  display: flex;
  align-items: flex-start;
  justify-content: center;
  padding: 12vh 16px 16px;
  background: rgba(15, 23, 42, 0.45);
}
.vera5-command-palette-panel {
  box-sizing: border-box;
  width: min(560px, 100%);
  max-height: min(70vh, 520px);
  display: flex;
  flex-direction: column;
  gap: 8px;
  padding: 12px;
  border-radius: 10px;
  border: 1px solid #313a45;
  background: #12171e;
  color: #f5f7fa;
  font-family: system-ui, sans-serif;
  box-shadow: 0 16px 40px rgba(15, 23, 42, 0.18);
}
.vera5-command-palette-input {
  box-sizing: border-box;
  width: 100%;
  padding: 10px 12px;
  border: 1px solid #313a45;
  border-radius: 8px;
  background: #19202a;
  color: #f5f7fa;
  font: 14px/1.4 system-ui, sans-serif;
}
.vera5-command-palette-input:focus-visible {
  outline: 2px solid #ffb224;
  outline-offset: 1px;
}
.vera5-command-palette-list {
  display: flex;
  flex-direction: column;
  gap: 4px;
  overflow: auto;
  max-height: min(48vh, 360px);
}
.vera5-command-palette-item {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  gap: 2px;
  width: 100%;
  padding: 8px 10px;
  border: 1px solid transparent;
  border-radius: 8px;
  background: transparent;
  color: inherit;
  text-align: left;
  cursor: pointer;
  font: inherit;
}
.vera5-command-palette-item:hover,
.vera5-command-palette-item--selected {
  border-color: #313a45;
  background: #19202a;
}
.vera5-command-palette-item-label {
  font-size: 14px;
  font-weight: 600;
  color: #f5f7fa;
}
.vera5-command-palette-item-description {
  font-size: 12px;
  color: #a7b0ba;
}
.vera5-command-palette-empty,
.vera5-command-palette-hint {
  margin: 0;
  font-size: 12px;
  color: #6b7480;
}
@media (prefers-color-scheme: dark) {
  .vera5-command-palette-panel {
    border-color: #313a45;
    background: #19202a;
    color: #f5f7fa;
    box-shadow: none;
  }
  .vera5-command-palette-input {
    border-color: #313a45;
    background: #12171e;
    color: #f5f7fa;
  }
  .vera5-command-palette-item:hover,
  .vera5-command-palette-item--selected {
    border-color: #313a45;
    background: #12171e;
  }
  .vera5-command-palette-item-label {
    color: #a7b0ba;
  }
  .vera5-command-palette-item-description,
  .vera5-command-palette-empty,
  .vera5-command-palette-hint {
    color: #a7b0ba;
  }
}
@media (prefers-reduced-motion: reduce) {
  html.vera5-workspace-open {
    transition: none;
  }
  .vera5-workspace-icon-button--spinning {
    animation: none;
  }
  .vera5-workspace-toggle-switch,
  .vera5-workspace-toggle-knob {
    transition: none;
  }
}
`.trim()}function At(e=document){if(e.getElementById(Qo))return;const t=e.createElement("style");t.id=Qo,t.textContent=Bf(),e.head?.appendChild(t)}const We="vera5-ioc-highlight",Ji="vera5-ioc-badge",Qi="vera5-ioc-enrich-icon",Gf={ipv4:"IP",domain:"DOM",url:"URL",md5:"MD5",sha1:"SHA1",sha256:"SHA256",cve:"CVE"};let Zo=0;function zf(){return Zo+=1,`vera5-hl-${Zo}`}function Kf(e){return e instanceof Document?e.body??e.documentElement:e}function Yf(e=document){At(e)}function Wf(e){return e.dataset.vera5DisplayValue}function jf(e){const t=e.dataset.vera5RuleId,n=e.dataset.vera5SourceTextHint;return!t||!n?null:{ruleId:t,sourceTextHint:n,ignoredOverlaps:qf(e)}}function qf(e){const t=e.dataset.vera5IgnoredOverlaps;if(!t)return[];try{const n=JSON.parse(t);if(!Array.isArray(n))return[];const r=[];for(const o of n){if(o===null||typeof o!="object")continue;const a=o;typeof a.type=="string"&&typeof a.value=="string"&&typeof a.ruleId=="string"&&a.value.length>0&&a.ruleId.length>0&&r.push({type:a.type,value:a.value,ruleId:a.ruleId})}return r}catch{return[]}}function hn(e=document.body){const t=Kf(e),n=Array.from(t.querySelectorAll(`.${We}`));for(const r of n)Xf(r);return n.length}function Xf(e){const t=e.parentNode;if(t){for(e.querySelectorAll(`.${Ji}`).forEach(n=>{n.remove()});e.firstChild;)t.insertBefore(e.firstChild,e);t.removeChild(e),t.normalize()}}function Jf(e,t,n,r){const o=e.createElement("span");o.className=We,o.dataset.vera5Ioc="true",o.dataset.vera5Type=n.type,o.dataset.vera5Value=n.value,o.dataset.vera5AnchorId=r,o.dataset.vera5RuleId=n.ruleId,o.dataset.vera5SourceTextHint=n.sourceTextHint,n.displayValue&&(o.dataset.vera5DisplayValue=n.displayValue),n.ignoredOverlaps&&n.ignoredOverlaps.length>0&&(o.dataset.vera5IgnoredOverlaps=JSON.stringify(n.ignoredOverlaps));const a=Gf[n.type]??n.type.toUpperCase();o.setAttribute("role","button"),o.setAttribute("tabindex","0"),o.setAttribute("aria-label",`View indicator details for ${n.value}`),o.appendChild(e.createTextNode(t));const i=e.createElement("span");i.className=Ji,i.setAttribute("aria-hidden","true"),i.textContent=a,o.appendChild(i);const s=e.createElement("span");return s.className=Qi,s.setAttribute("aria-hidden","true"),s.textContent="›",o.appendChild(s),o}function Qf(e,t){const n=new Map;for(const r of e){const{textNode:o}=r;if(!o.isConnected||!t.contains(o)||o.parentElement?.closest(`.${We}`))continue;const a=n.get(o)??[];a.push(r),n.set(o,a)}return n}function Zf(e){if(!e.textNode.isConnected)return!1;const t=e.textNode.data;return e.start<0||e.end>t.length||e.start>=e.end?!1:t.slice(e.start,e.end)===e.value}function em(e,t,n,r){const o=e.filter(Zf);return o.length>0||!n?o:Hf(t,r)}function tm(e,t,n,r){const o=e.data,a=[...t].sort((u,d)=>u.start-d.start),i=n.createDocumentFragment();let s=0,l=0;for(const u of a){if(u.start<s||u.end>o.length||u.start>=u.end)continue;u.start>s&&i.appendChild(n.createTextNode(o.slice(s,u.start)));const d=zf();i.appendChild(Jf(n,o.slice(u.start,u.end),u,d)),r.push({anchorId:d,type:u.type,value:u.value,ruleId:u.ruleId,sourceTextHint:u.sourceTextHint,...u.displayValue?{displayValue:u.displayValue}:{},...u.ignoredOverlaps&&u.ignoredOverlaps.length>0?{ignoredOverlaps:[...u.ignoredOverlaps]}:{}}),s=u.end,l+=1}return l===0?0:(s<o.length&&i.appendChild(n.createTextNode(o.slice(s))),e.parentNode?.replaceChild(i,e),l)}function nm(e,t={}){const n=t.root??document.body,r=t.doc??n.ownerDocument??document;Yf(r);const o=t.clearExisting!==!1;o&&hn(n);const a=em(e,n,o,t.scan),i=Qf(a,n),s=[];let l=0;for(const u of i.values()){const d=u[0]?.textNode;d?.isConnected&&(l+=tm(d,u,r,s))}return{highlightedCount:l,skippedCount:Math.max(0,a.length-l),anchorLinks:s}}function rm(e,t=document.body){return t.querySelector(`.${We}[data-vera5-anchor-id="${CSS.escape(e)}"]`)}function om(e=document.body){return Array.from(e.querySelectorAll(`.${We}`)).filter(t=>t.isConnected)}function am(e,t,n=document.body){const r=om(n);if(r.length===0)return null;if(!e)return t==="next"?r[0]:r[r.length-1];const o=r.indexOf(e);if(o===-1)return t==="next"?r[0]:r[r.length-1];const i=(o+(t==="next"?1:-1)+r.length)%r.length;return r[i]??null}function im(e){return e!==null&&typeof e=="object"&&"type"in e&&e.type===le.SCAN_PAGE}function sm(e){return e!==null&&typeof e=="object"&&"type"in e&&e.type===le.SCAN_SELECTION}function gn(e=document){const t=e.getSelection();return!t||t.rangeCount===0||t.isCollapsed?null:t.getRangeAt(0).cloneRange()}function cm(e,t,n){return n?nm(e,{root:t,clearExisting:!0}).anchorLinks:(hn(t),[])}async function jr(){const[e,t]=await Promise.all([Tf(),_f()]);return{ioc:{includePrivateIpv4:e,enabledTypes:t}}}function lm(e,t){return t.length>0?t.map(({type:n,value:r,anchorId:o,ruleId:a,sourceTextHint:i,displayValue:s,ignoredOverlaps:l})=>({type:n,value:r,anchorId:o,ruleId:a,sourceTextHint:i,...s?{displayValue:s}:{},...l&&l.length>0?{ignoredOverlaps:[...l]}:{}})):yl(e)}async function um(e){const t=El({pageUrl:window.location.href,entries:[...e]}),n=await z(Il(t));if(!n||typeof n!="object"||!("ok"in n))return{tabId:null,snapshot:t};if(n.ok!==!0)return{tabId:null,snapshot:t};const r=n.payload;return{tabId:r!==null&&typeof r=="object"&&"tabId"in r&&typeof r.tabId=="number"?r.tabId:null,snapshot:t}}async function Zi(e,t,n){const r=await If(),o=cm(e,t,r),a=lm(e,o),{tabId:i,snapshot:s}=await um(a);return e.length,{ok:!0,payload:{count:e.length,tabId:i,snapshot:s,profile:n}}}async function vn(e=document.body){const t=await jr(),{matches:n,profile:r}=Xi(e,t);return Zi(n,e,r)}async function es(e=document.body){const t=gn(document);if(!t)return{ok:!1,error:"No text selected."};const n=await jr(),{matches:r,profile:o}=Uf(t,e,n);let a=t.commonAncestorContainer;return a.nodeType===Node.TEXT_NODE&&(a=a.parentNode??e),Zi(r,a,o)}function dm(){chrome.runtime.onMessage.addListener((e,t,n)=>im(e)?(vn().then(n).catch(r=>{C(r)}),!0):sm(e)?(es().then(n).catch(r=>{C(r)}),!0):!1)}function pm(){chrome.storage.onChanged.addListener((e,t)=>{on(()=>{t==="local"&&e[Wn]?.newValue===!1&&hn(document.body)})})}const ts=400;let $t=null,nt=null,ns=ts,qn=document.body,rs;function os(){nt!==null&&(clearTimeout(nt),nt=null)}async function fm(){await Yr()&&vn(qn).then(t=>{rs?.(t)}).catch(w)}function mm(){os(),nt=setTimeout(()=>{nt=null,fm()},ns)}function hm(e={}){return e.enabled!==!0?()=>{}:(Xn(),ns=e.debounceMs??ts,qn=e.root??document.body,rs=e.onScan,$t=new MutationObserver(()=>{mm()}),$t.observe(qn,{childList:!0,subtree:!0,characterData:!0}),Xn)}function Xn(){os(),$t?.disconnect(),$t=null}let Ot=null;function as(e=document){return e.location.hostname.trim().toLowerCase()}function gm(e){if(Ot&&(Ot(),Ot=null),!e){Xn();return}Ot=hm({enabled:!0})}async function is(e=document){as(e);const t=await Cf(e);gm(t)}async function vm(e=document){as(e),await is(e)}function Em(e=document){chrome.storage.onChanged.addListener((t,n)=>{on(()=>{n!=="local"||!Af.some(o=>o in t)||is(e)})})}const ss=["benign","internal","suppress-false-positive","case-important"],ym={benign:"Benign",internal:"Internal","suppress-false-positive":"Suppress false positive","case-important":"Case important"};function bm(e){return typeof e=="string"&&ss.includes(e)}function qr(e){return bm(e)?e:null}function Sm(e){return ym[e]}const pt="iocLabels";function cs(){return typeof chrome<"u"&&chrome.storage?.local!==void 0&&!L()}function Xr(e){return F(e)}function Jn(e){if(e===null||typeof e!="object"||Array.isArray(e))return{};const t={};for(const[n,r]of Object.entries(e)){if(typeof n!="string")continue;const o=n.trim(),a=qr(r);o.length===0||!a||(t[o]=a)}return t}async function Jr(){if(!cs())return{};const e=await k(pt);return Jn(e[pt])}async function Cm(e){const t=Xr(e);return t.length===0?null:(await Jr())[t]??null}async function Am(e,t){if(!cs())return;const n=Xr(e);if(n.length===0)return;const r=await Jr(),o=t?qr(t):null;if(o?r[n]=o:delete r[n],Object.keys(r).length===0){await br(pt);return}await yr({[pt]:r})}const ft=new Map;let ls=!1;function Qr(){return typeof chrome<"u"&&chrome.storage?.local!==void 0&&!L()}function Vt(){ls=!0}function us(e){return Xr(e)}function ds(e,t){const n=us(e);if(!t){ft.delete(n);return}ft.set(n,t)}function Bt(e){return ft.get(us(e))??null}function Im(e,t){const n=t?qr(t):null;ds(e,n),Qr()&&Am(e,n).catch(w)}function ps(e,t){ds(e,t)}async function Tm(){if(!Qr()){Vt();return}try{const e=await Jr();for(const[t,n]of Object.entries(e))ft.has(t)||ft.set(t,n);Vt()}catch(e){w(e),Vt()}}function _m(e,t){const n=Bt(e);if(n){t(n);return}if(!ls){if(!Qr()){Vt();return}Cm(e).then(r=>{r&&(Bt(e)||(ps(e,r),t(r)))}).catch(w)}}function xm(e,t){const n=Bt(e);return n||(t??null)}const Gt="enrichmentCache",Nm=500,wm="|";function fs(){return{}}function Rm(e){return e===null||typeof e!="object"||Array.isArray(e)?!1:Object.values(e).every(t=>{if(t===null||typeof t!="object"||Array.isArray(t))return!1;const n=t;return typeof n.fetchedAt=="number"&&Number.isFinite(n.fetchedAt)&&"payload"in n})}function Om(e){return Rm(e)?{...e}:fs()}function zt(e){return Object.keys(e).length}function Lm(e,t="oldest"){const n=Object.keys(e);return n.sort((r,o)=>{const a=e[r]?.fetchedAt??0,i=e[o]?.fetchedAt??0;return t==="oldest"?a-i:i-a}),n}function km(e,t=Nm,n=new Set){if(!Number.isFinite(t)||t<=0)return fs();const r={...e},o=a=>{for(;zt(r)>t;){const i=Lm(r,"oldest").filter(s=>!a||!n.has(s));if(i.length===0)break;delete r[i[0]]}};return o(!0),o(!1),r}function Dm(e,t){const n=e.trim();return n.length===0?null:`${n}${wm}${t}`}function Pm(e,t=Date.now()){return Math.max(0,t-e.fetchedAt)}function Mm(e,t,n=Date.now()){if(!Number.isFinite(t)||t<=0)return!0;const r=t*1e3;return Pm(e,n)>=r}function Hm(e,t,n={}){if(Object.prototype.hasOwnProperty.call(n,e)){const r=n[e];if(r!==void 0)return r}return t}function Vm(e,t,n,r=Date.now()){const o=e[t];return!o||Mm(o,n,r)?null:o}async function Um(e){const t=await fn();return Hm(e,t.enrichmentCacheTtlSeconds,t.enrichmentSourceCacheTtlSeconds)}async function Fm(){const e=await chrome.storage.local.get(Gt),t=Om(e[Gt]),n=km(t);return zt(n)!==zt(t)&&await $m(n),n}async function $m(e){if(zt(e)===0){await Gm();return}await chrome.storage.local.set({[Gt]:e})}async function Bm(e,t,n=Date.now()){const r=Dm(e,t);if(!r)return null;const o=await Um(t),a=await Fm();return Vm(a,r,o,n)}async function Gm(e){await chrome.storage.local.remove(Gt)}async function ms(e,t,n=Date.now()){const r=await Bm(e,t,n);if(!r)return null;const o=yd(r.payload);if(!o)return null;const a=o.status===sn.OK?!0:o.fromCache;return{...o,...a===!0?{fromCache:!0}:{},fetchedAt:new Date(r.fetchedAt).toISOString()}}async function zm(e,t,n=Date.now()){const r=await ms(e,t,n);return!r||r.status!==sn.OK?null:r}const ea=200,ta=4e3,Km=5e3,Ym=new Set(Object.values(p));function Qn(e){if(typeof e!="string")return null;const t=e.trim();return t.length>0?t:null}function na(e){return typeof e!="number"||!Number.isFinite(e)?null:e}function Wm(e){return typeof e=="string"&&Ym.has(e)}function jm(e){return F(e)}function qm(e){return`${e.iocType}:${e.value}`}function Xm(e){if(e===null||typeof e!="object"||Array.isArray(e))return null;const t=e;if(!Wm(t.iocType))return null;const n=Qn(t.value);return n?{iocType:t.iocType,value:jm(n)}:null}function En(e){const t=e.trim();return t.length===0?null:t.length>ea?t.slice(0,ea):t}function Jm(e){if(e===void 0)return;const t=e.trim();if(t.length!==0)return t.length>ta?t.slice(0,ta):t}function Qm(e){if(!Array.isArray(e)||e.length>Km)return!1;const t=new Set;for(const n of e){const r=Xm(n);if(!r)return!1;const o=qm(r);if(t.has(o)||(t.add(o),JSON.stringify(n)!==JSON.stringify(r)))return!1}return!0}function yn(e){if(e===null||typeof e!="object"||Array.isArray(e))return!1;const t=e,n=Qn(t.id),r=Qn(t.name),o=na(t.createdAt),a=na(t.updatedAt);if(!n||!r||o===null||a===null||a<o||r!==En(r)||!Qm(t.members))return!1;if(t.description===void 0)return!0;if(typeof t.description!="string")return!1;const i=Jm(t.description);return i===void 0?!1:t.description===i}const hs="Save to collection…",rt="Save to collection",Zr="Create new collection",Ue="Collection name",eo="Save to new collection",to="No saved collections yet.",ra="Add filtered to collection…",oa="Add filtered indicators to collection";function Kt(e){return e.added?`Saved to ${e.collectionName}.`:`Already in ${e.collectionName}.`}function aa(e){if(e.addedCount===0)return`All ${e.totalCount} filtered indicators were already in ${e.collectionName}.`;const t=e.addedCount===1?"indicator":"indicators";if(e.duplicateCount===0)return`Added ${e.addedCount} ${t} to ${e.collectionName}.`;const n=e.duplicateCount===1?"was":"were";return`Added ${e.addedCount} ${t} to ${e.collectionName}. ${e.duplicateCount} ${n} already saved.`}function Zm(e){return e>0?`${ra} (${e})`:ra}const gs=1,eh=new Set(Object.values(p)),Zn={ipv4:"IP",domain:"DOM",url:"URL",md5:"MD5",sha1:"SHA1",sha256:"SHA256",cve:"CVE"},th=[p.URL,p.SHA256,p.SHA1,p.MD5,p.CVE,p.IPV4,p.DOMAIN];function nh(e){const t=new Set(e);return th.filter(n=>t.has(n))}function vs(e){return nh(Object.entries(e.countByType).filter(([,t])=>typeof t=="number"&&t>0).map(([t])=>t))}function Ie(e,t){return t==="all"?[...e]:e.filter(n=>n.type===t)}function rh(e){const t=[`${e.totalCount} indicator${e.totalCount===1?"":"s"}`];for(const n of vs(e)){const r=e.countByType[n];r&&r>0&&t.push(`${r} ${Zn[n]}`)}return t.join(" · ")}function Lt(e){return e.map(t=>t.value).join(`
`)}function oh(e){if(e.length===0)return null;const t=e.reduce((r,o)=>o.fetchedAtMs>r.fetchedAtMs?o:r),n=t.status==="ok"&&t.fromCache===!0?!0:void 0;return{badgeText:ci(t.status,n),sourceLabel:t.sourceLabel,status:t.status,...n===!0?{fromCache:!0}:{}}}async function ah(e){const t=[];for(const n of zr){const r=await ms(e.value,n);if(!r?.fetchedAt)continue;const o=Date.parse(r.fetchedAt);Number.isFinite(o)&&t.push({fetchedAtMs:o,sourceLabel:r.sourceLabel,status:r.status,fromCache:r.fromCache})}return oh(t)}function Es(e){return`${e.sourceLabel} · ${e.badgeText}`}function ih(e,t){const n=`View ${e} on page`;return t?`${n}. ${Es(t)}`:n}async function sh(e){const t={};return await Promise.all(e.map(async n=>{const r=await ah(n);r&&(t[n.anchorId]=r)})),t}async function ch(e){if(e.length===0)return[];const t=await fn(),n=hf(t.enrichmentSourceEnabled),r=new Date().toISOString(),o=[];for(const a of e){const i=[];for(const s of zr){if(n.includes(s))continue;const l=await zm(a.value,s);l&&i.push({sourceId:l.sourceId,sourceLabel:l.sourceLabel,status:l.status,summary:l.summary,tags:l.tags,fromCache:l.fromCache,fetchedAt:l.fetchedAt,errorCode:l.errorCode,errorMessage:l.errorMessage,retryHint:l.retryHint,rawVendorJson:l.rawVendorJson})}o.push(Ii({value:a.value,iocType:a.iocType,sourceResults:li(i),disabledSources:n,exportedAt:r}))}return o}async function ys(e){return ch(e.map(t=>({iocType:t.type,value:t.value})))}function bs(e){const t={};for(const n of e)t[n.type]=(t[n.type]??0)+1;return t}function lh(e){return typeof e.ruleId!="string"||e.ruleId.length===0||typeof e.sourceTextHint!="string"||e.sourceTextHint.length===0?null:{ruleId:e.ruleId,sourceTextHint:e.sourceTextHint,...e.ignoredOverlaps&&e.ignoredOverlaps.length>0?{ignoredOverlaps:[...e.ignoredOverlaps]}:{}}}function uh(e){return{schemaVersion:gs,tabId:e.tabId,pageUrl:e.pageUrl,scannedAt:e.scannedAt,totalCount:e.entries.length,countByType:bs(e.entries),entries:e.entries.map(t=>({...t}))}}function Ss(e){return typeof e=="string"&&eh.has(e)}function dh(e){if(e===null||typeof e!="object")return!1;const t=e;return!(!(Ss(t.type)&&typeof t.value=="string"&&t.value.length>0&&typeof t.anchorId=="string"&&t.anchorId.length>0)||t.ruleId!==void 0&&typeof t.ruleId!="string"||t.sourceTextHint!==void 0&&typeof t.sourceTextHint!="string")}function ph(e){if(e===null||typeof e!="object")return!1;const t=e;if(t.schemaVersion!==gs||typeof t.tabId!="number"||!Number.isFinite(t.tabId)||typeof t.pageUrl!="string"||typeof t.scannedAt!="number"||!Number.isFinite(t.scannedAt)||typeof t.totalCount!="number"||!Number.isFinite(t.totalCount)||t.countByType===null||typeof t.countByType!="object")return!1;for(const[n,r]of Object.entries(t.countByType))if(!Ss(n)||typeof r!="number"||!Number.isFinite(r))return!1;return!Array.isArray(t.entries)||t.entries.length!==t.totalCount?!1:t.entries.every(dh)}function kt(e){if(!e.copied)return"Could not copy to clipboard.";const t=e.count===1?"indicator":"indicators";return e.filtered?`Copied ${e.count} filtered ${t} to clipboard.`:`Copied ${e.count} ${t} to clipboard.`}function ia(e){if(!e.success)return e.format==="markdown"?"Could not export Markdown.":"Could not export JSON.";const t=e.count===1?"indicator":"indicators",n=e.format==="markdown"?"Markdown":"JSON";return`Exported ${e.count} ${t} as ${n}.`}function sa(e){if(!e.success)return`Could not export ${lt(e.templateId)}.`;const t=e.count===1?"indicator":"indicators";return`Exported ${e.count} ${t} as ${lt(e.templateId)}.`}function ca(e){if(!e.success)return e.format==="markdown"?"Could not copy Markdown.":"Could not copy JSON.";const t=e.count===1?"indicator":"indicators",n=e.format==="markdown"?"Markdown":"JSON";return`Copied ${e.count} filtered ${t} as ${n}.`}function la(e){if(!e.success)return`Could not copy ${lt(e.templateId)}.`;const t=e.count===1?"indicator":"indicators";return`Copied ${e.count} filtered ${t} as ${lt(e.templateId)}.`}const ua="vera5-inv-",da=200,pa=4e3,Dt="Investigation",Yt=100,fh=new Set(Object.values(p));function fa(e){if(typeof e!="string")return null;const t=e.trim();return t.length>0?t:null}function mt(e){return typeof e!="number"||!Number.isFinite(e)?null:e}function bn(e){return typeof e=="string"&&fh.has(e)}function J(e){return typeof e!="number"||!Number.isFinite(e)||!Number.isInteger(e)||e<0?null:e}function Cs(e){let t=0;for(const n of Object.values(e))typeof n=="number"&&Number.isFinite(n)&&(t+=n);return t}function mh(e){if(e===void 0)return{};const t={};for(const[n,r]of Object.entries(e)){if(!bn(n))continue;const o=J(r);o===null||o===0||(t[n]=o)}return t}function no(e){const t=mh(e.iocCountByType),n=Cs(t);if(e.totalIocCount===void 0)return{totalIocCount:n,iocCountByType:t};const r=J(e.totalIocCount);return r===null||r!==n?null:{totalIocCount:r,iocCountByType:t}}function hh(e){const t=bs(e);return{totalIocCount:e.length,iocCountByType:t}}function gh(e){const t=e.trim();if(t.length===0)return Dt;try{const n=new URL(t).hostname.trim();if(n.length>0)return`${Dt} — ${n}`}catch{return Dt}return Dt}function Q(e){return F(e)}function ma(e){if(!Array.isArray(e))return null;const t=[];for(const n of e){const r=mt(n);if(r===null)return null;t.push(r)}return t}function vh(e){if(e===null||typeof e!="object"||Array.isArray(e))return null;const t=e,n=mt(t.firstSeenAt),r=ma(t.enrichEvents),o=ma(t.exportEvents);if(n===null||r===null||o===null)return null;const a={firstSeenAt:n,enrichEvents:r.slice(0,Yt),exportEvents:o.slice(0,Yt)};if(t.iocType!==void 0){if(!bn(t.iocType))return null;a.iocType=t.iocType}return a}function Sn(e){if(e===void 0||e===null||typeof e!="object"||Array.isArray(e))return;const t={};for(const[n,r]of Object.entries(e)){const o=Q(n),a=vh(r);o.length===0||!a||(t[o]=a)}return Object.keys(t).length>0?t:void 0}function ha(e,t){const n=[...e,t];return n.length<=Yt?n:n.slice(n.length-Yt)}function As(e,t){const n=Q(t.iocKey);if(n.length===0)return e;const r=t.at??Date.now(),o={...e.iocTimelines??{}},a=o[n];return t.event==="first-seen"?a?e:(o[n]={firstSeenAt:r,enrichEvents:[],exportEvents:[],...t.iocType?{iocType:t.iocType}:{}},{...e,iocTimelines:o}):a?(o[n]={...a,enrichEvents:t.event==="enrich"?ha(a.enrichEvents,r):a.enrichEvents,exportEvents:t.event==="export"?ha(a.exportEvents,r):a.exportEvents,...t.iocType&&!a.iocType?{iocType:t.iocType}:{}},{...e,iocTimelines:o}):(o[n]={firstSeenAt:r,enrichEvents:t.event==="enrich"?[r]:[],exportEvents:t.event==="export"?[r]:[],...t.iocType?{iocType:t.iocType}:{}},{...e,iocTimelines:o})}function Eh(e,t){const n=Q(t);return n.length===0?null:e.iocTimelines?.[n]??null}function yh(e){return[{kind:"first-seen",at:e.firstSeenAt},...e.enrichEvents.map(t=>({kind:"enrich",at:t})),...e.exportEvents.map(t=>({kind:"export",at:t}))].sort((t,n)=>t.at-n.at)}function bh(e){return Number.isFinite(e)?new Date(e).toLocaleString():"Unknown time"}function Sh(e){switch(e){case"first-seen":return"First seen";case"enrich":return"Enriched";case"export":return"Exported"}}function Ch(e){return yh(e).map(t=>`${Sh(t.kind)} · ${bh(t.at)}`)}function Cn(e){if(e===void 0||e===null||typeof e!="object"||Array.isArray(e))return;const t={};for(const[n,r]of Object.entries(e)){const o=Q(n);if(o.length===0||r===null||typeof r!="object"||Array.isArray(r))continue;const a=r,i=mt(a.pinnedAt);if(i===null)continue;const s={pinnedAt:i};if(a.iocType!==void 0){if(!bn(a.iocType))continue;s.iocType=a.iocType}t[o]=s}return Object.keys(t).length>0?t:void 0}function ga(e,t){const n=Q(t);return n.length===0?!1:!!e.pinnedIocs?.[n]}function Ah(e){return e.pinnedIocs?Object.entries(e.pinnedIocs).sort((t,n)=>t[1].pinnedAt-n[1].pinnedAt).map(([t])=>t):[]}function Ih(e,t){if(t.length===0)return[...e];const n=new Set(t),r=new Map;for(const i of e)r.set(Q(i.value),i);const o=[];for(const i of t){const s=r.get(i);s&&o.push(s)}const a=e.filter(i=>!n.has(Q(i.value)));return[...o,...a]}function Th(e,t){const n=Q(t.iocKey);if(n.length===0)return e;const r={...e.pinnedIocs??{}},o=!!r[n];if((t.pinned===void 0?!o:t.pinned)?r[n]={pinnedAt:t.at??Date.now(),...t.iocType?{iocType:t.iocType}:{}}:delete r[n],Object.keys(r).length===0){const i={...e};return delete i.pinnedIocs,i}return{...e,pinnedIocs:r}}function Is(e){const t=e.enrichmentCount===void 0?0:J(e.enrichmentCount),n=e.exportCount===void 0?0:J(e.exportCount);return t===null||n===null?null:{enrichmentCount:t,exportCount:n}}function ro(e){const t=e.trim();return t.length===0?null:t.length>da?t.slice(0,da):t}function oo(e){return e.trim()}function ao(e){if(e===void 0)return;const t=e.trim();if(t.length!==0)return t.length>pa?t.slice(0,pa):t}function _h(e=Date.now()){return typeof crypto<"u"&&typeof crypto.randomUUID=="function"?`${ua}${crypto.randomUUID()}`:`${ua}${e}-${Math.random().toString(36).slice(2,10)}`}function Ts(e){const t=ro(e.title);if(!t)return null;const n=e.createdAt??Date.now(),r=e.updatedAt??n;if(!Number.isFinite(n)||!Number.isFinite(r)||r<n)return null;const o=e.id?.trim()||_h(n);if(o.length===0)return null;const a=no({totalIocCount:e.totalIocCount,iocCountByType:e.iocCountByType});if(!a)return null;const i=e.enrichmentCount===void 0?0:J(e.enrichmentCount),s=e.exportCount===void 0?0:J(e.exportCount);if(i===null||s===null)return null;const l=ao(e.notes),u=Sn(e.iocTimelines),d=Cn(e.pinnedIocs),f={id:o,title:t,createdAt:n,updatedAt:r,pageUrl:oo(e.pageUrl),totalIocCount:a.totalIocCount,iocCountByType:{...a.iocCountByType},enrichmentCount:i,exportCount:s};return l!==void 0&&(f.notes=l),u!==void 0&&(f.iocTimelines=u),d!==void 0&&(f.pinnedIocs=d),f}function An(e,t){const n=t.title===void 0?e.title:ro(t.title);if(!n)return null;const r=t.pageUrl===void 0?e.pageUrl:oo(t.pageUrl);let o;t.notes===null?o=void 0:t.notes===void 0?o=e.notes:o=ao(t.notes);const a=t.updatedAt??Date.now();if(!Number.isFinite(a)||a<e.createdAt)return null;const i=t.totalIocCount===void 0&&t.iocCountByType===void 0?{totalIocCount:e.totalIocCount,iocCountByType:{...e.iocCountByType}}:no({totalIocCount:t.totalIocCount??e.totalIocCount,iocCountByType:t.iocCountByType??e.iocCountByType});if(!i)return null;const s=t.enrichmentCount===void 0?e.enrichmentCount:J(t.enrichmentCount),l=t.exportCount===void 0?e.exportCount:J(t.exportCount);if(s===null||l===null)return null;let u;t.iocTimelines===null?u=void 0:t.iocTimelines===void 0?u=e.iocTimelines?{...e.iocTimelines}:void 0:u=Sn(t.iocTimelines);let d;t.pinnedIocs===null?d=void 0:t.pinnedIocs===void 0?d=e.pinnedIocs?{...e.pinnedIocs}:void 0:d=Cn(t.pinnedIocs);const f={id:e.id,title:n,createdAt:e.createdAt,updatedAt:a,pageUrl:r,totalIocCount:i.totalIocCount,iocCountByType:{...i.iocCountByType},enrichmentCount:s,exportCount:l};return o!==void 0&&(f.notes=o),u!==void 0&&(f.iocTimelines=u),d!==void 0&&(f.pinnedIocs=d),f}function xh(e){if(e===null||typeof e!="object")return!1;for(const[t,n]of Object.entries(e))if(!bn(t)||J(n)===null)return!1;return!0}function Nh(e){if(e===null||typeof e!="object")return!1;const t=e,n=fa(t.id),r=fa(t.title),o=mt(t.createdAt),a=mt(t.updatedAt),i=J(t.totalIocCount);if(!n||!r||o===null||a===null||i===null||a<o||typeof t.pageUrl!="string"||!xh(t.iocCountByType)||Cs(t.iocCountByType)!==i||Is(t)===null)return!1;if(t.iocTimelines!==void 0){const s=Sn(t.iocTimelines);if(!s||JSON.stringify(s)!==JSON.stringify(t.iocTimelines))return!1}if(t.pinnedIocs!==void 0){const s=Cn(t.pinnedIocs);if(!s||JSON.stringify(s)!==JSON.stringify(t.pinnedIocs))return!1}return t.notes===void 0?!0:typeof t.notes!="string"?!1:t.notes.trim().length>0}function _s(e){if(!Nh(e))return null;const t=no({totalIocCount:e.totalIocCount,iocCountByType:e.iocCountByType});if(!t)return null;const n=Is(e);if(!n)return null;const r=ao(e.notes),o=Sn(e.iocTimelines),a=Cn(e.pinnedIocs),i={id:e.id.trim(),title:ro(e.title)??e.title.trim(),createdAt:e.createdAt,updatedAt:e.updatedAt,pageUrl:oo(e.pageUrl),totalIocCount:t.totalIocCount,iocCountByType:{...t.iocCountByType},enrichmentCount:n.enrichmentCount,exportCount:n.exportCount};return r!==void 0&&(i.notes=r),o!==void 0&&(i.iocTimelines=o),a!==void 0&&(i.pinnedIocs=a),i}const It=1,ht="investigationSessions",io=10;function xs(){return typeof chrome<"u"&&chrome.storage?.local!==void 0&&!L()}function Ns(e){return typeof e!="number"||!Number.isFinite(e)||!Number.isInteger(e)||e<0?null:e}function ws(e){if(typeof e!="string")return;const t=e.trim();return t.length>0?t:void 0}function Rs(e,t){if(!Array.isArray(e))return[];const n=[],r=new Set;for(const o of e){if(typeof o!="string")continue;const a=o.trim();a.length===0||r.has(a)||!t.has(a)||(r.add(a),n.push(a))}return n}function Tt(e){return{schemaVersion:It,sessions:e.sessions,...e.activeSessionId?{activeSessionId:e.activeSessionId}:{},...e.archivedSessionIds&&e.archivedSessionIds.length>0?{archivedSessionIds:e.archivedSessionIds}:{}}}function ot(){return{schemaVersion:It,sessions:[]}}function In(e){if(e===null||typeof e!="object"||Array.isArray(e))return ot();const t=e;if(Ns(t.schemaVersion)!==It||!Array.isArray(t.sessions))return ot();const r=[],o=new Map;for(const l of t.sessions){const u=_s(l);if(!u)continue;const d=o.get(u.id);(!d||u.updatedAt>=d.updatedAt)&&o.set(u.id,u)}r.push(...o.values()),r.sort((l,u)=>u.updatedAt-l.updatedAt);const a=Rs(t.archivedSessionIds,o),i=ws(t.activeSessionId),s=i&&o.has(i)&&!a.includes(i)?i:void 0;return Tt({sessions:r,activeSessionId:s,archivedSessionIds:a})}function wh(e){const t=In(e);if(e===null||typeof e!="object"||Array.isArray(e))return!1;const n=e;if(Ns(n.schemaVersion)!==It||!Array.isArray(n.sessions)||n.sessions.length!==t.sessions.length)return!1;for(let a=0;a<n.sessions.length;a+=1){const i=n.sessions[a],s=t.sessions[a];if(!i||!s||JSON.stringify(i)!==JSON.stringify(s))return!1}if(ws(n.activeSessionId)!==t.activeSessionId)return!1;const o=Rs(n.archivedSessionIds,new Map(t.sessions.map(a=>[a.id,a])));return JSON.stringify(o)===JSON.stringify(t.archivedSessionIds??[])}async function M(){if(!xs())return ot();const e=await k(ht);return In(e[ht])}async function je(e){if(!xs())return;const t=In(e);if(t.sessions.length===0){await br(ht);return}await yr({[ht]:t})}function Os(e,t=io){const n=new Set(e.archivedSessionIds??[]);return e.sessions.filter(r=>!n.has(r.id)).slice(0,t).map(r=>({...r}))}async function Rh(){return(await M()).sessions.map(t=>({...t}))}async function Oh(e=io){const t=await M();return Os(t,e)}async function Lh(e){const t=e.trim();if(t.length===0)return null;const r=(await M()).sessions.find(o=>o.id===t);return r?{...r}:null}async function so(){const e=await M();if(!e.activeSessionId)return null;const t=e.sessions.find(n=>n.id===e.activeSessionId);return t?{...t}:null}async function qe(e,t){const n=_s(e);if(!n)return!1;const r=await M(),o=r.sessions.filter(i=>i.id!==n.id);o.push(n),o.sort((i,s)=>s.updatedAt-i.updatedAt);let a=r.activeSessionId;return t?.setActive?a=n.id:a&&!o.some(i=>i.id===a)&&(a=void 0),await je(Tt({sessions:o,activeSessionId:a,archivedSessionIds:r.archivedSessionIds})),!0}async function kh(e){const t=e.trim();if(t.length===0)return!1;const n=await M(),r=n.sessions.filter(i=>i.id!==t);if(r.length===n.sessions.length)return!1;const o=n.activeSessionId===t?void 0:n.activeSessionId,a=(n.archivedSessionIds??[]).filter(i=>i!==t);return await je(Tt({sessions:r,activeSessionId:o,archivedSessionIds:a})),!0}async function Dh(e){await je(e)}async function Ph(e){const t=e.trim();if(t.length===0)return null;const n=await M(),r=n.sessions.find(o=>o.id===t);return!r||n.archivedSessionIds?.includes(t)?null:(await je(Tt({sessions:n.sessions,activeSessionId:t,archivedSessionIds:n.archivedSessionIds})),{...r})}async function Ls(e){const t=e.sessionId.trim();if(t.length===0)return null;const n=await M(),r=n.sessions.find(i=>i.id===t);if(!r||n.archivedSessionIds?.includes(t))return null;const o=An(r,{title:e.title,updatedAt:e.now??Date.now()});return o&&await qe(o,{setActive:n.activeSessionId===t})?o:null}async function Mh(e){const t=e.trim();if(t.length===0)return!1;const n=await M();if(!n.sessions.some(a=>a.id===t))return!1;const r=[...n.archivedSessionIds??[]];r.includes(t)||r.push(t);const o=n.activeSessionId===t?void 0:n.activeSessionId;return await je(Tt({sessions:n.sessions,activeSessionId:o,archivedSessionIds:r})),!0}async function Hh(e){const t=e.now??Date.now(),n=hh(e.entries),r=await M(),o=r.activeSessionId?r.sessions.find(s=>s.id===r.activeSessionId)??null:null;let a=null;if(o?a=An(o,{pageUrl:e.pageUrl,totalIocCount:n.totalIocCount,iocCountByType:n.iocCountByType,updatedAt:t}):a=Ts({title:gh(e.pageUrl),pageUrl:e.pageUrl,createdAt:t,updatedAt:t,totalIocCount:n.totalIocCount,iocCountByType:n.iocCountByType}),!a)return null;for(const s of e.entries){const l=s.value?.trim();l&&(a=As(a,{iocKey:l,iocType:s.type,event:"first-seen",at:t}))}return await qe(a,{setActive:!0})?a:null}async function Vh(e){const t=e.now??Date.now(),n=Ts({title:e.title,pageUrl:e.pageUrl,createdAt:t,updatedAt:t});return n&&await qe(n,{setActive:!0})?n:null}async function Uh(e){const t=await M();return t.activeSessionId?Ls({sessionId:t.activeSessionId,title:e.title,now:e.now}):null}async function ks(e){const t=e.now??Date.now(),n=await M();if(!n.activeSessionId)return null;const r=n.sessions.find(s=>s.id===n.activeSessionId);if(!r||n.archivedSessionIds?.includes(r.id))return null;let o=r;for(const s of e.timelineEvents??[])o=As(o,{iocKey:s.iocValue,iocType:s.iocType,event:s.event,at:t});const a=An(o,{[e.field]:r[e.field]+1,updatedAt:t,iocTimelines:o.iocTimelines});return a&&await qe(a,{setActive:!0})?a:null}function Ds(e,t){return e?.iocs&&e.iocs.length>0?e.iocs.map(n=>({iocValue:n.value,iocType:n.type,event:t})):e?.iocValue?.trim()?[{iocValue:e.iocValue,iocType:e.iocType,event:t}]:[]}async function Fh(e){return ks({field:"enrichmentCount",now:e?.now,timelineEvents:Ds(e,"enrich")})}async function Wt(e){return ks({field:"exportCount",now:e?.now,timelineEvents:Ds(e,"export")})}async function Ps(e){const t=e.now??Date.now(),n=await M();if(!n.activeSessionId)return null;const r=n.sessions.find(s=>s.id===n.activeSessionId);if(!r||n.archivedSessionIds?.includes(r.id))return null;const o=Th(r,{iocKey:e.iocValue,iocType:e.iocType,pinned:e.pinned,at:t}),a=An(o,{pinnedIocs:o.pinnedIocs??null,updatedAt:t});return a&&await qe(a,{setActive:!0})?a:null}const $h=Object.freeze(Object.defineProperty({__proto__:null,INVESTIGATION_SESSIONS_SCHEMA_VERSION:It,MAX_RECENT_INVESTIGATION_SESSIONS:io,STORAGE_KEY_INVESTIGATION_SESSIONS:ht,archiveInvestigationSession:Mh,createEmptyInvestigationSessionsStore:ot,deleteStoredInvestigationSession:kh,getActiveInvestigationSession:so,getInvestigationSessionsStore:M,getStoredInvestigationSession:Lh,hydrateInvestigationSessionsStore:Dh,isInvestigationSessionsStore:wh,listRecentInvestigationSessions:Oh,listRecentInvestigationSessionsFromStore:Os,listStoredInvestigationSessions:Rh,normalizeInvestigationSessionsStore:In,persistInvestigationSessionsStore:je,recordActiveInvestigationSessionEnrichmentEvent:Fh,recordActiveInvestigationSessionExportEvent:Wt,renameActiveInvestigationSession:Uh,renameInvestigationSession:Ls,reopenInvestigationSession:Ph,saveStoredInvestigationSession:qe,startNewInvestigationSession:Vh,syncActiveInvestigationSessionFromScan:Hh,toggleActiveInvestigationSessionIocPin:Ps},Symbol.toStringTag,{value:"Module"})),Bh=new Set(Object.values(p));function Ms(e){return`tabScanTrayFilter:${e}`}function Gh(e){return e==="all"||typeof e=="string"&&Bh.has(e)}async function jt(e,t){await Hl({[Ms(e)]:t})}async function Hs(e){const t=Ms(e),r=(await Ml(t))[t];return Gh(r)?r:"all"}let er=null;function co(){return er??{defaultExportTemplateId:"analyst-update",pivotEmphasisProviders:[]}}async function va(){const e=await k([He,Ve]);return er={defaultExportTemplateId:Pi(e[He]),pivotEmphasisProviders:Mi(e[Ve])},er}function zh(){va(),!(typeof chrome>"u"||!chrome.storage?.onChanged)&&chrome.storage.onChanged.addListener((e,t)=>{t==="local"&&(He in e||Ve in e)&&va()})}const Kh="(prefers-reduced-motion: reduce)";function Yh(e=window){return e.matchMedia(Kh).matches}function Wh(e=window){return Yh(e)?0:1500}function jh(e,t=window){const n=Wh(t);if(n===0){e();return}t.setTimeout(e,n)}function qh(e){if(!e?.ok||typeof e.payload!="object"||e.payload===null)return[];const t=e.payload.collections;return Array.isArray(t)?t.filter(n=>yn(n)):[]}function Xh(e){if(!e?.ok||typeof e.payload!="object"||e.payload===null)return null;const t=e.payload.collection;return yn(t)?t:null}function Jh(e){if(!e?.ok||typeof e.payload!="object"||e.payload===null)return null;const t=e.payload;return yn(t.collection)?{collection:t.collection,added:t.added===!0}:null}function Qh(e){if(!e?.ok||typeof e.payload!="object"||e.payload===null)return null;const t=e.payload;return!yn(t.collection)||typeof t.addedCount!="number"||typeof t.duplicateCount!="number"||typeof t.totalCount!="number"?null:{collection:t.collection,addedCount:t.addedCount,duplicateCount:t.duplicateCount,totalCount:t.totalCount}}async function lo(){const e=await z(_l());return qh(e)}async function uo(e){const t=await z(xl(e));return Xh(t)}async function qt(e){const t=await z(Nl({collectionId:e.collectionId,iocType:e.member.iocType,value:e.member.value}));return Jh(t)}async function Ea(e){const t=await z(wl({collectionId:e.collectionId,members:e.members.map(n=>({iocType:n.iocType,value:n.value}))}));return Qh(t)}const Zh=8,eg=8;function Vs(e,t,n){const r=n.margin??Zh,o=n.offset??eg,a=Math.max(r,n.width-r-t.width),i=Math.max(r,n.height-r-t.height);let s=e.top+e.height+o;s+t.height>n.height-r&&(s=e.top-t.height-o),s=ya(s,r,i);let l=e.left;return l+t.width>n.width-r&&(l=n.width-r-t.width),l=ya(l,r,a),{top:s,left:l}}function ya(e,t,n){return Math.min(Math.max(e,t),n)}function Us(e,t){e.style.position="fixed",e.style.top=`${t.top}px`,e.style.left=`${t.left}px`,e.style.margin="0",e.style.zIndex="2147483646"}function po(e=window){return{width:e.innerWidth,height:e.innerHeight}}function tg(e){if(!e?.ok||typeof e.payload!="object"||e.payload===null)return null;const t=e.payload.summary;return t===null||!ph(t)?null:t}async function fo(e){const t=await z(Rl());return tg(t)}async function Fs(){return fo()}const ba=12e3,ng="[redacted]",rg=/^(key|api[_-]?key|x-otx-api-key|authorization|token|secret|password|bearer|access[_-]?token|refresh[_-]?token)$/i;function og(e){return typeof e=="object"&&e!==null&&!Array.isArray(e)}function ag(e){const t=e.trim().toLowerCase();return t?rg.test(t)?!0:t.endsWith("_key")||t.endsWith("-key")||t.includes("apikey")||t.includes("api_key"):!1}function tr(e){if(Array.isArray(e))return e.map(n=>tr(n));if(!og(e))return e;const t={};for(const[n,r]of Object.entries(e)){if(ag(n)){t[n]=ng;continue}t[n]=tr(r)}return t}function ig(e){const t=tr(e);let n;try{n=JSON.stringify(t,null,2)}catch{return}return n.length>ba?`${n.slice(0,ba)}
…`:n}function sg(e){const t=e.trim();if(!t)return t;try{return ig(JSON.parse(t))??t}catch{return t}}const gt="vera5-hover-card-host";function he(e){Wt(e&&e.length>0?{iocs:e}:void 0)}function mo(e){return e.map(t=>({value:t.value,type:t.type}))}let Fe=null,O=null,nr=null,we=!1,ee=null,me="",ge=[],Xt=!1;const cg=["button:not([disabled])","a[href]","textarea:not([disabled])","input:not([disabled])","select:not([disabled])",'[tabindex]:not([tabindex="-1"])'].join(", ");function rr(e){nr=e}function $s(e){const t=e.querySelector(cg);return t?(t.focus(),!0):!1}function lg(e){const t=nr;nr=null,t?.isConnected&&e.contains(t)&&t.focus()}function Bs(){return Fe}function Gs(){return O}const ug="vera5-hover-card-panel",dg="vera5-hover-card-copy",pg="vera5-hover-card-pivot-recipes",fg="vera5-hover-card-pivot-recipes-list",mg="vera5-hover-card-pivot-recipe",hg="vera5-hover-card-pivot-recipe-source",gg="vera5-hover-card-pivot-recipe-guidance",vg="vera5-hover-card-pivot-link",Eg="vera5-hover-card-enrichment",yg="vera5-hover-card-tags",bg="vera5-hover-card-tag",Sg="vera5-hover-card-attribution",Cg="vera5-hover-card-disclaimer",$e="vera5-hover-card-action",zs="vera5-hover-card-retry-hint",Ks="vera5-hover-card-sources",Ys="vera5-hover-card-source-item",Ag="vera5-hover-card-source-detail",Ig="vera5-hover-card-raw-json",Tg="vera5-hover-card-raw-json-body",Ws="vera5-hover-card-risk-score",_g="vera5-hover-card-risk-score-label",xg="vera5-hover-card-risk-disagreement",Ng="vera5-hover-card-risk-score-unavailable",wg="vera5-hover-card-risk-score-unavailable-detail",Rg="vera5-hover-card-risk-score-insufficient",Og="vera5-hover-card-analyst-notes",Lg="vera5-hover-card-analyst-notes-input",kg="vera5-hover-card-ioc-label",Dg="vera5-hover-card-ioc-label-label",Pg="vera5-hover-card-ioc-label-select",Mg="vera5-hover-card-save-collection",Hg="vera5-hover-card-save-collection-toggle",Vg="vera5-hover-card-save-collection-panel",Ug="vera5-hover-card-save-collection-heading",Fg="vera5-hover-card-save-collection-list",$g="vera5-hover-card-save-collection-feedback",Bg="vera5-hover-card-save-collection-field",Gg="vera5-hover-card-ioc-timeline",zg="vera5-hover-card-ioc-timeline-label",Kg="vera5-hover-card-ioc-timeline-list",Sa="vera5-hover-card-ioc-timeline-item",Yg="vera5-hover-card-ioc-pin",Wg="vera5-hover-card-ioc-pin--pinned",jg="vera5-hover-card-export",qg="vera5-hover-card-export-actions",Jt="vera5-hover-card-export-button",js="vera5-hover-card-export-dropdown",qs="vera5-hover-card-export-dropdown-menu",Xg="vera5-hover-card-export-dropdown-item",Jg="vera5-hover-card-export-footer",Qg="vera5-hover-card-scan-export-status",Zg="vera5-hover-card-scan-export-template-row",ev="vera5-hover-card-scan-export-template-label",tv="vera5-hover-card-scan-export-template-select",Ca="vera5-hover-card-scan-export-template-select",nv="vera5-hover-card-section-heading",rv="vera5-hover-card-intel-summary",Aa="vera5-why-detected",ov="vera5-why-detected-list",av="vera5-why-detected-item",Xs="vera5-tray-why-detected",iv={ipv4:"IPv4 address",domain:"Domain",url:"URL",md5:"MD5 hash",sha1:"SHA1 hash",sha256:"SHA256 hash",cve:"CVE ID"};function Js(e){return iv[e]}function te(e,t){const n=t.createElement("h2");return n.className=nv,n.textContent=e,n}function sv(e,t,n){const r=n.createElement("section");r.className=Ws,r.setAttribute("aria-label","Risk score");const o=n.createElement("p");o.className=Ng,o.textContent=e,r.appendChild(o);const a=n.createElement("p");return a.className=wg,a.setAttribute("role","note"),a.textContent=t,r.appendChild(a),r}function cv(e,t){const n=e.disabledSources??[],r=e.sourceResults??[],o=Si(n,r);if(!o)return null;if(o.mode==="unavailable")return sv(o.headline,o.detail,t);const a=o.view,i=t.createElement("section");i.className=Ws,i.setAttribute("aria-label","Risk score");const s=t.createElement("p");s.className=_g,s.textContent="Risk score: ";const l=t.createElement("strong");if(l.textContent=a.summaryText,s.appendChild(l),i.appendChild(s),o.insufficientCompositeNotice){const u=t.createElement("p");u.className=Rg,u.setAttribute("role","note"),u.textContent=o.insufficientCompositeNotice,i.appendChild(u)}if(i.appendChild(Od(bi(a,o.insufficientCompositeNotice),t)),a.chain.showDisagreement){const u=t.createElement("p");u.className=xg,u.setAttribute("role","note"),u.textContent=a.chain.disagreementLine,i.appendChild(u)}return i}function Qs(e,t,n=Eu){const r=t.createElement("details");r.className=Ig;const o=t.createElement("summary");o.textContent=n,r.appendChild(o);const a=t.createElement("pre");return a.className=Tg,a.textContent=sg(e),r.appendChild(a),r}function lv(e,t){const n=co(),r=gi(e.type,e.value,{enabledSourceIds:e.enabledEnrichmentSourceIds,showDisabledSources:e.showDisabledSourcesInWorkspace,emphasisProviders:n.pivotEmphasisProviders});if(r.length===0)return null;const o=t.createElement("section");o.className=pg,o.setAttribute("aria-label","Recommended next pivots"),o.appendChild(te("Recommended next pivots",t));const a=t.createElement("ul");a.className=fg;for(const i of r){const s=t.createElement("li");s.className=mg;const l=t.createElement("span");l.className=hg,l.textContent=i.sourceLabel;const u=t.createElement("a");u.className=vg,u.href=i.href,u.target="_blank",u.rel="noopener noreferrer",u.textContent=i.label;const d=t.createElement("span");d.className=gg,d.textContent=i.guidance,s.append(l,u,d),a.appendChild(s)}return o.appendChild(a),o}function uv(e,t){if(e.length<=1)return null;const n=t.createElement("section");n.className=Ks,n.setAttribute("aria-label","Enrichment source results"),n.appendChild(te("Sources",t));const r=t.createElement("ul");r.className="vera5-hover-card-sources-list";for(const o of e){const a=t.createElement("li");a.className=Ys;const i=t.createElement("span");i.className=Mu(o.status,o.fromCache),i.textContent=`${o.label} · ${o.badgeText}`,a.appendChild(i);const s=t.createElement("span");if(s.className=Ag,s.textContent=o.detail,a.appendChild(s),o.lastUpdatedLine){const l=t.createElement("span");l.className="vera5-hover-card-source-last-updated",l.setAttribute("role","note"),l.textContent=o.lastUpdatedLine,a.appendChild(l)}if(o.retryHint){const l=t.createElement("span");l.className=zs,l.setAttribute("role","note"),l.textContent=o.retryHint,a.appendChild(l)}o.rawVendorJson?.trim()&&a.appendChild(Qs(o.rawVendorJson,t)),r.appendChild(a)}return n.appendChild(r),n}function dv(e,t){if(e.length===0)return null;const n=t.createElement("section");n.className=Ks,n.setAttribute("aria-label","Enrichment sources"),n.appendChild(te("Sources",t));const r=t.createElement("ul");r.className="vera5-hover-card-sources-list";for(const o of e){const a=t.createElement("li");a.className=Ys,a.textContent=`${o.label} — ${o.message}`,r.appendChild(a)}return n.appendChild(r),n}function pv(e,t){const n=e.map(o=>o.trim()).filter(o=>o.length>0);if(n.length===0)return null;const r=t.createElement("div");r.className=yg,r.setAttribute("role","list"),r.setAttribute("aria-label","Threat intelligence tags");for(const o of n){const a=t.createElement("span");a.className=bg,a.setAttribute("role","listitem"),a.textContent=o,r.appendChild(a)}return r}function fv(e,t,n){if(e.length===0)return null;const r=n.createElement("footer");r.className=Cg,r.setAttribute("aria-label",Ou(t));for(const o of e){const a=n.createElement("p");a.setAttribute("role","note"),a.textContent=o,r.appendChild(a)}return r}function mv(e,t,n){const r=n.createElement("p");return r.className=Sg,r.setAttribute("role","note"),r.textContent=ri(e,t),r}function hv(e){const t=e.createElement("button");return t.type="button",t.className=$e,t.textContent=vu,t.setAttribute("aria-label","Open Vera5 Settings to add an API key"),t.addEventListener("click",n=>{n.stopPropagation(),Wa()}),t}function gv(e,t){const n=t.createElement("p");return n.className="vera5-hover-card-source-last-updated",n.setAttribute("role","note"),n.textContent=e,n}function vv(e,t){const n=t.createElement("p");return n.className=zs,n.setAttribute("role","note"),n.textContent=e,n}function Ev(e,t,n,r){const o=r.createElement("button");return o.type="button",o.className=dg,o.textContent=t,o.setAttribute("aria-label",n),o.addEventListener("click",()=>{j(e).then(a=>{if(!a)return;o.textContent=ed,o.classList.add("vera5-hover-card-copy--copied");const i=r.defaultView??window;jh(()=>{o.textContent=t,o.classList.remove("vera5-hover-card-copy--copied")},i)})}),o}function yv(e,t){const n=t.createDocumentFragment(),r=Or(e);for(const o of od(r))n.appendChild(Ev(o.copyValue,o.label,o.ariaLabel,t));return n}function bv(e,t){const n=t.createElement("button");return n.type="button",n.className=$e,n.textContent=Fo,n.setAttribute("aria-label",Fo),n.addEventListener("click",()=>{const r=t.defaultView??window;id(r)&&sd(e,r)}),n}function Sv(e,t){const n=e.preQueryDisclosure;if(!n||n.sourceIds.length===0)return null;const r=n.sourceIds.map(h=>Ye[h]),o=$l({sourceLabels:r,value:e.displayValue??e.value,typeLabel:Js(e.type)}),a=t.createElement("section");a.className="vera5-pre-query-disclosure",a.setAttribute("aria-label",nd),a.appendChild(te(rd,t));const i=t.createElement("p");i.className="vera5-pre-query-disclosure__message",i.setAttribute("role","note"),i.textContent=o,a.appendChild(i);const s=t.createElement("label");s.className="vera5-pre-query-disclosure__remember";const l=t.createElement("input");l.type="checkbox",l.setAttribute("aria-label",Go),s.appendChild(l),s.append(` ${Go}`),a.appendChild(s);const u=t.createElement("div");u.className="vera5-pre-query-disclosure__actions";const d=t.createElement("button");d.type="button",d.className=$e,d.textContent=$o,d.setAttribute("aria-label",$o),d.addEventListener("click",h=>{h.stopPropagation(),Bn({proceed:!0,rememberDismiss:l.checked})}),u.appendChild(d);const f=t.createElement("button");return f.type="button",f.className=$e,f.textContent=Bo,f.setAttribute("aria-label",Bo),f.addEventListener("click",h=>{h.stopPropagation(),Bn({proceed:!1,rememberDismiss:!1})}),u.appendChild(f),a.appendChild(u),a}function Cv(e){return Ii({value:e.value,iocType:e.type,enrichmentState:e.enrichmentState,summary:e.summary,tags:e.tags,disabledSources:e.disabledSources,sourceResults:e.sourceResults,analystNotes:an(e.value,e.analystNotes)})}function or(e){for(const t of e.querySelectorAll(`.${qs}`))t.hidden=!0;for(const t of e.querySelectorAll(`.${js} .${Jt}`))t.setAttribute("aria-expanded","false")}function Av(e){e.documentElement.dataset.vera5ExportDropdownDismiss!=="1"&&(e.documentElement.dataset.vera5ExportDropdownDismiss="1",e.addEventListener("click",()=>{or(e)}))}function Ia(e,t,n,r){const o=r.createElement("div");o.className=js;const a=r.createElement("button");a.type="button",a.className=Jt,a.textContent=e,a.setAttribute("aria-label",t),a.setAttribute("aria-haspopup","menu"),a.setAttribute("aria-expanded","false");const i=r.createElement("ul");i.className=qs,i.setAttribute("role","menu"),i.hidden=!0;for(const s of n){const l=r.createElement("li");l.setAttribute("role","none");const u=r.createElement("button");u.type="button",u.className=Xg,u.textContent=s.label,u.setAttribute("role","menuitem"),u.addEventListener("mousedown",d=>{d.stopPropagation()}),u.addEventListener("click",d=>{d.stopPropagation(),or(r),Promise.resolve(s.action())}),l.appendChild(u),i.appendChild(l)}return a.addEventListener("mousedown",s=>{s.stopPropagation()}),a.addEventListener("click",s=>{s.stopPropagation();const l=i.hidden;or(r),i.hidden=!l,a.setAttribute("aria-expanded",l?"true":"false")}),o.appendChild(a),o.appendChild(i),o}function Zs(e,t,n){return[{format:"markdown",exportLabel:"Export Markdown",copyLabel:"Copy Markdown"},{format:"json",exportLabel:"Export JSON",copyLabel:"Copy JSON"},{format:"txt",exportLabel:"Export TXT",copyLabel:"Copy TXT"}].map(({format:o,exportLabel:a,copyLabel:i})=>({label:n==="export"?a:i,action:()=>{const s=e(),l=[{value:s.value,type:s.type}];if(n==="export"){Sp(s,o,t),he(l);return}if(o==="markdown"){dp(s).then(u=>{u&&he(l)});return}if(o==="json"){up(s).then(u=>{u&&he(l)});return}pp(s).then(u=>{u&&he(l)})}}))}function Iv(e,t){return[{label:"Copy all",action:()=>{const o=Qt();if(o&&o.summary.entries.length>0){j(Lt(o.summary.entries)).then(a=>{T(t,kt({copied:a,count:o.summary.entries.length,filtered:!1}),a)});return}en().then(a=>{if(!a||a.summary.entries.length===0){T(t,q,!1);return}j(Lt(a.summary.entries)).then(i=>{T(t,kt({copied:i,count:a.summary.entries.length,filtered:!1}),i)})})}},{label:"Copy filtered",action:()=>{const o=Qt();if(o){const a=Ie(o.summary.entries,o.filter);if(a.length===0){T(t,q,!1);return}j(Lt(a)).then(i=>{T(t,kt({copied:i,count:a.length,filtered:!0}),i)});return}en().then(a=>{if(!a){T(t,q,!1);return}const i=Ie(a.summary.entries,a.filter);if(i.length===0){T(t,q,!1);return}j(Lt(i)).then(s=>{T(t,kt({copied:s,count:i.length,filtered:!0}),s)})})}}]}function Tv(e,t,n){return[...Iv(t,n),...Ov(n),...Zs(e,t,"copy")]}function _v(e,t,n){return[...Rv(t,n),...Zs(e,t,"export")]}function T(e,t,n){e.textContent=t,e.hidden=t.length===0,e.classList.remove("vera5-hover-card-scan-export-status--success","vera5-hover-card-scan-export-status--error"),e.classList.add(n?"vera5-hover-card-scan-export-status--success":"vera5-hover-card-scan-export-status--error")}const q="Scan this page first to export detected indicators.",xv="Preparing export…";let ve=null,ho=null,ar=null;function go(e){ar=e}function Qt(){return ar?ar():ve?.context??null}async function ec(){try{const e=Qt()??await en();if(!e)return{context:null,records:[]};const t=Ie(e.summary.entries,e.filter);if(t.length===0)return{context:e,records:[]};const n=await ys(t);return{context:e,records:n}}catch{return{context:null,records:[]}}}function ir(){ho=ec().then(e=>(ve=e,e))}function Nv(){ve=null,ho=null}function Zt(e,t,n){const r=o=>{Promise.resolve(t(o)).catch(()=>{if(n){n();return}T(e,q,!1)})};if(ve&&ve.records.length>0){r(ve),ir();return}T(e,xv,!1),(ho??ec()).then(o=>{ve=o,r(o),ir()}).catch(()=>{if(n){n();return}T(e,q,!1)})}function wv(e,t,n){return!e.context||e.records.length===0?!1:(t==="markdown"?Dr("markdown-report",e.records,n):vp(e.records,t,n),he(mo(e.records)),!0)}function Rv(e,t){return[{format:"markdown",label:"Export filtered Markdown"},{format:"json",label:"Export filtered JSON"}].map(({format:r,label:o})=>({label:o,action:()=>{Zt(t,a=>{if(!wv(a,r,e)){T(t,q,!1);return}T(t,ia({success:!0,count:a.records.length,format:r}),!0)},()=>{T(t,ia({success:!1,count:0,format:r}),!1)})}}))}function Ov(e){return[{format:"markdown",label:"Copy filtered Markdown"},{format:"json",label:"Copy filtered JSON"}].map(({format:n,label:r})=>({label:r,action:()=>{Zt(e,async o=>{if(!o.context||o.records.length===0){T(e,q,!1);return}const a=n==="markdown"?await Pr("markdown-report",o.records):await hp(o.records);T(e,ca({success:a,count:o.records.length,format:n}),a),a&&he(mo(o.records))},()=>{T(e,ca({success:!1,count:0,format:n}),!1)})}}))}function Lv(e,t){const n=e.createElement("div");n.className=Zg,n.setAttribute("role","group"),n.setAttribute("aria-label","Export ticket templates");const r=e.createElement("label");r.className=ev,r.htmlFor=Ca,r.textContent="Template";const o=e.createElement("select");o.id=Ca,o.className=tv;for(const s of Ip()){const l=e.createElement("option");l.value=s,l.textContent=lt(s),o.appendChild(l)}o.value=co().defaultExportTemplateId;const a=e.createElement("button");a.type="button",a.className=Jt,a.textContent="Export template",a.setAttribute("aria-label","Export filtered indicators using the selected template"),a.addEventListener("click",()=>{const s=o.value;Kn(s)&&Zt(t,l=>{if(!l.context||l.records.length===0){T(t,q,!1);return}Dr(s,l.records,e),T(t,sa({success:!0,count:l.records.length,templateId:s}),!0)},()=>{T(t,sa({success:!1,count:0,templateId:s}),!1)})});const i=e.createElement("button");return i.type="button",i.className=Jt,i.textContent="Copy template",i.setAttribute("aria-label","Copy filtered indicators using the selected template"),i.addEventListener("click",()=>{const s=o.value;Kn(s)&&Zt(t,async l=>{if(!l.context||l.records.length===0){T(t,q,!1);return}const u=await Pr(s,l.records);T(t,la({success:u,count:l.records.length,templateId:s}),u),u&&he(mo(l.records))},()=>{T(t,la({success:!1,count:0,templateId:s}),!1)})}),n.append(r,o,a,i),n}async function en(){const e=Qt();if(e)return e;const t=await Fs();if(!t||t.entries.length===0)return null;const n=await Hs(t.tabId);return{summary:t,filter:n}}async function Ta(){const e=await en();if(!e)return[];const t=Ie(e.summary.entries,e.filter);return t.length===0?[]:ys(t)}function kv(e,t){Av(t),Nv(),ir();const n=t.createElement("section");n.className=jg,n.setAttribute("aria-label","Export case artifacts");const r=t.createElement("p");r.className=Qg,r.hidden=!0,r.setAttribute("aria-live","polite");const o=t.createElement("div");o.className=Jg;const a=t.createElement("div");a.className=qg,a.setAttribute("role","group"),a.setAttribute("aria-label","Export and copy case artifacts");const i=()=>Cv(e);return a.appendChild(Ia("Export","Export case artifacts as a file",_v(i,t,r),t)),a.appendChild(Ia("Copy","Copy case artifacts to the clipboard",Tv(i,t,r),t)),o.appendChild(a),o.appendChild(Lv(t,r)),o.appendChild(r),n.appendChild(o),n}function Dv(e,t,n){const r=n.createElement("section");r.className=kg,r.setAttribute("aria-label",Au);const o=te(Cu,n);o.id="vera5-ioc-label-heading",o.className=Dg;const a=n.createElement("select");a.id=oi,a.className=Pg,a.setAttribute("aria-labelledby",o.id);const i=n.createElement("option");i.value=et,i.textContent="None",a.appendChild(i);for(const s of ss){const l=n.createElement("option");l.value=s,l.textContent=Sm(s),a.appendChild(l)}return a.value=t??et,a.addEventListener("change",()=>{const s=a.value===et?null:a.value;Im(e,s)}),a.addEventListener("mousedown",s=>{s.stopPropagation()}),_m(e,s=>{a.value===et&&s&&(a.value=s)}),r.appendChild(o),r.appendChild(a),r}function Pv(e,t){const n=t.createElement("button");n.type="button",n.className=Yg,n.setAttribute("aria-label",wu);const r=o=>{n.setAttribute("aria-pressed",o?"true":"false"),n.textContent=o?Nu:xu,n.classList.toggle(Wg,o)};return r(!1),so().then(o=>{o&&r(ga(o,e.value))}),n.addEventListener("click",o=>{o.stopPropagation(),Ps({iocValue:e.value,iocType:e.type}).then(a=>{a&&r(ga(a,e.value))})}),n}function Mv(e,t){const n=t.createElement("section");n.className=Gg,n.setAttribute("aria-label",Tu);const r=te(Iu,t);r.id="vera5-ioc-timeline-heading",r.className=zg;const o=t.createElement("ul");o.className=Kg,o.setAttribute("aria-labelledby",r.id);const a=t.createElement("li");return a.className=Sa,a.textContent=_u,o.appendChild(a),n.appendChild(r),n.appendChild(o),so().then(i=>{if(!i)return;const s=Eh(i,e);if(s){o.replaceChildren();for(const l of Ch(s)){const u=t.createElement("li");u.className=Sa,u.textContent=l,o.appendChild(u)}}}),n}function vo(){we=!1,ee=null,me="",ge=[],Xt=!1}async function Hv(e){we=!0,ee=null,me="",Xt=!0,ge=[],ie(e),ge=await lo(),Xt=!1,ie(e)}function Vv(e,t){const n=t.createElement("section");n.className=Mg,n.setAttribute("aria-label",rt),n.addEventListener("click",u=>{u.stopPropagation()}),n.addEventListener("keydown",u=>{u.stopPropagation()});const r=t.createElement("button");if(r.type="button",r.className=Hg,r.textContent=hs,r.setAttribute("aria-expanded",we?"true":"false"),r.addEventListener("click",()=>{if(we){we=!1,ee=null,ie(t);return}Hv(t)}),n.appendChild(r),!we)return n;const o=t.createElement("div");o.className=Vg,o.setAttribute("role","group"),o.setAttribute("aria-label",rt);const a=t.createElement("p");if(a.className=Ug,a.textContent=rt,o.appendChild(a),Xt){const u=t.createElement("p");u.className="vera5-workspace-empty",u.textContent="Loading collections…",o.appendChild(u)}else if(ge.length===0){const u=t.createElement("p");u.className="vera5-workspace-empty",u.textContent=to,o.appendChild(u)}else{const u=t.createElement("div");u.className=Fg;for(const d of ge){const f=t.createElement("button");f.type="button",f.className=$e,f.textContent=d.name,f.addEventListener("click",()=>{(async()=>{const h=await qt({collectionId:d.id,member:{iocType:e.type,value:e.value}});ee=h?Kt({collectionName:h.collection.name,added:h.added}):"Could not save to collection.",ie(t)})()}),u.appendChild(f)}o.appendChild(u)}const i=t.createElement("label");i.className=Bg,i.textContent=Zr;const s=t.createElement("input");s.type="text",s.value=me,s.placeholder=Ue,s.setAttribute("aria-label",Ue),s.addEventListener("input",()=>{me=s.value,ie(t)}),s.addEventListener("mousedown",u=>{u.stopPropagation()}),i.appendChild(s),o.appendChild(i);const l=t.createElement("button");if(l.type="button",l.className=$e,l.textContent=eo,l.disabled=En(me)===null,l.addEventListener("click",()=>{(async()=>{const u=await uo({name:me});if(!u){ee="Could not create collection.",ie(t);return}const d=await qt({collectionId:u.id,member:{iocType:e.type,value:e.value}});if(!d){ee="Collection created, but indicator was not saved.",ie(t);return}ge=[d.collection,...ge.filter(f=>f.id!==d.collection.id)],me="",ee=Kt({collectionName:d.collection.name,added:d.added}),ie(t)})()}),o.appendChild(l),ee){const u=t.createElement("p");u.className=$g,u.setAttribute("aria-live","polite"),u.textContent=ee,o.appendChild(u)}return n.appendChild(o),n}function Uv(e,t,n){const r=n.createElement("section");r.className=Og,r.setAttribute("aria-label",Su);const o=te(yu,n);o.id="vera5-analyst-notes-heading";const a=n.createElement("textarea");return a.id=xr,a.className=Lg,a.placeholder=bu,a.rows=3,a.value=t,a.setAttribute("aria-labelledby",o.id),a.addEventListener("input",()=>{Wl(e,a.value)}),a.addEventListener("mousedown",i=>{i.stopPropagation()}),ql(e,i=>{a.value.length===0&&i.length>0&&(a.value=i)}),r.appendChild(o),r.appendChild(a),r}function tc(e=document){const t=e.getElementById(gt);if(t)return t;const n=e.createElement("div");return n.id=gt,n.style.position="fixed",n.style.top="0",n.style.left="0",n.style.width="0",n.style.height="0",n.style.zIndex="2147483646",n.style.pointerEvents="none",e.body.appendChild(n),n}function Fv(e,t){const n=t.createElement("button");return n.type="button",n.className="vera5-hover-card-detail-clear",n.textContent="↻",n.setAttribute("aria-label","Clear indicator details"),n.addEventListener("click",e.onClear),n}function $v(e,t){const n=t.createDocumentFragment(),r=Or(e);if(!r.showRefangedPair){const i=t.createElement("p");return i.className="vera5-hover-card-value",i.textContent=r.refangedValue,n.appendChild(i),n}const o=t.createElement("p");o.className="vera5-hover-card-value-on-page",o.textContent=`${Xu} ${r.onPageValue}`,n.appendChild(o);const a=t.createElement("p");return a.className="vera5-hover-card-refanged-value",a.textContent=`${fi} ${r.refangedValue}`,n.appendChild(a),n}function nc(e,t,n={}){const r=t.createElement("section");r.className=n.compact?`${Aa} ${Xs}`:Aa,r.setAttribute("aria-label",ju),n.omitHeading||r.appendChild(te(di,t));const o=t.createElement("p");o.className="vera5-why-detected-row",o.textContent=`Type: ${e.typeLabel}`,r.appendChild(o);const a=t.createElement("p");a.className="vera5-why-detected-row",a.textContent=`Reason: ${e.reason}`,r.appendChild(a);const i=t.createElement("p");if(i.className="vera5-why-detected-row vera5-why-detected-context",i.textContent=`Source context: ${e.sourceTextHint}`,r.appendChild(i),e.ignoredOverlaps.length>0){const s=t.createElement("p");s.className="vera5-why-detected-overlaps-heading",s.textContent="Ignored overlaps:",r.appendChild(s);const l=t.createElement("ul");l.className=ov;for(const u of e.ignoredOverlaps){const d=t.createElement("li");d.className=av,d.textContent=`${u.typeLabel} ${u.value} — ${u.reason}`,l.appendChild(d)}r.appendChild(l)}else{const s=t.createElement("p");s.className="vera5-why-detected-row",s.textContent="Ignored overlaps: none",r.appendChild(s)}return r}function Eo(e,t=document,n={}){At(t);const r=co(),o=gi(e.type,e.value,{emphasisProviders:r.pivotEmphasisProviders}),a=e.sourceResults??[],i=Wu({enrichmentState:e.enrichmentState,summary:e.summary,tags:e.tags,sourceAttribution:e.sourceAttribution,errorMessage:e.errorMessage,errorCode:e.errorCode,retryHint:e.retryHint,disabledSources:e.disabledSources,sourceResults:a,pivotLinkCount:o.length}),s=i.enrichment,l=i.showMultiSourceResults?uv(a,t):null,u=i.showSingleSourceRawJson&&i.singleSourceRawJson?.trim()?Qs(i.singleSourceRawJson,t):null,d=dv(i.disabledSourcePlaceholders,t),f=lv(e,t),h=i.showTags?pv(i.enrichmentTags,t):null,E=si(e.sourceAttribution,a),x={enrichmentState:s.variant,includeRiskScoreDisclaimer:i.includeRiskScoreDisclaimer},P=i.showAttribution&&E?mv(E,s.variant,t):null,Z=i.showDisclaimer?fv(i.disclaimerLines,x,t):null,m=i.showMissingKeyAction?hv(t):null,$=i.showRateLimitRetryHint&&e.retryHint?vv(e.retryHint,t):null,K=i.singleSourceLastUpdatedLine?gv(i.singleSourceLastUpdatedLine,t):null,S=i.showBelowSummary,N=i.showFooter,Y=i.showRiskScore?cv(e,t):null,ue=Uv(e.value,an(e.value,e.analystNotes),t),de=Dv(e.value,xm(e.value,e.iocLabel),t),pe=Mv(e.value,t),ne=Vv(e,t),Qe=kv(e,t),b=pi({type:e.type,ruleId:e.ruleId,sourceTextHint:e.sourceTextHint,ignoredOverlaps:e.ignoredOverlaps}),W=b?nc(b,t):null,fe=Sv(e,t),A=t.createElement("aside");A.className=ug,A.setAttribute("role","region"),A.setAttribute("aria-label",`Indicator details for ${e.value}`),e.ruleId&&(A.dataset.vera5RuleId=e.ruleId),e.sourceTextHint&&(A.dataset.vera5SourceTextHint=e.sourceTextHint);const Nt=t.createElement("div");Nt.className="vera5-hover-card-header";const Ln=t.createElement("span");Ln.className="vera5-hover-card-type",Ln.textContent=Js(e.type),Nt.appendChild(Ln);const Ze=t.createElement("div");if(Ze.className="vera5-hover-card-header-actions",Ze.appendChild(Pv(e,t)),Ze.appendChild(yv(e,t)),n.detailClear&&Ze.appendChild(Fv(n.detailClear,t)),Nt.appendChild(Ze),A.appendChild(Nt),A.appendChild($v(e,t)),ad(e.type)){const ko=bv(e.value,t);ko.style.marginBottom="8px",A.appendChild(ko)}W&&(W.style.marginBottom="8px",A.appendChild(W)),fe&&(fe.style.marginBottom="8px",A.appendChild(fe));const re=t.createElement("section");re.className=rv,re.setAttribute("aria-label","Threat intelligence summary"),re.appendChild(te("Intel Summary",t));const oe=t.createElement("p");return oe.className=$f(s.variant,Eg),S&&(oe.style.marginBottom="8px"),oe.textContent=s.text,s.variant==="error"?oe.setAttribute("role","alert"):oe.setAttribute("role","status"),s.variant==="loading"&&(oe.setAttribute("aria-live","polite"),oe.setAttribute("aria-busy","true")),re.appendChild(oe),Y&&(Y.style.marginBottom=S?"8px":"0",re.appendChild(Y)),m&&(m.style.marginBottom=S?"8px":"0",re.appendChild(m)),$&&($.style.marginBottom=S?"8px":"0",re.appendChild($)),A.appendChild(re),u&&(u.style.marginBottom=N?"8px":"0",A.appendChild(u)),K&&(K.style.marginBottom=N?"8px":"0",A.appendChild(K)),h&&(h.style.marginBottom=N?"8px":"0",A.appendChild(h)),l&&(l.style.marginBottom=N?"8px":"0",A.appendChild(l)),d&&A.appendChild(d),f&&A.appendChild(f),de.style.marginBottom=N?"8px":"0",A.appendChild(de),pe.style.marginBottom=N?"8px":"0",A.appendChild(pe),ne.style.marginBottom=N?"8px":"0",A.appendChild(ne),ue.style.marginBottom=N?"8px":"0",A.appendChild(ue),Qe.style.marginBottom=N?"8px":"0",A.appendChild(Qe),P&&A.appendChild(P),Z&&A.appendChild(Z),A}function Bv(e,t,n=po()){const r=t.getBoundingClientRect();e.style.visibility="hidden",e.style.display="block";const o=e.getBoundingClientRect(),a={width:Math.max(o.width,e.offsetWidth,220),height:Math.max(o.height,e.offsetHeight,80)},i=Vs(r,a,n);return Us(e,i),e.style.visibility="visible",i}function tn(e,t,n=document,r={}){O&&O.value!==t.value&&vo(),Fe=e;const o=tc(n);o.replaceChildren();const a=an(t.value,t.analystNotes),i={...t,analystNotes:a.length>0?a:void 0};O=i;const s=Eo(i,n);return o.appendChild(s),Bv(s,e,po(n.defaultView??window)),r.moveFocus&&$s(s),s}function Gv(e,t,n=document,r={}){let o=n.body,a=e.commonAncestorContainer;a.nodeType===Node.TEXT_NODE&&(a=a.parentElement),a instanceof Element&&(o=a),O&&O.value!==t.value&&vo(),Fe=o;const i=tc(n);i.replaceChildren();const s=an(t.value,t.analystNotes),l={...t,analystNotes:s.length>0?s:void 0};O=l;const u=Eo(l,n);i.appendChild(u);const d=e.getBoundingClientRect();u.style.visibility="hidden",u.style.display="block";const f=u.getBoundingClientRect(),h={width:Math.max(f.width,u.offsetWidth,220),height:Math.max(f.height,u.offsetHeight,80)},E=Vs(d,h,po(n.defaultView??window));return Us(u,E),u.style.visibility="visible",r.moveFocus&&$s(u),u}function zv(e,t,n=document){if(!O||F(O.value)!==F(e))return;const r=n.getElementById(xr);if(!r||r.value===t)return;const o=n.activeElement===r,a=r.selectionStart,i=r.selectionEnd;if(r.value=t,O={...O,analystNotes:t.length>0?t:void 0},o){r.focus();const s=Math.min(a,t.length);r.setSelectionRange(s,Math.min(i,t.length))}}function Kv(e,t,n=document){if(!O||F(O.value)!==F(e))return;const r=n.getElementById(oi),o=t??et;if(!r||r.value===o)return;const a=n.activeElement===r;r.value=o,O={...O,iocLabel:t??void 0},a&&r.focus()}function ie(e=document){!Fe||!O||tn(Fe,O,e)}function Tn(e=document){Qa(),vo();const t=e.getElementById(gt);t&&(t.replaceChildren(),Fe=null,O=null,lg(e))}const Yv="modulepreload",Wv=function(e){return"/"+e},_a={},sr=function(t,n,r){let o=Promise.resolve();if(n&&n.length>0){let i=function(u){return Promise.all(u.map(d=>Promise.resolve(d).then(f=>({status:"fulfilled",value:f}),f=>({status:"rejected",reason:f}))))};document.getElementsByTagName("link");const s=document.querySelector("meta[property=csp-nonce]"),l=s?.nonce||s?.getAttribute("nonce");o=i(n.map(u=>{if(u=Wv(u),u in _a)return;_a[u]=!0;const d=u.endsWith(".css"),f=d?'[rel="stylesheet"]':"";if(document.querySelector(`link[href="${u}"]${f}`))return;const h=document.createElement("link");if(h.rel=d?"stylesheet":Yv,d||(h.as="script"),h.crossOrigin="",h.href=u,l&&h.setAttribute("nonce",l),document.head.appendChild(h),d)return new Promise((E,x)=>{h.addEventListener("load",E),h.addEventListener("error",()=>x(new Error(`Unable to preload CSS for ${u}`)))})}))}function a(i){const s=new Event("vite:preloadError",{cancelable:!0});if(s.payload=i,window.dispatchEvent(s),!s.defaultPrevented)throw i}return o.then(i=>{for(const s of i||[])s.status==="rejected"&&a(s.reason);return t().catch(a)})};function jv(e){const t=`chrome-extension://${e}`;return`chrome://settings/content/siteDetails?site=${encodeURIComponent(t)}`}function qv(e=chrome.runtime.id){const t=jv(e);if(typeof chrome.tabs?.create=="function"){chrome.tabs.create({url:t});return}z(Tl())}function Xv(e){return e.enabled?e.scanState==="scanning"?"scanning":e.scanState==="done"&&e.scanSummary?e.scanSummary.totalCount>0?"results":"empty":"prompt":null}const Jv=60,Qv=3600,Zv=15e3,eE=15e3,tE=400,nE={[g.ABUSEIPDB]:{liveEnrichment:!0,requestTimeoutSeconds:Zv/1e3,quotaSummary:"Typical free tier: 1,000 checks/day (resets 00:00 UTC). Confirm limits in your AbuseIPDB account.",rateLimitHeaderHints:["Retry-After","X-RateLimit-Limit","X-RateLimit-Remaining","X-RateLimit-Reset"]},[g.OTX]:{liveEnrichment:!0,requestTimeoutSeconds:eE/1e3,quotaSummary:"Typical keyed tier: 10,000 requests/hour. Confirm limits in your OTX account.",rateLimitHeaderHints:["Retry-After"]},[g.URLSCAN]:{liveEnrichment:!1,requestTimeoutSeconds:null,quotaSummary:"Live enrichment not shipped. Toggle stores preference and pivot links only.",rateLimitHeaderHints:["X-Rate-Limit-Limit","X-Rate-Limit-Remaining"]},[g.GREYNOISE]:{liveEnrichment:!1,requestTimeoutSeconds:null,quotaSummary:"Live enrichment not shipped. Toggle stores preference and pivot links only.",rateLimitHeaderHints:[]}};function rc(){return{defaultGlobalCooldownSeconds:Jv,maxGlobalCooldownSeconds:Qv,hoverEnrichmentDebounceMs:tE,manualRefreshBypassesGlobalCooldown:!0,sources:I.map(e=>({sourceId:e,...nE[e]}))}}function rE(e,t){return e[t]===!0}function oE(e,t){return pu(e,t)}function oc(e,t){return I.filter(n=>rE(e,n)&&oE(n,t))}function aE(e,t,n){const r=new Map(e.map(l=>[l.anchorId,l])),o=new Set;let a=0;for(const l of t){const u=r.get(l);if(!u)continue;const d=oc(n,u.type);a+=d.length;for(const f of d)o.add(f)}const i=rc(),s=[...o].map(l=>{const u=i.sources.find(d=>d.sourceId===l);return{sourceId:l,label:Ye[l],quotaSummary:u?.quotaSummary??"Confirm limits in your vendor account."}});return{iocCount:t.length,maxLiveRequests:a,quotaSummaries:s}}function iE(e){const t=[],n=rc();if(e.maxLiveRequests===0)t.push(`Enrich ${e.iocCount} selected indicator${e.iocCount===1?"":"s"} without live vendor queries (no live enrichment sources are enabled for these types).`);else{t.push(`Enrich ${e.iocCount} selected indicator${e.iocCount===1?"":"s"} with up to ${e.maxLiveRequests} live vendor request${e.maxLiveRequests===1?"":"s"}.`),t.push("Vendor quotas apply:");for(const r of e.quotaSummaries)t.push(`• ${r.label}: ${r.quotaSummary}`)}return t.push(`Rate limits may pause or fail queue items. After a vendor rate limit, Vera5 may wait up to ${n.maxGlobalCooldownSeconds} seconds before retrying.`),t.join(`

`)}const xa="manualOnlyMode";async function sE(){const t=(await k(xa))[xa];return t===void 0?!0:!!t}let cr=null;function cE(e){cr=e}async function lE(){return!await sE()}async function yo(e){return L()||!await lE()?!1:(cr&&await cr(e),!0)}const uE="ENRICH_IOC";function ac(e){if(!Array.isArray(e))return;const t=e.filter(n=>typeof n=="string").map(n=>n.trim()).filter(n=>n.length>0);return t.length>0?t:void 0}function dE(e){if(typeof e!="object"||e===null)return!1;const t=e;return!(typeof t.sourceId!="string"||typeof t.sourceLabel!="string"||t.status!=="ok"&&t.status!=="error"&&t.status!=="skipped"||t.summary!==void 0&&typeof t.summary!="string"||t.tags!==void 0&&ac(t.tags)===void 0||t.errorMessage!==void 0&&typeof t.errorMessage!="string"||t.fromCache!==void 0&&typeof t.fromCache!="boolean"||t.errorCode!==void 0&&typeof t.errorCode!="string"||t.retryHint!==void 0&&typeof t.retryHint!="string"||t.rawVendorJson!==void 0&&typeof t.rawVendorJson!="string")}function lr(e){if(!dE(e))return null;const t=e,n={sourceId:t.sourceId,sourceLabel:t.sourceLabel,status:t.status};t.summary&&(n.summary=t.summary);const r=ac(t.tags);r&&(n.tags=r),t.errorMessage&&(n.errorMessage=t.errorMessage),t.fromCache===!0&&(n.fromCache=!0),typeof t.fetchedAt=="string"&&t.fetchedAt.trim()&&(n.fetchedAt=t.fetchedAt.trim()),t.errorCode&&(n.errorCode=t.errorCode),t.retryHint&&(n.retryHint=t.retryHint);const o=t.rawVendorJson?.trim();return o&&(n.rawVendorJson=o),n}function pE(e){if(!Array.isArray(e))return[];const t=[];for(const n of e){const r=lr(n);r&&t.push(r)}return t}async function fE(e){const t=ml({value:e.value,type:e.iocType});if(!t)return null;const n={type:uE,value:t.value,iocType:t.type};e.sourceId&&(n.sourceId=e.sourceId),e.bypassCache===!0&&(n.bypassCache=!0);const r=await z(n);if(!r?.ok||typeof r.payload!="object"||r.payload===null)return null;const o=r.payload,a=pE(o.sources);if(a.length===0){const s=lr(o.source);return s?{sources:[s],primary:s}:null}const i=lr(o.source)??a[0]??null;return{sources:a,primary:i}}const Na="enrichmentSourceEnabled",wa="showDisabledSourcesInWorkspace";function mE(){return Object.fromEntries(I.map(e=>[e,!1]))}function hE(e){const t=mE();if(e===null||typeof e!="object"||Array.isArray(e))return t;for(const n of I){const r=e[n];typeof r=="boolean"&&(t[n]=r)}return t}async function bo(){const e=await k(Na);return hE(e[Na])}async function gE(){return(await k(wa))[wa]===!0}async function vE(){const e=await k(Ee);return e[Ee]===void 0?!0:e[Ee]===!0}async function EE(e){await gf(e)}function yE(e,t=!0){const n=I.filter(r=>!e[r]);return t?n:[]}function bE(e){return I.filter(t=>e[t])}async function _n(){const[e,t]=await Promise.all([bo(),gE()]);return{sources:e,showDisabledSourcesInWorkspace:t,disabledSourceIds:yE(e,t),enabledSourceIds:bE(e)}}async function SE(){const e=await k([Le,ke,De]),t=Gp();return e[Le]===void 0&&e[ke]===void 0&&e[De]===void 0?t:Yp({domains:e[Le]??t.domains,cidrRanges:e[ke]??t.cidrRanges,vendorLabels:e[De]??t.vendorLabels})}async function CE(){const e=await k(Oe);return e[Oe]===void 0?!0:e[Oe]===!0}async function AE(e,t){const n=await CE();if(!n)return!0;const r=await SE();return Xp(r)?!qp(e,t,r):!0}let Ce={open:!1,selectedAnchorId:null,payloadValue:null},ur=null;function IE(e){ur=e}function Xe(e){Ce={open:e.open,selectedAnchorId:e.selectedAnchorId===void 0?Ce.selectedAnchorId:e.selectedAnchorId,payloadValue:e.payloadValue===void 0?Ce.payloadValue:e.payloadValue}}function xn(){Ce={open:Ce.open,selectedAnchorId:null,payloadValue:null}}function ic(e,t=document){return!Ce.open||Ce.payloadValue!==e.value?!1:t.getElementById("vera5-workspace-host")!==null}function Ra(e,t=document){return!ic(e,t)||!ur?!1:(ur(e,t),!0)}const TE=400,sc="Threat intelligence queries are blocked for this site by domain policy.",_E="Threat intelligence queries are blocked for this indicator because it matches a configured internal asset list.";let at=null;function U(){at!==null&&(clearTimeout(at),at=null),Qa()}async function So(e=document){return await Sf(e)?{allowed:!0}:{allowed:!1,errorCode:cn.DOMAIN_POLICY,errorMessage:sc}}async function cc(e,t){return await AE(e,t)?{allowed:!0}:{allowed:!1,errorCode:cn.INTERNAL_ASSET,errorMessage:_E}}function dr(e,t,n=document){Ae({...e,enrichmentState:"error",errorCode:t.errorCode,errorMessage:t.errorMessage,preQueryDisclosure:void 0},n)}function xE(e,t=document,n=TE){U(),at=setTimeout(()=>{at=null,_t(e,t)},n)}function NE(e,t){const n=ui(t);return{...e,enrichmentState:n.enrichmentState,summary:n.summary,tags:n.tags,sourceAttribution:n.sourceAttribution,errorMessage:n.errorMessage,errorCode:n.errorCode,retryHint:n.retryHint,sourceResults:n.sourceResults,preQueryDisclosure:void 0}}function Ae(e,t){if(Ra(e,t))return!0;const n=Bs(),r=Gs();return n&&r?.value===e.value?(tn(n,e,t),!0):Ra(e,t)}function Oa(e,t){if(ic(e,t))return!0;const n=Bs(),r=Gs();return!!(n&&r?.value===e.value)}async function wE(e,t,n){const r=await vE();if(!r||t.length===0)return!0;const o=Fl();Ae({...e,enrichmentState:"empty",preQueryDisclosure:{sourceIds:t}},n);const a=await o;return a.rememberDismiss&&await EE(!1),a.proceed}async function RE(e,t,n){Ae({...e,enrichmentState:"loading",preQueryDisclosure:void 0},t);const r={value:e.value,iocType:e.type};n.bypassCache===!0&&(r.bypassCache=!0);const o=await fE(r);if(!o||o.sources.length===0){Ae({...e,enrichmentState:"error",errorMessage:"Threat intelligence could not be loaded.",preQueryDisclosure:void 0},t);return}Ae(NE(e,o.sources),t)}async function _t(e,t=document,n={}){if(L()||!Oa(e,t))return"skipped";const r=await bo(),o=oc(r,e.type);if(o.length===0)return Ae({...e,enrichmentState:"error",errorCode:cn.DISABLED,errorMessage:"No enrichment sources are enabled in extension settings.",preQueryDisclosure:void 0},t),"blocked";const a=await So(t);if(!a.allowed)return dr(e,a,t),"blocked";const i=await cc(e.value,e.type);return i.allowed?await wE(e,o,t)?Oa(e,t)?(await RE(e,t,n),"completed"):"skipped":(Ae({...e,enrichmentState:"empty",preQueryDisclosure:void 0},t),"cancelled"):(dr(e,i,t),"blocked")}function OE(){cE(e=>{xE(e)})}const LE=new Set(Object.values(p));function lc(e){return LE.has(e)}function vt(e){if(!e)return null;const t=e.closest(`.${We}`);if(!t)return null;const n=t.dataset.vera5Value,r=t.dataset.vera5Type;return!n||!r||!lc(r)?null:t}function Je(e){const t=e.dataset.vera5Value,n=e.dataset.vera5Type;if(!t||!n||!lc(n))return null;const r=jf(e),o=Wf(e);return{value:t,type:n,...r??{},...o?{displayValue:o}:{},enrichmentState:"empty"}}function uc(e){return e.closest(`.${Qi}`)!==null}function Nn(e,t={},n=document){const r=Je(e);return r?(t.moveFocusToPanel?rr(e):rr(null),L()?(tn(e,r,n,{moveFocus:t.moveFocusToPanel}),!0):(_n().then(({disabledSourceIds:o,enabledSourceIds:a,showDisabledSourcesInWorkspace:i})=>{const s={...r,...o.length>0?{disabledSources:o}:{},enabledEnrichmentSourceIds:a,showDisabledSourcesInWorkspace:i};tn(e,s,n,{moveFocus:t.moveFocusToPanel}),t.enrichmentTrigger==="manual"?(U(),_t(s,n,{bypassCache:!0}).catch(w)):t.enrichmentTrigger!=="none"&&yo(s).catch(w)}).catch(w),!0)):!1}function kE(e){return e.closest(`#${gt}`)!==null}function DE(e,t){const n=e.target;if(!(n instanceof Element))return;const r=vt(n);if(r){e.preventDefault(),e.stopPropagation(),Nn(r,{enrichmentTrigger:uc(n)?"manual":"auto"},t);return}kE(n)||(U(),Tn(t))}function PE(e,t){return e?e===t.body||e===t.documentElement:!0}function ME(e,t){if(e.key!=="ArrowDown"&&e.key!=="ArrowUp")return!1;const n=e.target instanceof Element?e.target:null;if(n?.closest(`#${gt}`))return!1;const r=e.key==="ArrowDown"?"next":"previous",a=vt(n)??(PE(t.activeElement,t)?null:void 0);if(a===void 0)return!1;const i=am(a,r,t.body);return i?(e.preventDefault(),U(),Tn(t),rr(null),i.scrollIntoView({block:"center",inline:"nearest",behavior:"smooth"}),i.focus(),!0):!1}function HE(e,t){if(e.key==="Escape"){U(),Tn(t);return}if(ME(e,t)||e.key!=="Enter"&&e.key!==" ")return;const n=vt(e.target instanceof Element?e.target:null);n&&(e.preventDefault(),Nn(n,{enrichmentTrigger:uc(e.target instanceof Element?e.target:n)?"manual":"auto",moveFocusToPanel:!0},t))}function VE(e=document){const t=r=>{DE(r,e)},n=r=>{HE(r,e)};return e.addEventListener("click",t,!0),e.addEventListener("keydown",n,!0),()=>{e.removeEventListener("click",t,!0),e.removeEventListener("keydown",n,!0),U(),Tn(e)}}function UE(e){return e!==null&&typeof e=="object"&&"type"in e&&e.type===le.ENRICH_SELECTION}function La(e,t){const r=(t.ownerDocument??document).createRange();try{r.selectNodeContents(t)}catch{return!1}return e.compareBoundaryPoints(Range.END_TO_START,r)<0&&e.compareBoundaryPoints(Range.START_TO_END,r)>0}function FE(e=document){const t=e.getSelection();if(!t||t.rangeCount===0||t.isCollapsed)return null;const n=t.getRangeAt(0);for(const o of[t.anchorNode,t.focusNode]){if(!o)continue;const a=o.nodeType===Node.ELEMENT_NODE?o:o.parentElement,i=vt(a);if(i&&La(n,i))return i}let r=n.commonAncestorContainer;for(r.nodeType===Node.TEXT_NODE&&(r=r.parentElement);r instanceof Element;){const o=vt(r);if(o&&La(n,o))return o;r=r.parentElement}return null}function $E(e,t={}){const n=e.trim();if(n.length===0)return null;const r=Wr(n,t);if(r.length===0)return null;for(const o of Object.values(p)){const a=za(n,o);if(!a)continue;const i=r.find(s=>s.type===o&&s.value===a&&s.start===0&&s.end===n.length);return i||{value:a,type:o,start:0,end:n.length,ruleId:Va(o),sourceTextHint:n}}return[...r].sort((o,a)=>a.value.length-o.value.length)[0]??null}async function Co(e=document){const t=gn(e);if(!t)return null;const n=FE(e);if(n){const a=Je(n);return a?{value:a.value,type:a.type,ruleId:a.ruleId,sourceTextHint:a.sourceTextHint,highlight:n,range:null}:null}const r=await jr(),o=$E(e.getSelection()?.toString()??"",r.ioc??{});return o?{value:o.value,type:o.type,ruleId:o.ruleId,sourceTextHint:o.sourceTextHint,highlight:null,range:t}:null}function BE(e){if(e.highlight){const t=Je(e.highlight);if(t)return t}return{value:e.value,type:e.type,ruleId:e.ruleId,sourceTextHint:e.sourceTextHint,enrichmentState:"empty"}}async function ka(e,t,n=document){return await dc(e,n,{enrichmentTrigger:"none"})?(dr(BE(e),t,n),!0):!1}function GE(e,t){let n=e.commonAncestorContainer;return n.nodeType===Node.TEXT_NODE&&(n=n.parentElement),n instanceof HTMLElement?n:t.body}async function dc(e,t=document,n={enrichmentTrigger:"manual"}){if(e.highlight){const u=await sr(()=>Promise.resolve().then(()=>Ha),void 0);if(u.isWorkspaceOpen(t)){const d=Je(e.highlight);return d?(u.presentWorkspaceEnrichmentForPayload(d,e.highlight,n,t),!0):!1}return Nn(e.highlight,n,t)}if(!e.range)return!1;const r={value:e.value,type:e.type,ruleId:e.ruleId,sourceTextHint:e.sourceTextHint,enrichmentState:"empty"},o=await sr(()=>Promise.resolve().then(()=>Ha),void 0);if(o.isWorkspaceOpen(t))return o.presentWorkspaceEnrichmentForPayload(r,GE(e.range,t),n,t),!0;const{disabledSourceIds:a,enabledSourceIds:i,showDisabledSourcesInWorkspace:s}=await _n(),l={...r,...a.length>0?{disabledSources:a}:{},enabledEnrichmentSourceIds:i,showDisabledSourcesInWorkspace:s};return Gv(e.range,l,t),n.enrichmentTrigger==="manual"?(U(),_t(l,t,{bypassCache:!0}).catch(w)):yo(l).catch(w),!0}async function Ao(e=document){const t=e.getSelection();if(!t||t.rangeCount===0||t.isCollapsed)return{ok:!1,error:"No text selected."};const n=await Co(e);if(!n)return{ok:!1,error:"No indicator found in selection."};const r=await So(e);if(!r.allowed)return await ka(n,r,e)?{ok:!0,payload:{value:n.value,type:n.type}}:{ok:!1,error:"No indicator found in selection."};const o=await cc(n.value,n.type);return o.allowed?await dc(n,e,{enrichmentTrigger:"manual"})?{ok:!0,payload:{value:n.value,type:n.type}}:{ok:!1,error:"No indicator found in selection."}:await ka(n,o,e)?{ok:!0,payload:{value:n.value,type:n.type}}:{ok:!1,error:"No indicator found in selection."}}function zE(){chrome.runtime.onMessage.addListener((e,t,n)=>UE(e)?(Ao().then(n).catch(r=>{C(r)}),!0):!1)}let D=null;function KE(){return D}function pc(){return D?.running===!0}function Et(){D?.running&&(D={...D,cancelRequested:!0})}function YE(){D=null}async function WE(e,t,n){if(e.length===0||D?.running)return{completedCount:0,cancelled:!1};let r=0,o=!1;D={running:!0,cancelRequested:!1,currentIndex:0,totalCount:e.length,currentAnchorId:null},n?.(D);for(let a=0;a<e.length;a+=1){if(D.cancelRequested){o=!0;break}const i=e[a];if(D={...D,currentIndex:a+1,currentAnchorId:i},n?.(D),await t(i),r+=1,D.cancelRequested){o=!0;break}}return D=null,{completedCount:r,cancelled:o}}const Be="vera5-workspace-host",Io=380,fc=44,To=8,mc="vera5-workspace-open",hc="https://www.vera5.io/",jE="Run a scan to detect indicators on this page.",qE="Select an indicator to view details.",Da="Confirm bulk enrich",XE="Start enrich queue",JE="Cancel";let c=gc();function gc(){return{open:!1,collapsed:!1,ready:!1,enabled:!0,highlightEnabled:!0,scanState:"idle",textSelectionAvailable:!1,selectionEnrichAvailable:!1,scanSummary:null,typeFilter:"all",trayFilterReady:!1,trayNavigationMessage:null,trayEnrichmentStatuses:{},trayMultiSelectAnchorIds:{},sessionPinnedIocKeys:[],selectedAnchorId:null,saveToCollectionAnchorId:null,saveToCollectionFeedback:null,saveToCollectionNewName:"",saveToCollectionOptions:[],saveToCollectionLoading:!1,addFilteredToCollectionOpen:!1,addFilteredToCollectionFeedback:null,addFilteredToCollectionNewName:"",addFilteredToCollectionOptions:[],addFilteredToCollectionLoading:!1,selection:null}}function wn(e=document){return c.open&&e.getElementById(Be)!==null}function QE(){return c.selection}function vc(e){return e!==null&&typeof e=="object"&&"type"in e&&e.type===le.TOGGLE_WORKSPACE}function Ec(e){return e!==null&&typeof e=="object"&&"type"in e&&e.type===le.OPEN_WORKSPACE}function yc(e){const t=e.getElementById(Be);if(t)return t;At(e);const n=e.createElement("div");return n.id=Be,n.className="vera5-workspace-host",n.hidden=!0,n.style.setProperty("--vera5-workspace-width",`${Io}px`),n.style.setProperty("--vera5-workspace-gutter",`${To}px`),e.body.appendChild(n),n}function bc(){return c.collapsed?fc:Io}function Sc(e){const t=e.getElementById(Be);if(!t)return;const n=bc();t.style.setProperty("--vera5-workspace-width",`${n}px`),t.classList.toggle("vera5-workspace-host--collapsed",c.collapsed),_o(c.open,e)}function _o(e,t){if(t.documentElement.classList.toggle(mc,e),e){const n=bc();t.documentElement.style.setProperty("--vera5-workspace-width",`${n+To}px`);return}t.documentElement.style.removeProperty("--vera5-workspace-width")}function nn(e,t){const n=t.querySelector(".vera5-workspace-bottom");if(!(n instanceof HTMLElement))return;go(()=>!c.scanSummary||c.scanSummary.entries.length===0?null:{summary:c.scanSummary,filter:c.typeFilter}),n.replaceChildren();const r=Eo(e,t,{detailClear:{onClear:()=>{py(t)}}});r.classList.add("vera5-workspace-detail-panel"),n.appendChild(r)}function Ge(e){const t=e.querySelector(".vera5-workspace-bottom");if(!(t instanceof HTMLElement))return;t.replaceChildren();const n=e.createElement("p");n.className="vera5-workspace-empty",n.textContent=qE,t.appendChild(n)}function Cc(e,t=document){c.open&&(c.selection&&(c.selection={...c.selection,payload:e}),nn(e,t),v(t))}function Ac(e,t,n=document){if(!c.selection||F(c.selection.payload.value)!==F(e))return;const r=n.querySelector(`.vera5-workspace-bottom #${xr}`);if(!r||r.value===t)return;const o=n.activeElement===r,a=r.selectionStart,i=r.selectionEnd;if(r.value=t,c.selection={...c.selection,payload:{...c.selection.payload,analystNotes:t.length>0?t:void 0}},o){r.focus();const s=Math.min(a,t.length);r.setSelectionRange(s,Math.min(i,t.length))}}async function ZE(){if(!c.scanSummary||c.scanSummary.entries.length===0){c.trayEnrichmentStatuses={};return}try{c.trayEnrichmentStatuses=await sh(c.scanSummary.entries)}catch(e){C(e),c.trayEnrichmentStatuses={}}}async function ey(){try{const{getActiveInvestigationSession:e}=await sr(async()=>{const{getActiveInvestigationSession:n}=await Promise.resolve().then(()=>$h);return{getActiveInvestigationSession:n}},void 0),t=await e();c.sessionPinnedIocKeys=t?Ah(t):[]}catch(e){C(e),c.sessionPinnedIocKeys=[]}}async function Rn(){await Promise.all([ZE(),ey()])}function Ic(e){if(e===null||typeof e!="object")return null;const t=e;if(!Al(t.snapshot))return null;const n=typeof t.tabId=="number"?t.tabId:null;return n===null?null:uh({...t.snapshot,tabId:n})}async function Tc(e){if(c.scanState!=="scanning"){try{const[t,n,r]=await Promise.all([df(),ff(),Fs()]);if(c.enabled=t,c.highlightEnabled=n,r){c.scanSummary=r,c.scanState="done";const o=await Hs(r.tabId);c.typeFilter=o,c.trayFilterReady=!0}else c.scanState!=="error"&&(c.scanSummary=null,c.scanState="idle",c.typeFilter="all",c.trayFilterReady=!1,c.trayEnrichmentStatuses={})}catch(t){C(t)}finally{c.ready=!0,c.open&&(v(e),c.selection||Ge(e))}c.scanSummary&&c.scanSummary.entries.length>0&&Rn().then(()=>{c.open&&v(e)}).catch(t=>{C(t)})}}function H(e,t,n,r=!1){const o=t.createElement("button");return o.type="button",o.className="vera5-workspace-button",o.textContent=e,o.disabled=r,o.addEventListener("click",n),o}async function ty(e,t){c.saveToCollectionAnchorId=e,c.saveToCollectionFeedback=null,c.saveToCollectionNewName="",c.saveToCollectionLoading=!0,c.saveToCollectionOptions=[],v(t),c.saveToCollectionOptions=await lo(),c.saveToCollectionLoading=!1,v(t)}function ny(e,t,n){const r=n.createElement("div");r.className="vera5-tray-save-collection",r.addEventListener("click",d=>{d.stopPropagation()}),r.addEventListener("keydown",d=>{d.stopPropagation()});const o=c.saveToCollectionAnchorId===t.anchorId,a=n.createElement("button");if(a.type="button",a.className="vera5-tray-save-collection-toggle",a.textContent=hs,a.setAttribute("aria-expanded",o?"true":"false"),a.addEventListener("click",()=>{if(o){c.saveToCollectionAnchorId=null,c.saveToCollectionFeedback=null,v(n);return}ty(t.anchorId,n)}),r.appendChild(a),!o){e.appendChild(r);return}const i=n.createElement("div");i.className="vera5-tray-save-collection-panel",i.setAttribute("role","group"),i.setAttribute("aria-label",rt);const s=n.createElement("p");if(s.className="vera5-tray-save-collection-heading",s.textContent=rt,i.appendChild(s),c.saveToCollectionLoading){const d=n.createElement("p");d.className="vera5-workspace-empty",d.textContent="Loading collections…",i.appendChild(d)}else if(c.saveToCollectionOptions.length===0){const d=n.createElement("p");d.className="vera5-workspace-empty",d.textContent=to,i.appendChild(d)}else{const d=n.createElement("div");d.className="vera5-tray-save-collection-list";for(const f of c.saveToCollectionOptions)d.appendChild(H(f.name,n,()=>{(async()=>{const h=await qt({collectionId:f.id,member:{iocType:t.type,value:t.value}});c.saveToCollectionFeedback=h?Kt({collectionName:h.collection.name,added:h.added}):"Could not save to collection.",v(n)})()}));i.appendChild(d)}const l=n.createElement("label");l.className="vera5-workspace-field-label",l.textContent=Zr;const u=n.createElement("input");if(u.type="text",u.value=c.saveToCollectionNewName,u.placeholder=Ue,u.setAttribute("aria-label",Ue),u.addEventListener("input",()=>{c.saveToCollectionNewName=u.value,v(n)}),l.appendChild(u),i.appendChild(l),i.appendChild(H(eo,n,()=>{(async()=>{const d=await uo({name:c.saveToCollectionNewName});if(!d){c.saveToCollectionFeedback="Could not create collection.",v(n);return}const f=await qt({collectionId:d.id,member:{iocType:t.type,value:t.value}});if(!f){c.saveToCollectionFeedback="Collection created, but indicator was not saved.",v(n);return}c.saveToCollectionOptions=[f.collection,...c.saveToCollectionOptions.filter(h=>h.id!==f.collection.id)],c.saveToCollectionNewName="",c.saveToCollectionFeedback=Kt({collectionName:f.collection.name,added:f.added}),v(n)})()},En(c.saveToCollectionNewName)===null)),c.saveToCollectionFeedback){const d=n.createElement("p");d.className="vera5-tray-save-collection-feedback",d.setAttribute("aria-live","polite"),d.textContent=c.saveToCollectionFeedback,i.appendChild(d)}r.appendChild(i),e.appendChild(r)}async function ry(e){c.addFilteredToCollectionOpen=!0,c.addFilteredToCollectionFeedback=null,c.addFilteredToCollectionNewName="",c.addFilteredToCollectionLoading=!0,c.addFilteredToCollectionOptions=[],v(e),c.addFilteredToCollectionOptions=await lo(),c.addFilteredToCollectionLoading=!1,v(e)}function oy(e,t,n){const r=n.createElement("div");r.className="vera5-tray-save-collection",r.addEventListener("click",f=>{f.stopPropagation()}),r.addEventListener("keydown",f=>{f.stopPropagation()});const o=t.map(f=>({iocType:f.type,value:f.value})),a=c.addFilteredToCollectionOpen,i=n.createElement("button");if(i.type="button",i.className="vera5-tray-save-collection-toggle",i.textContent=Zm(t.length),i.setAttribute("aria-expanded",a?"true":"false"),i.disabled=t.length===0,i.addEventListener("click",()=>{if(a){c.addFilteredToCollectionOpen=!1,c.addFilteredToCollectionFeedback=null,v(n);return}ry(n)}),r.appendChild(i),!a){e.appendChild(r);return}const s=n.createElement("div");s.className="vera5-tray-save-collection-panel",s.setAttribute("role","group"),s.setAttribute("aria-label",oa);const l=n.createElement("p");if(l.className="vera5-tray-save-collection-heading",l.textContent=oa,s.appendChild(l),c.addFilteredToCollectionLoading){const f=n.createElement("p");f.className="vera5-workspace-empty",f.textContent="Loading collections…",s.appendChild(f)}else if(c.addFilteredToCollectionOptions.length===0){const f=n.createElement("p");f.className="vera5-workspace-empty",f.textContent=to,s.appendChild(f)}else{const f=n.createElement("div");f.className="vera5-tray-save-collection-list";for(const h of c.addFilteredToCollectionOptions)f.appendChild(H(h.name,n,()=>{(async()=>{const E=await Ea({collectionId:h.id,members:o});c.addFilteredToCollectionFeedback=E?aa({collectionName:E.collection.name,addedCount:E.addedCount,duplicateCount:E.duplicateCount,totalCount:E.totalCount}):"Could not add filtered indicators to collection.",v(n)})()}));s.appendChild(f)}const u=n.createElement("label");u.className="vera5-workspace-field-label",u.textContent=Zr;const d=n.createElement("input");if(d.type="text",d.value=c.addFilteredToCollectionNewName,d.placeholder=Ue,d.setAttribute("aria-label",Ue),d.addEventListener("input",()=>{c.addFilteredToCollectionNewName=d.value,v(n)}),u.appendChild(d),s.appendChild(u),s.appendChild(H(eo,n,()=>{(async()=>{const f=await uo({name:c.addFilteredToCollectionNewName});if(!f){c.addFilteredToCollectionFeedback="Could not create collection.",v(n);return}const h=await Ea({collectionId:f.id,members:o});if(!h){c.addFilteredToCollectionFeedback="Collection created, but filtered indicators were not saved.",v(n);return}c.addFilteredToCollectionOptions=[h.collection,...c.addFilteredToCollectionOptions.filter(E=>E.id!==h.collection.id)],c.addFilteredToCollectionNewName="",c.addFilteredToCollectionFeedback=aa({collectionName:h.collection.name,addedCount:h.addedCount,duplicateCount:h.duplicateCount,totalCount:h.totalCount}),v(n)})()},En(c.addFilteredToCollectionNewName)===null)),c.addFilteredToCollectionFeedback){const f=n.createElement("p");f.className="vera5-tray-save-collection-feedback",f.setAttribute("aria-live","polite"),f.textContent=c.addFilteredToCollectionFeedback,s.appendChild(f)}r.appendChild(s),e.appendChild(r)}function ay(e,t,n,r=!1,o=""){const a=t.createElement("button");return a.type="button",a.className=`vera5-workspace-icon-button${o?` ${o}`:""}`,a.textContent="↻",a.setAttribute("aria-label",e),a.disabled=r,a.addEventListener("click",n),a}function Pa(e,t,n,r,o){const a=r.createElement("button");a.type="button",a.className="vera5-workspace-toggle",t&&a.classList.add("vera5-workspace-toggle--on"),a.setAttribute("role","switch"),a.setAttribute("aria-checked",t?"true":"false"),a.setAttribute("aria-label",e),a.disabled=n;const i=r.createElement("span");i.className="vera5-workspace-toggle-label",i.textContent=e;const s=r.createElement("span");s.className="vera5-workspace-toggle-switch",s.setAttribute("aria-hidden","true");const l=r.createElement("span");return l.className="vera5-workspace-toggle-knob",s.appendChild(l),a.append(i,s),a.addEventListener("click",()=>{a.disabled||o(!t)}),a}function Ma(e,t,n,r){const o=n.createElement("button");return o.type="button",o.className="vera5-workspace-filter-chip",o.textContent=e,o.setAttribute("aria-pressed",t?"true":"false"),o.addEventListener("click",r),o}function iy(e){return e==="Live"?"vera5-workspace-tray-hint vera5-workspace-tray-hint--live":e==="Error"?"vera5-workspace-tray-hint vera5-workspace-tray-hint--error":"vera5-workspace-tray-hint"}async function sy(e){if(c.enabled){c.scanState="scanning",c.typeFilter="all",c.trayFilterReady=!1,c.trayNavigationMessage=null,c.trayEnrichmentStatuses={},v(e);try{const t=await vn();if(!t.ok){c.scanState="error";return}const n=Ic(t.payload)??await fo();if(!n){c.scanState="error";return}c.scanSummary=n,c.scanState="done",c.typeFilter="all",c.trayFilterReady=!0,jt(n.tabId,"all").catch(r=>{C(r)}),Rn().then(()=>{c.open&&c.scanState==="done"&&v(e)}).catch(r=>{C(r)})}catch(t){C(t),c.scanState="error"}finally{c.scanState==="scanning"&&(c.scanState="error"),c.open&&v(e)}}}async function cy(e){if(c.enabled){c.scanState="scanning",c.typeFilter="all",c.trayFilterReady=!1,c.trayNavigationMessage=null,c.trayEnrichmentStatuses={},v(e);try{const t=await es();if(!t.ok){c.scanState="error";return}const n=Ic(t.payload)??await fo();if(!n){c.scanState="error";return}c.scanSummary=n,c.scanState="done",c.typeFilter="all",c.trayFilterReady=!0,jt(n.tabId,"all").catch(r=>{C(r)}),Rn().then(()=>{c.open&&c.scanState==="done"&&v(e)}).catch(r=>{C(r)})}catch(t){C(t),c.scanState="error"}finally{c.scanState==="scanning"&&(c.scanState="error"),c.open&&v(e)}}}function ly(e){const t=gn(e)!==null,n=t!==c.textSelectionAvailable;n&&(c.textSelectionAvailable=t),Co(e).then(r=>{const o=r!==null;o===c.selectionEnrichAvailable&&!n||(c.selectionEnrichAvailable=o,c.open&&v(e))}).catch(r=>{C(r)}),n&&c.open&&v(e)}async function uy(e){if(c.enabled)try{await Ao(e)}catch(t){C(t)}}function dy(e){c.scanState!=="scanning"&&(c.scanSummary=null,c.scanState="idle",c.typeFilter="all",c.trayFilterReady=!1,c.trayNavigationMessage=null,c.trayEnrichmentStatuses={},c.trayMultiSelectAnchorIds={},Et(),c.selection&&(U(),c.selection=null,c.selectedAnchorId=null,xn(),Xe({open:!0,selectedAnchorId:null,payloadValue:null}),go(null),Ge(e)),v(e))}function py(e){if(!c.selection){Ge(e);return}U(),c.selection=null,c.selectedAnchorId=null,xn(),Xe({open:!0,selectedAnchorId:null,payloadValue:null}),Ge(e),v(e)}function fy(e){c.collapsed=!c.collapsed,Sc(e);const t=e.querySelector(".vera5-workspace-sidebar");t instanceof HTMLElement&&t.classList.toggle("vera5-workspace-sidebar--collapsed",c.collapsed);const n=e.querySelector(".vera5-workspace-edge-tab");n instanceof HTMLButtonElement&&(n.textContent=c.collapsed?"‹":"›",n.setAttribute("aria-label",c.collapsed?"Expand workspace":"Collapse workspace"))}function my(e,t={},n=document){const r=Je(e);return r?(xo(r,e,t,n,e.dataset.vera5AnchorId??null),!0):!1}function xo(e,t,n={},r=document,o=t.dataset.vera5AnchorId??null){c.selectedAnchorId=o,c.trayNavigationMessage=null,(i=>{c.selection={highlight:t,payload:i},Xe({open:!0,selectedAnchorId:c.selectedAnchorId,payloadValue:i.value}),nn(i,r),v(r)})(e),!L()&&_n().then(({disabledSourceIds:i,enabledSourceIds:s,showDisabledSourcesInWorkspace:l})=>{const u={...e,...i.length>0?{disabledSources:i}:{},enabledEnrichmentSourceIds:s,showDisabledSourcesInWorkspace:l};c.selection?.highlight===t&&c.selectedAnchorId===o&&(c.selection={highlight:t,payload:u},nn(u,r)),n.enrichmentTrigger==="manual"?(U(),_t(u,r,{bypassCache:!0}).catch(d=>{C(d)})):n.enrichmentTrigger!=="none"&&yo(u).catch(d=>{C(d)})}).catch(i=>{C(i)})}function No(e,t=document){const n=t.querySelector(`[data-vera5-anchor-id="${CSS.escape(e)}"]`);return n?(n.scrollIntoView({block:"center",inline:"nearest",behavior:"smooth"}),my(n,{enrichmentTrigger:"auto"},t)):(c.trayNavigationMessage="This indicator is no longer on the page. Scan again to refresh the list.",v(t),!1)}function hy(e,t){t?c.trayMultiSelectAnchorIds[e]=!0:delete c.trayMultiSelectAnchorIds[e]}function gy(){const e=c.scanSummary;return e?Ie(e.entries,c.typeFilter).map(n=>n.anchorId).filter(n=>c.trayMultiSelectAnchorIds[n]):[]}async function vy(e,t){const n=t.querySelector(`[data-vera5-anchor-id="${CSS.escape(e)}"]`);if(!n){c.trayNavigationMessage="This indicator is no longer on the page. Scan again to refresh the list.",v(t);return}const r=Je(n);if(!r)return;n.scrollIntoView({block:"center",inline:"nearest",behavior:"smooth"});const{disabledSourceIds:o,enabledSourceIds:a,showDisabledSourcesInWorkspace:i}=await _n(),s={...r,...o.length>0?{disabledSources:o}:{},enabledEnrichmentSourceIds:a,showDisabledSourcesInWorkspace:i};xo(r,n,{enrichmentTrigger:"none"},t,e),U(),await _t(s,t,{bypassCache:!0})==="cancelled"&&Et()}function Ey(e,t){return At(t),new Promise(n=>{const r=t.createElement("div");r.className="vera5-tray-enrich-queue-warning-backdrop";const o=t.createElement("div");o.className="vera5-tray-enrich-queue-warning-panel",o.setAttribute("role","dialog"),o.setAttribute("aria-modal","true"),o.setAttribute("aria-label",Da);const a=t.createElement("h3");a.className="vera5-tray-enrich-queue-warning-heading",a.textContent=Da;const i=t.createElement("p");i.className="vera5-tray-enrich-queue-warning-message",i.setAttribute("role","note"),i.textContent=e;const s=t.createElement("div");s.className="vera5-tray-enrich-queue-warning-actions";const l=f=>{r.remove(),n(f)},u=H(XE,t,()=>{l(!0)}),d=H(JE,t,()=>{l(!1)});s.append(u,d),o.append(a,i,s),r.appendChild(o),r.addEventListener("click",f=>{f.target===r&&l(!1)}),t.body.appendChild(r),u.focus()})}async function yy(e,t){if(pc()||e.length===0)return;const n=c.scanSummary;if(!n)return;if(!(await So(t)).allowed){c.trayNavigationMessage=sc,v(t);return}const o=Ie(n.entries,c.typeFilter),a=await bo(),i=aE(o,e,a);if(await Ey(iE(i),t)){c.trayNavigationMessage=null;try{await WE(e,l=>vy(l,t),()=>{c.open&&v(t)})}catch(l){C(l)}finally{await Rn(),c.open&&v(t)}}}function v(e){const t=e.querySelector(".vera5-workspace-top");if(!(t instanceof HTMLElement))return;t.replaceChildren();const n=e.createElement("div");n.className="vera5-workspace-controls";const r=e.createElement("div");if(r.className="vera5-workspace-toggle-row",r.appendChild(Pa("Extension enabled",c.enabled,!c.ready,e,m=>{c.enabled=m,pf(m),m||(c.scanState="idle",c.scanSummary=null,c.typeFilter="all",c.trayFilterReady=!1,c.trayNavigationMessage=null,c.trayEnrichmentStatuses={},c.trayMultiSelectAnchorIds={},Et(),c.selection=null,c.selectedAnchorId=null,Ge(e)),v(e)})),r.appendChild(Pa("Highlight indicators",c.highlightEnabled,!c.ready||!c.enabled,e,m=>{c.highlightEnabled=m,mf(m),v(e)})),n.appendChild(r),n.appendChild(H(c.scanState==="scanning"?"Scanning…":"Scan page",e,()=>{sy(e).catch(m=>{C(m)})},!c.ready||!c.enabled||c.scanState==="scanning")),n.appendChild(H(c.scanState==="scanning"?"Scanning…":"Scan selection",e,()=>{cy(e).catch(m=>{C(m)})},!c.ready||!c.enabled||c.scanState==="scanning"||!c.textSelectionAvailable)),n.appendChild(H("Enrich selection",e,()=>{uy(e).catch(m=>{C(m)})},!c.ready||!c.enabled||!c.selectionEnrichAvailable)),n.appendChild(H("Settings",e,()=>{z(Ka())},!c.ready)),n.appendChild(H("Permissions",e,()=>{qv()},!c.ready)),c.scanState==="error"){const m=e.createElement("p");m.className="vera5-workspace-error",m.textContent="Scan failed. Reload the tab and try again.",n.appendChild(m)}t.appendChild(n);const o=Xv({enabled:c.enabled,scanState:c.scanState,scanSummary:c.scanSummary});if(!o)return;const a=e.createElement("div");a.className="vera5-workspace-tray-heading-row";const i=e.createElement("h2");i.className="vera5-workspace-tray-heading",i.textContent="Detected indicators";const s=ay("Clear detected indicators",e,()=>{dy(e)},!c.ready||!c.enabled||c.scanState==="scanning");if(a.append(i,s),t.appendChild(a),o==="prompt"){const m=e.createElement("p");m.className="vera5-workspace-empty",m.textContent=jE,t.appendChild(m);return}if(o==="scanning"){const m=e.createElement("p");m.className="vera5-workspace-empty",m.setAttribute("aria-live","polite"),m.textContent="Scanning page…",t.appendChild(m);return}if(o==="empty"){const m=e.createElement("p");m.className="vera5-workspace-empty",m.setAttribute("aria-live","polite"),m.textContent="No indicators detected on this page.",t.appendChild(m);return}const l=c.scanSummary;if(!l)return;const u=e.createElement("p");u.className="vera5-workspace-tray-summary",u.textContent=rh(l),t.appendChild(u);const d=e.createElement("div");d.className="vera5-workspace-filter-row",d.setAttribute("role","group"),d.setAttribute("aria-label","Filter by indicator type"),d.appendChild(Ma(`All (${l.totalCount})`,c.typeFilter==="all",e,()=>{c.typeFilter="all",c.trayFilterReady&&c.scanSummary&&jt(c.scanSummary.tabId,"all"),v(e)}));for(const m of vs(l))d.appendChild(Ma(`${Zn[m]} (${l.countByType[m]??0})`,c.typeFilter===m,e,()=>{c.typeFilter=m,c.trayFilterReady&&c.scanSummary&&jt(c.scanSummary.tabId,m),v(e)}));t.appendChild(d);const f=Ih(Ie(l.entries,c.typeFilter),c.sessionPinnedIocKeys),h=gy(),E=pc(),x=KE(),P=e.createElement("div");if(P.className="vera5-workspace-tray-bulk-row",P.appendChild(H(`Enrich selected (${h.length})`,e,()=>{yy(h,e).catch(m=>{C(m)})},!c.ready||!c.enabled||h.length===0||E)),E&&P.appendChild(H("Cancel enrich queue",e,()=>{Et(),U(),v(e)},!1)),t.appendChild(P),oy(P,f,e),E&&x){const m=e.createElement("p");m.className="vera5-workspace-tray-queue-status",m.setAttribute("aria-live","polite"),m.textContent=`Enriching ${x.currentIndex} of ${x.totalCount}…`,t.appendChild(m)}if(c.trayNavigationMessage){const m=e.createElement("p");m.className="vera5-workspace-error",m.setAttribute("role","alert"),m.setAttribute("aria-live","polite"),m.textContent=c.trayNavigationMessage,t.appendChild(m)}if(f.length===0){const m=e.createElement("p");m.className="vera5-workspace-empty",m.textContent="No indicators match this filter.",t.appendChild(m);return}const Z=e.createElement("ul");Z.className="vera5-workspace-tray-list";for(const m of f){const $=c.trayEnrichmentStatuses[m.anchorId],K=lh(m),S=e.createElement("li");S.className="vera5-workspace-tray-row",S.dataset.vera5TrayEntry="true",S.dataset.vera5Type=m.type,S.dataset.vera5Value=m.value,S.dataset.vera5AnchorId=m.anchorId,K&&(S.dataset.vera5RuleId=K.ruleId,S.dataset.vera5SourceTextHint=K.sourceTextHint),m.displayValue&&(S.dataset.vera5DisplayValue=m.displayValue),S.tabIndex=0,S.setAttribute("role","button"),S.setAttribute("aria-label",ih(m.value,$)),S.setAttribute("aria-selected",c.selectedAnchorId===m.anchorId?"true":"false"),S.classList.toggle("vera5-workspace-tray-row--bulk-selected",!!c.trayMultiSelectAnchorIds[m.anchorId]),S.classList.toggle("vera5-workspace-tray-row--pinned",c.sessionPinnedIocKeys.includes(Q(m.value)));const N=e.createElement("input");N.type="checkbox",N.className="vera5-workspace-tray-select",N.checked=!!c.trayMultiSelectAnchorIds[m.anchorId],N.disabled=E,N.setAttribute("aria-label",`Select ${m.value} for bulk enrich`),N.addEventListener("click",b=>{b.stopPropagation()}),N.addEventListener("change",()=>{hy(m.anchorId,N.checked),v(e)});const Y=()=>{No(m.anchorId,e)};S.addEventListener("click",Y),S.addEventListener("keydown",b=>{b.key!=="Enter"&&b.key!==" "||(b.preventDefault(),Y())});const ue=e.createElement("span");ue.className="vera5-workspace-tray-type",ue.setAttribute("aria-hidden","true"),ue.textContent=Zn[m.type];const de=Or({value:m.value,displayValue:m.displayValue}),pe=e.createElement("span");if(pe.className="vera5-workspace-tray-value",de.showRefangedPair){const b=e.createElement("span");b.className="vera5-workspace-tray-value-on-page",b.textContent=de.onPageValue;const W=e.createElement("span");W.className="vera5-workspace-tray-refanged-value",W.textContent=`${fi} ${de.refangedValue}`,pe.append(b,W)}else pe.textContent=de.refangedValue;const ne=e.createElement("div");if(ne.className="vera5-workspace-tray-row-main",c.sessionPinnedIocKeys.includes(Q(m.value))){const b=e.createElement("span");b.className="vera5-workspace-tray-pin",b.textContent="★",b.setAttribute("aria-label","Pinned for triage"),ne.appendChild(b)}if(ne.append(N,ue,pe),$){const b=e.createElement("span");b.className=iy($.badgeText),b.setAttribute("aria-hidden","true"),b.textContent=Es($),ne.appendChild(b)}S.appendChild(ne),ny(S,m,e);const Qe=pi({type:m.type,ruleId:m.ruleId,sourceTextHint:m.sourceTextHint,ignoredOverlaps:m.ignoredOverlaps});if(Qe){const b=e.createElement("details");b.className=Xs,b.addEventListener("click",fe=>{fe.stopPropagation()}),b.addEventListener("keydown",fe=>{fe.stopPropagation()});const W=e.createElement("summary");W.textContent=di,b.appendChild(W),b.appendChild(nc(Qe,e,{compact:!0,omitHeading:!0})),S.appendChild(b)}Z.appendChild(S)}t.appendChild(Z)}function by(e){const t=yc(e);t.replaceChildren();const n=e.createElement("div");n.className="vera5-workspace-shell";const r=e.createElement("button");r.type="button",r.className="vera5-workspace-edge-tab",r.textContent=c.collapsed?"‹":"›",r.setAttribute("aria-label",c.collapsed?"Expand workspace":"Collapse workspace"),r.addEventListener("click",()=>{fy(e)});const o=e.createElement("div");o.className="vera5-workspace-sidebar",c.collapsed&&o.classList.add("vera5-workspace-sidebar--collapsed"),o.setAttribute("role","complementary"),o.setAttribute("aria-label","Vera5 workspace");const a=e.createElement("div");a.className="vera5-workspace-header";const i=e.createElement("a");i.className="vera5-workspace-title",i.href=hc,i.target="_blank",i.rel="noopener noreferrer";const s=e.createElement("span");s.className="vera5-workspace-title-5",s.textContent="5",i.append("Vera",s);const l=e.createElement("button");l.type="button",l.className="vera5-workspace-close",l.textContent="×",l.setAttribute("aria-label","Close Vera5 workspace"),l.addEventListener("click",()=>{Ro(e)}),a.append(i,l);const u=e.createElement("div");u.className="vera5-workspace-top";const d=e.createElement("hr");d.className="vera5-workspace-divider",d.setAttribute("aria-hidden","true");const f=e.createElement("div");f.className="vera5-workspace-bottom",o.append(a,u,d,f),n.append(r,o),t.appendChild(n),Sc(e),v(e),c.selection?nn(c.selection.payload,e):Ge(e)}function wo(e=document){c.open=!0,c.textSelectionAvailable=gn(e)!==null,Co(e).then(n=>{c.selectionEnrichAvailable=n!==null,c.open&&v(e)}).catch(n=>{C(n)}),Xe({open:!0,selectedAnchorId:c.selectedAnchorId,payloadValue:c.selection?.payload.value??null});const t=yc(e);t.hidden=!1,_o(!0,e),by(e),Tc(e).catch(n=>{C(n)})}function Ro(e=document){c.open=!1,c.selection=null,c.selectedAnchorId=null,go(null),xn(),Xe({open:!1,selectedAnchorId:null,payloadValue:null}),U();const t=e.getElementById(Be);t&&(t.hidden=!0,t.replaceChildren()),_o(!1,e)}function _c(e=document){if(wn(e)){Ro(e);return}wo(e)}let pr=!1,fr=!1;function xc(e=document){IE((t,n)=>{Cc(t,n)}),e.addEventListener("selectionchange",()=>{ly(e)}),typeof chrome<"u"&&chrome.runtime?.onMessage&&!pr&&(pr=!0,chrome.runtime.onMessage.addListener((t,n,r)=>{if(vc(t)){try{_c(e),r({ok:!0,payload:{open:wn(e)}})}catch(o){w(o)}return!0}if(Ec(t)){try{wo(e),r({ok:!0,payload:{open:!0}})}catch(o){w(o)}return!0}return!1})),!(typeof chrome>"u"||!chrome.storage?.onChanged||fr)&&(fr=!0,chrome.storage.onChanged.addListener((t,n)=>{if(n!=="session"||!c.open)return;Object.keys(t).some(o=>o.startsWith("tabScanSnapshot:"))&&Tc(e).catch(o=>{C(o)})}))}function Sy(){Et(),YE(),c=gc(),pr=!1,fr=!1,xn(),Xe({open:!1,selectedAnchorId:null,payloadValue:null})}const Ha=Object.freeze(Object.defineProperty({__proto__:null,VERA5_WEBSITE_URL:hc,WORKSPACE_COLLAPSED_WIDTH_PX:fc,WORKSPACE_HOST_GUTTER_PX:To,WORKSPACE_HOST_ID:Be,WORKSPACE_HTML_CLASS:mc,WORKSPACE_WIDTH_PX:Io,activateWorkspaceIndicatorByAnchorId:No,closeWorkspace:Ro,getWorkspaceSelection:QE,isOpenWorkspaceMessage:Ec,isToggleWorkspaceMessage:vc,isWorkspaceOpen:wn,openWorkspace:wo,presentWorkspaceEnrichmentForPayload:xo,resetWorkspaceSidebarForTests:Sy,setupWorkspaceSidebarListener:xc,toggleWorkspace:_c,updateWorkspaceAnalystNoteIfOpen:Ac,updateWorkspaceDetailPanel:Cc},Symbol.toStringTag,{value:"Module"}));async function Cy(){await jl()}function Ay(){chrome.storage.onChanged.addListener((e,t)=>{on(()=>{if(t!=="local")return;const n=e[it];if(!n)return;const r=Gn(n.oldValue),o=Gn(n.newValue),a=new Set([...Object.keys(r),...Object.keys(o)]);for(const i of a){const s=r[i]??"",l=o[i]??"";if(s===l)continue;const u=ct(i);ni(i,l),u!==l&&(zv(i,l),Ac(i,l))}})})}async function Iy(){await Tm()}function Ty(){chrome.storage.onChanged.addListener((e,t)=>{on(()=>{if(t!=="local")return;const n=e[pt];if(!n)return;const r=Jn(n.oldValue),o=Jn(n.newValue),a=new Set([...Object.keys(r),...Object.keys(o)]);for(const i of a){const s=r[i]??null,l=o[i]??null;if(s===l)continue;const u=Bt(i);ps(i,l),u!==l&&Kv(i,l)}})})}const Oo=new Map;function _e(e){Oo.set(e.id,e)}function _y(){return[...Oo.values()].sort((e,t)=>e.label.localeCompare(t.label))}function xy(e,t){if(t.length===0)return!0;const n=[e.id,e.label,e.description??"",...e.keywords??[]].join(" ").toLowerCase();return t.split(/\s+/).filter(Boolean).every(r=>n.includes(r))}function Ny(e){const t=e.trim().toLowerCase();return _y().filter(n=>n.isEnabled&&!n.isEnabled()?!1:xy(n,t))}async function wy(e){const t=Oo.get(e);return!t||t.isEnabled&&!t.isEnabled()?!1:(await t.run(),!0)}const xe={SCAN_PAGE:"scan-page",ENRICH_SELECTION:"enrich-selection",COPY_FILTERED_MARKDOWN:"copy-filtered-markdown",EXPORT_TRAY_SUBSET:"export-tray-subset",CLEAR_HIGHLIGHTS:"clear-highlights",OPEN_OPTIONS:"open-options"};function Ry(e=document){const t=e.getSelection();return!!(t&&t.rangeCount>0&&!t.isCollapsed)}function Oy(){_e({id:xe.SCAN_PAGE,label:"Scan page",description:"Detect indicators in visible page text",keywords:["detect","ioc","scan"],run:()=>{vn()}}),_e({id:xe.ENRICH_SELECTION,label:"Enrich selection",description:"Look up the indicator in the current text selection",keywords:["enrich","ioc","lookup","selection"],isEnabled:()=>Ry(),run:()=>{Ao()}}),_e({id:xe.COPY_FILTERED_MARKDOWN,label:"Copy filtered Markdown",description:"Copy filtered tray indicators as Markdown",keywords:["clipboard","copy","markdown","tray"],run:async()=>{const e=await Ta();e.length!==0&&(await Pr("markdown-report",e),Wt({iocs:e.map(t=>({value:t.value,type:t.type}))}))}}),_e({id:xe.EXPORT_TRAY_SUBSET,label:"Export tray subset",description:"Download filtered tray indicators as Markdown",keywords:["download","export","markdown","tray"],run:async()=>{const e=await Ta();e.length!==0&&(Dr("markdown-report",e),Wt({iocs:e.map(t=>({value:t.value,type:t.type}))}))}}),_e({id:xe.CLEAR_HIGHLIGHTS,label:"Clear highlights",description:"Remove all indicator highlights on this page",keywords:["clear","highlight","reset"],run:()=>{hn(document.body)}}),_e({id:xe.OPEN_OPTIONS,label:"Open options",description:"Open extension settings",keywords:["options","preferences","settings"],run:()=>{Wa()}})}const Nc="vera5-command-palette-host",Ly="vera5-command-palette-backdrop",ky="vera5-command-palette-panel",wc="vera5-command-palette-input",Rc="vera5-command-palette-list",Dy="vera5-command-palette-item",Py="vera5-command-palette-item--selected",Oc="vera5-command-palette-empty",My="vera5-command-palette-hint",Hy="Vera5 command palette",Vy="Filter commands",Uy="No matching commands.",Fy="Type to filter · Enter to run · Esc to close · ↑↓ to navigate";let _={open:!1,query:"",selectedIndex:0},tt=null;function Lo(e){return Ny(e)}function mr(e,t){return t<=0?0:e<0?t-1:e>=t?0:e}function xt(e){return e.getElementById(Nc)}function $y(e){return xt(e)?.querySelector(`.${wc}`)??null}function rn(e){const t=xt(e);if(!t)return;const n=t.querySelector(`.${Rc}`),r=t.querySelector(`.${Oc}`);if(!n||!r)return;const o=Lo(_.query);if(_.selectedIndex=mr(_.selectedIndex,o.length),n.replaceChildren(),o.length===0){r.textContent=Uy,r.hidden=!1;return}r.hidden=!0,o.forEach((a,i)=>{const s=e.createElement("button");s.type="button",s.className=Dy,s.dataset.commandId=a.id,s.setAttribute("role","option"),s.setAttribute("aria-selected",i===_.selectedIndex?"true":"false"),i===_.selectedIndex&&s.classList.add(Py);const l=e.createElement("span");if(l.className="vera5-command-palette-item-label",l.textContent=a.label,s.appendChild(l),a.description){const u=e.createElement("span");u.className="vera5-command-palette-item-description",u.textContent=a.description,s.appendChild(u)}s.addEventListener("click",()=>{_.selectedIndex=i,Lc(e)}),n.appendChild(s)})}function By(e){At(e);let t=xt(e);if(t)return t;t=e.createElement("div"),t.id=Nc,t.hidden=!0;const n=e.createElement("div");n.className=Ly,n.addEventListener("click",l=>{l.target===n&&On(e)});const r=e.createElement("div");r.className=ky,r.setAttribute("role","dialog"),r.setAttribute("aria-modal","true"),r.setAttribute("aria-label",Hy);const o=e.createElement("input");o.type="search",o.className=wc,o.setAttribute("aria-label",Vy),o.autocomplete="off",o.spellcheck=!1,o.addEventListener("input",()=>{_.query=o.value,_.selectedIndex=0,rn(e)}),o.addEventListener("keydown",l=>{Gy(l,e)});const a=e.createElement("div");a.className=Rc,a.setAttribute("role","listbox");const i=e.createElement("p");i.className=Oc,i.hidden=!0;const s=e.createElement("p");return s.className=My,s.textContent=Fy,r.append(o,a,i,s),n.appendChild(r),t.appendChild(n),e.body.appendChild(t),t}function Gy(e,t){if(!_.open)return;const n=Lo(_.query);if(e.key==="ArrowDown"){e.preventDefault(),_.selectedIndex=mr(_.selectedIndex+1,n.length),rn(t);return}if(e.key==="ArrowUp"){e.preventDefault(),_.selectedIndex=mr(_.selectedIndex-1,n.length),rn(t);return}if(e.key==="Enter"){e.preventDefault(),Lc(t);return}e.key==="Escape"&&(e.preventDefault(),On(t))}async function Lc(e){const n=Lo(_.query)[_.selectedIndex];n&&(On(e),await wy(n.id))}function zy(e=document){const t=xt(e);return _.open&&t!==null&&!t.hidden}function Ky(e=document){const t=By(e);tt=e.activeElement instanceof HTMLElement?e.activeElement:null,_={open:!0,query:"",selectedIndex:0},t.hidden=!1;const n=$y(e);n&&(n.value=""),rn(e),n?.focus()}function On(e=document){_.open=!1,_.query="",_.selectedIndex=0;const t=xt(e);t&&(t.hidden=!0),tt&&e.contains(tt)&&tt.focus(),tt=null}function Yy(e=document){if(zy(e)){On(e);return}Ky(e)}function Wy(e){return e!==null&&typeof e=="object"&&"type"in e&&e.type===le.TOGGLE_COMMAND_PALETTE}function jy(){Oy(),chrome.runtime.onMessage.addListener(e=>(Wy(e)&&Yy(document),!1))}function qy(e){return e!==null&&typeof e=="object"&&"type"in e&&e.type===le.NAVIGATE_TO_IOC_ANCHOR&&typeof e.anchorId=="string"&&e.anchorId.length>0}function Xy(e,t=document.body,n=document){const r=rm(e,t);return r?(r.scrollIntoView({block:"center",inline:"nearest",behavior:"smooth"}),wn(n)?No(e,n)?{ok:!0}:{ok:!1,error:"highlight not found"}:(Nn(r,{enrichmentTrigger:"auto"},n),{ok:!0})):{ok:!1,error:"highlight not found"}}function Jy(){chrome.runtime.onMessage.addListener((e,t,n)=>{if(!qy(e))return!1;try{n(Xy(e.anchorId))}catch(r){w(r)}return!0})}const Qy=document.documentElement.dataset.vera5ContentInit==="1";Qy||(document.documentElement.dataset.vera5ContentInit="1",document.documentElement.dataset.vera5Content="active",z({type:le.CONTENT_REGISTER}),dm(),zE(),Jy(),pm(),Em(),Dn(vm),Ay(),Ty(),zh(),Dn(Cy),Dn(Iy),OE(),jy(),VE());xc();
